# Dirección vigente v3: variedad de escenas con continuidad

## Tres unidades independientes

- **Pulso narrativo:** una idea, causa, consecuencia o avance del relato. Unos 10–20 pulsos pueden servir para 40 s; 14 es una base editable.
- **Subtítulo:** una unidad de lectura, con su propio inicio y final. Puede cubrir parte de un pulso o unir dos; no crea automáticamente una escena.
- **Escena visual:** una situación o escala de observación que desarrolla varias acciones y conserva sus objetos mientras se explica. Para unos 40 s, elegir **2–4 escenas visuales diferentes**. No imponer un único escenario durante todo el video.

Los cambios de encuadre y detalles dentro de una escena tampoco se cuentan automáticamente como escenas nuevas. La cantidad sigue la explicación, no las filas del texto.

## Diseñar cada escena y su salida

Antes de programar, definir contexto, protagonista, varias acciones causales, resultado y salida. Para cada unión escribir:

> El resultado de A deja este objeto en este estado → seguimos esta pieza, dato o acción → llegamos al encuadre de B y continuamos desde ese estado.

Ejemplos: seguir un perfil cortado hacia el banco de ensamblaje; entrar al celular desde su pantalla; seguir un paquete de datos hasta el auricular; alejarse de un detalle para revelar la máquina completa. Cambiar la escena conservando una referencia identificable; no exigir que todos los objetos sigan visibles cuando la cámara entra en un detalle.

Registrar por unión: intervalo de transición, pose y escala de salida, recorrido/cámara, referencia compartida, pose de llegada y primera acción posterior. Elegir transiciones que se puedan describir sin decir solamente «fundido».

## Animación que explica causas

Varias acciones por escena: preparar una pieza, moverla, encajarla y comprobar el resultado; convertir audio en datos, agruparlos y emitir un paquete. Cada acción hereda un resultado. El cambio de subtítulo no reinicia posiciones ni hace aparecer nuevamente el objeto.

Introducir novedades relevantes aproximadamente cada 1–3 s, con pausas para comprenderlas. Movimiento ágil no significa movimiento constante: evitar vibración, zoom permanente, partículas sin función o títulos animados como sustituto del mecanismo. Mostrar detalles del proceso y variar encuadres con intención.

## Transiciones y cámara

Evitar cortes bruscos, reinicios del dibujo, saltos de escala o posición. Se reemplaza el antiguo presupuesto de «hasta dos cortes bruscos»: no es una cuota permitida para la nueva dirección. Revisar y resolver cada salto que desoriente.

Seguir una pieza, acercarse al interior, alejarse para revelar contexto o continuar una acción en el plano siguiente son conexiones válidas. Mantener dirección y velocidad coherentes, con aceleración y asentamiento suaves. Como punto inicial, 12–30 cuadros para un recorrido corto; ampliar si cambia mucho la escala. No hay un porcentaje universal de zoom.

Un fundido puede acompañar un enlace, pero no resolver todas las uniones ni esconder cambios de estado. Diseñar cómo termina A y por qué ese resultado conduce a B. Ni cuatro placas con fades ni cuarenta segundos del mismo encuadre inmóvil satisfacen esta preferencia.

## Texto inicial y desarrollo

Mostrar la pregunta principal solo al comienzo, **como primer subtítulo**. Referencia: 64–84 px en 1080×1920, unos 2–4 s según extensión, máximo dos líneas, salida suave cuando empieza la explicación. No duplicarla como título arriba y subtítulo abajo.

Después, solo subtítulos y etiquetas breves necesarias al lado del gráfico. Sin título permanente, marca fija ni nombre de sección. Sin números de escena o slide. Usar el espacio liberado para objetos y detalles más grandes, respetando la zona segura de la guía visual.

Los últimos 3 s contienen una única CTA integrada en la escena final, después de resolver la pregunta. Mantener una acción suave sin introducir otra escena de cierre.

## Arquitectura Remotion

Separar el plan de escenas, el estado visual global y la pista de subtítulos. Un `Sequence` puede cubrir una escena con varios pulsos. No montar un `Shot` diferente por cada frase ni usar el texto como key de los objetos. Las escenas pueden ser componentes distintos; sus extremos deben compartir estado y su transición estar diseñada.

Esquema conceptual, no implementación probada:

```tsx
const frame = useCurrentFrame();
const visual = sampleScenesAtFrame(frame); // incluye cámara y estados de transición
const caption = captionAtFrame(frame);    // tiempo editorial o medido del audio
return <AbsoluteFill>
  <SceneRenderer state={visual} />
  <Caption cue={caption} />
</AbsoluteFill>;
```

`Caption` aplica el estilo de pregunta únicamente al primer intervalo y luego deja de mostrarla; no existe una capa global `Title`. `sampleScenesAtFrame` es determinista y no acumula estado del cuadro anterior: el renderer puede pedir cuadros fuera de orden. Compartir poses explícitas en las uniones y convertir relojes locales al global cuando sea necesario. Las transiciones no deben cambiar accidentalmente la duración total.

## HyperFrames e integración

Usar timeline pausada registrada, assets locales e IDs estables. Animar desde valores conocidos; evitar `.from()` repetidos que restablecen objetos por subtítulo. Un clip puede desarrollar varias acciones, con subtítulos en Remotion por encima. No usar timers ni aleatoriedad sin semilla.

Al pasar de HyperFrames a SVG/React o a otra escena, igualar pose, fondo, escala y cámara de la referencia compartida; comprobar la unión. Usar ambas herramientas no obliga a alternarlas por frase. La plantilla histórica requiere adaptación: conserva escenas fragmentadas y un h1 durante las partes; no demuestra esta arquitectura.

## Voz y revisión

Voz configurable. Si se pide: español rioplatense natural, cálido y acogedor; medir la grabación y ajustar subtítulos y acciones a sus frases y pausas. Sin audio, los tiempos sirven para lectura; no afirmar sincronización con una voz inexistente.

Revisar en movimiento si es posible. Si solo hay extracción de cuadros, muestrear cada 3 cuadros durante medio segundo a cada lado de todas las uniones, además de principio/mitad/final de cada escena y salida de la pregunta. Declarar esa limitación. La diferencia entre píxeles y un render a 30 FPS no certifican fluidez. Aplicar los controles del archivo 05.
