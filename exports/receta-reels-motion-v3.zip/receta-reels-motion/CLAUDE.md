# Instrucciones para Claude Code — v3

Leer y aplicar `AGENTS.md`, `00-EMPEZA-ACA.md`, el brief y las guías 02, 03, 05 y 07. El pedido explícito del usuario prevalece; una tarea de documentación no autoriza a generar un video.

Base: 2–4 escenas distintas conectadas, varios pulsos y subtítulos por escena, pregunta inicial como único subtítulo grande durante 2–4 s. Sin título permanente, encabezado ni marca fija. Una CTA en los últimos 3 s. Voz configurable; si se solicita, español rioplatense natural, cálido y acogedor, con acciones y subtítulos ajustados al audio real.

Revisar `ejemplos/05-bluetooth-4-escenas-40s.md`. La plantilla técnica antigua conserva montaje fragmentado y encabezados, pendientes de adaptación; no representa el estilo actualizado. Las skills se instalan localmente según la guía 06; leer sus SKILL.md y no confundir instalación con uso verificado. Preservar archivos y entregar evidencia real.
