# Puerta de aceptación v3 — para futuros videos

Esta lista se completa al producir un video. Las casillas vacías no significan pruebas ejecutadas en esta actualización documental.

## Escenas y continuidad

- [ ] Se identifican 2–4 escenas diferentes en unos 40 s, cada una con varias acciones; no se exige un único escenario.
- [ ] El guion separa escenas visuales, pulsos narrativos y subtítulos. Un cambio de frase no reinicia objetos.
- [ ] Cada unión tiene estado de salida, referencia compartida, recorrido y estado de llegada documentados.
- [ ] Las escenas se conectan siguiendo una pieza/dato/acción, acercándose al interior o revelando contexto; no son placas unidas solo con fundidos.
- [ ] No hay saltos repentinos de posición, escala o dirección ni reinicios del dibujo.
- [ ] Se revisaron secuencias densas de cuadros a ambos lados de cada unión y cambios de encuadre; registrar tiempos y evidencia.
- [ ] Hay acciones causales y detalles relevantes dentro de cada escena, con pausas de lectura.
- [ ] La única CTA ocupa los últimos 3 s dentro de la escena final.

## Pregunta y ausencia de título permanente

- [ ] La pregunta principal es el primer subtítulo y aparece una sola vez; no está duplicada arriba/abajo.
- [ ] Dura aproximadamente 2–4 s, se lee a tamaño de celular y usa 64–84 px como referencia si necesita mayor tamaño.
- [ ] Su salida es suave y ya no aparece al comenzar el desarrollo. Revisar antes, durante y después de la salida.
- [ ] Muestras del desarrollo y cierre confirman ausencia de título, marca o nombre de sección fijo.
- [ ] Solo hay subtítulos y etiquetas breves necesarias; estas últimas acompañan objetos, no encabezan todo el video.
- [ ] El gráfico aprovecha el espacio liberado; pregunta, objetos y subtítulos respetan márgenes seguros y no se superponen.
- [ ] No aparecen números de escena o slide; los IDs del storyboard son internos.

Si solo se revisaron secuencias de fotogramas, declarar el límite; no afirmar reproducción completa ni fluidez certificada. Cambios de píxeles, duración y FPS no prueban estas condiciones.

# Lista de entrega: registrar evidencia real

## Historia y exactitud

- [ ] La pregunta del hook se entiende durante sus 2–4 segundos iniciales.
- [ ] El cuerpo explica una cadena causal coherente y una sola idea principal.
- [ ] El microgancho tiene respuesta; el payoff aparece antes de la CTA.
- [ ] Las afirmaciones tienen fuentes; condiciones y excepciones importantes están claras.
- [ ] Hay una CTA legible en los últimos 3 segundos.

## Imagen y movimiento

- [ ] El objeto explicativo cambia dentro de cada escena; el movimiento no se limita al texto o una barra de progreso.
- [ ] Se revisaron cuadros del principio, mitad y final de cada escena y los cortes problemáticos.
- [ ] No hay números de slide ni logos ajenos.
- [ ] No hay texto cortado, demasiado pequeño o tapado por otras capas.
- [ ] Los subtítulos tienen máximo dos líneas, tiempo de lectura y contraste suficiente.
- [ ] Los elementos esenciales respetan la zona segura elegida.
- [ ] Las escalas, flechas, trayectorias y etiquetas del diagrama no inducen errores.
- [ ] La CTA forma parte de la duración total.

## Archivo final

Medir el MP4 que se va a entregar, no solo la composición ni un máster anterior.

```bash
ffprobe -v error -count_frames -show_streams -show_format -of json video-final.mp4
ffmpeg -v error -xerror -i video-final.mp4 -f null -
```

Comprobar: video H.264, 1080 × 1920, 30 FPS constantes, yuv420p, duración pedida y número de cuadros. Para 40 segundos: **1200 cuadros** y **40.000 s**. Si se pidió silencio, la lista de streams no debe contener audio. Un audio con volumen cero no equivale a ausencia de pista.

En el proyecto de ejemplo, `npm run verify` ejecuta comprobaciones técnicas y escribe el informe indicado en su README. Un proceso con salida 0 no prueba que el guion sea bueno: la revisión editorial y visual se registra aparte.

## Texto y sonido

- [ ] SRT y subtítulos incrustados tienen el mismo texto y los mismos intervalos.
- [ ] No se promete sincronización con una voz que todavía no se grabó.
- [ ] Si hay voz, usa español rioplatense natural, cálido y acogedor; subtítulos y acciones corresponden a tiempos medidos del audio real. Registrar por separado alineación técnica y escucha humana.
- [ ] Si hay audio, se registraron licencias, niveles y cualquier limitación de escucha.

## Entrega

- [ ] MP4 reproducible, guion, SRT, código, fuentes factuales y licencias.
- [ ] Sin dependencias pesadas, cachés ni credenciales dentro del ZIP.
- [ ] ZIP extraído y comprobado; no basta con que exista.
- [ ] Un enlace de descarga real o un adjunto del cliente; no inventar rutas publicadas.
- [ ] No publicar ni hacer push sin autorización.

En `VERIFICACION.md`, separar **pasó**, **falló** y **no ejecutado**. Explicar cómo se midió cada afirmación importante.
