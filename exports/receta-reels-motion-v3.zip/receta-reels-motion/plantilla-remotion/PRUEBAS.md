> **Resultados históricos de la demo original, no ejecutados en v3.** No validan la nueva dirección. El código conserva montaje fragmentado y encabezados durante las partes, pendientes de adaptación. El ZIP v3 no incluye el render final antiguo.

# Comprobaciones de la plantilla

Fecha: 29 de octubre de 2026. Plataforma comprobada: Linux; Node.js 24.19.0, npm 11.9.0, Chromium del sistema y FFmpeg/FFprobe 7.1.5.

## Pruebas ejecutadas

- `npm ci`: instalación desde el lockfile del proyecto Remotion, exit 0.
- `npm run check`: TypeScript sin errores; 14 partes, identificadores únicos, textos presentes y suma de 1200 cuadros.
- Verificación de los 14 campos `highlight`: cada uno coincide con un fragmento de su subtítulo.
- `REMOTION_BROWSER_EXECUTABLE=/usr/bin/chromium npm run render`: render completo de la demo, exportación final y validación, exit 0.
- FFprobe y decodificación completa con FFmpeg: 1080 × 1920, H.264, yuv420p, 30 FPS, 1200 cuadros, 40.000 segundos y ninguna pista de audio.
- En `hyperframes/`, `npm ci`: instalación desde lockfile y copia de GSAP a assets locales, exit 0.
- En `hyperframes/`, `npm run check`: lint, runtime y layout sin errores ni advertencias; navegador ejecutado. El chequeo del clip no evalúa subtítulos porque el clip no tiene texto. El chequeo de movimiento de HyperFrames figura desactivado; no se presenta como una prueba de movimiento superada.

- `npm run review`: generada y revisada visualmente la hoja `out/revision.jpg`, un cuadro de cada parte; sin números de slide y con palabras clave amarillas.
- `npm run verify:motion`: las 14 partes muestran cambios entre dos muestras de la región central del diagrama. Resultado en `out/movimiento.json`. Esta prueba detecta cambio entre muestras, no continuidad ni fluidez.

## Entrega comprobada

- Video: `out/reel.mp4`.
- Tamaño: 2,360,543 bytes.
- SHA-256: `66ad7205b9f10380cbe071dcb56c6826af4ffe2c50c95b067774c51fbeaf17a9`.
- Evidencia técnica: `out/verificacion.json`.
- El cierre ocupa 37–40 s y muestra «Compartilo con un amigo curioso».

## Alcance

Los scripts usan rutas portátiles y una variable opcional para el navegador. Se ejecutaron en Linux; Windows y macOS no se probaron en esta sesión. El clip de HyperFrames incluido proviene del proyecto anterior; en este kit se comprobó el HTML y se renderizó su integración en Remotion, sin volver a renderizar ese clip por separado. HyperFrames avisó que no pudo guardar el historial en el home de solo lectura; el chequeo sí terminó correctamente.

El video es una demo sobre gasificación. Para un tema distinto hace falta adaptar el guion y los diagramas; reemplazar textos no produce automáticamente una explicación nueva.
