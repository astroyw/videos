import {parts,totalFrames} from './common.mjs';
if(parts.length!==14) throw new Error('Esta demo tiene 14 diagramas. Si cambiás la cantidad, adaptá Visual en src/Reel.tsx.');
const ids=new Set();
for(const part of parts) {
  if(!part.id||ids.has(part.id)) throw new Error('Cada parte necesita un id único.');
  ids.add(part.id);
  if(!Number.isInteger(part.frames)||part.frames<12) throw new Error(`Duración inválida: ${part.id}`);
  for(const key of ['title','accent','caption']) if(typeof part[key]!=='string'||!part[key].trim()) throw new Error(`Falta ${key} en ${part.id}`);
}
if(totalFrames!==1200) throw new Error(`La demo debe sumar 1200 frames (40 s), suma ${totalFrames}. Si querés otra duración, cambiá esta validación de forma explícita.`);
if(parts[6].frames>180) throw new Error('El clip molecular dura 180 frames. Regeneralo si querés extender esta parte.');
console.log('PASS: 14 partes, ids únicos, textos presentes y 1200 frames (40 s).');
