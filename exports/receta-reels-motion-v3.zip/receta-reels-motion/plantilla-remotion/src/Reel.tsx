import React from 'react';
import {AbsoluteFill, Sequence, OffthreadVideo, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {C,p,Molecule,Defs,Bottle,Stage} from './visuals';
import parts from './storyboard.json';

const Label=({x,y,text,color=C.muted,size=30}:{x:number;y:number;text:string;color?:string;size?:number})=><text x={x} y={y} fill={color} fontSize={size} fontWeight="650" textAnchor="middle">{text}</text>;
const Pressure=({f,rising}:{f:number;rising:boolean})=>{
 const v=rising?p(f,0,55):1-p(f,0,40);
 return <g transform="translate(450 270)"><path d="M-170 100A200 200 0 1 1 170 100" fill="none" stroke="#424849" strokeWidth="22" strokeLinecap="round"/>
 <path d="M-170 100A200 200 0 1 1 170 100" fill="none" stroke={rising?C.yellow:C.red} strokeWidth="9" strokeDasharray={`${v*1040} 2000`} strokeLinecap="round"/>
 <g transform={`rotate(${-120+v*240})`}><path d="M0 0V-145" stroke={C.white} strokeWidth="6" strokeLinecap="round"/></g><circle r="17" fill={C.white}/>
 <Label x={0} y={130} text={rising?'PRESIÓN ↑':'PRESIÓN ↓'} color={rising?C.yellow:C.red} size={43}/></g>;
};
const Nucleation=({f,mode}:{f:number;mode:'start'|'grow'|'rise'})=>{
 const age=mode==='start'?f/90:mode==='grow'?1+f/60:3+f/60;
 return <>
 <rect x="70" y="40" width="750" height="520" rx="30" fill="#213231"/>
 <path d="M135 50V445l15 12-15 13v90" stroke="#9db7b2" strokeWidth="3" fill="none"/>
 {mode!=='rise'&&<>
 <circle cx={158+age*10} cy={450-age*9} r={5+age*25} fill="url(#bubble)" stroke="#d5efea" strokeWidth="2"/>
 {[0,1,2,3,4,5].map(i=>{const a=i*Math.PI/3;const distance=145-(f%50)*1.4;return <g key={i} opacity={mode==='grow'?.8:.25}><Molecule x={190+Math.cos(a)*distance} y={405+Math.sin(a)*distance} scale={.11} angle={i*60}/></g>})}
 <Label x={480} y={210} text={mode==='start'?'Una irregularidad…':'…facilita que se junten.'} color={C.white} size={36}/>
 <path d="M245 390 350 270" fill="none" stroke={C.yellow} strokeWidth="2"/>
 </>}
 {mode==='rise'&&Array.from({length:18},(_,i)=>{const t=((f+i*17)%(95+i%3*10))/(95+i%3*10);const x=180+i*32+Math.sin(i+t*5)*16;const y=530-t*460;const r=5+t*25;return <g key={i}><circle cx={x} cy={y} r={r} fill="url(#bubble)" stroke="#c9e9e4" strokeWidth="1.1"/><path d={`M${x-r*.5} ${y-r*.55}q${r*.4} ${-r*.3} ${r*.7} 0`} stroke={C.white} strokeWidth="1.3" fill="none"/></g>})}
 <Label x={450} y={620} text={mode==='start'?'Punto de nucleación':mode==='grow'?'CO₂ disuelto → burbuja de gas':'Las burbujas suben por flotación.'} color={mode==='rise'?C.muted:C.yellow} size={31}/>
 </>;
};

const Visual=({i}:{i:number})=>{
 const f=useCurrentFrame();
 return <>
 {i===0&&<Stage><Bottle f={f} open/></Stage>}
 {i===1&&<Stage><g transform="translate(-125 -60) scale(1.25)"><Bottle f={f+75} open/></g><Label x={665} y={190} text="El gas sale." color={C.yellow} size={37}/><path d="M620 215 570 155" stroke={C.yellow} strokeWidth="2"/></Stage>}
 {i===2&&<Stage><Molecule x={440} y={265} scale={1.85} angle={Math.sin(f/65)*9}/><Label x={440} y={445} text="dióxido de carbono" color={C.white} size={45}/><Label x={440} y={505} text="O=C=O · una molécula lineal" size={30}/></Stage>}
 {i===3&&<Stage>
 <rect x="140" y="80" width="620" height="450" rx="35" fill="#1d3039" stroke="#779caa" strokeWidth="2"/>
 <path d="M140 235H760" stroke="#95ccd2" strokeWidth="3"/>
 {[0,1,2,3,4,5,6,7,8,9].map(j=>{const t=((f+j*9)%90)/90;return <Molecule key={j} x={220+j*53} y={120+t*350} scale={.16} angle={j*27+f*.1}/>})}
 <Label x={450} y={592} text="CO₂ alimentario + bebida" color={C.yellow} size={36}/>
 </Stage>}
 {i===4&&<Stage>
 <rect x="175" y="75" width="100" height="340" rx="50" fill="#26363c" stroke="#8ab8c9" strokeWidth="3"/>
 <rect x="208" y={135+150*p(f,0,55)} width="34" height={310-(135+150*p(f,0,55))} rx="17" fill={C.blue}/><circle cx="225" cy="420" r="66" fill={C.blue}/>
 <Label x={560} y={220} text="MÁS FRÍA" color={C.blue} size={50}/><Label x={560} y={300} text="Más CO₂ puede" color={C.white} size={37}/><Label x={560} y={352} text="quedar disuelto." color={C.white} size={37}/>
 <Label x={450} y={580} text="A igual presión de CO₂" size={30}/>
 </Stage>}
 {i===5&&<Stage><Pressure f={f} rising/><Label x={450} y={550} text="Más presión de CO₂…" color={C.white} size={39}/><Label x={450} y={605} text="…favorece su disolución." size={33}/></Stage>}
 {i===6&&<><OffthreadVideo muted src={staticFile('gasificacion/molecular.mp4')} style={{position:'absolute',inset:0,width:1080,height:1920}}/><div style={{position:'absolute',left:120,top:1080,fontSize:27,color:C.muted}}>CO₂ entre moléculas de agua · esquema ampliado</div></>}
 {i===7&&<Stage><Bottle f={f} fill={.25+.75*p(f,0,65)} cap={0}/><path d="M450 20V285" stroke={C.yellow} strokeWidth="12" strokeDasharray="12 9" strokeDashoffset={-f*2}/><Label x={690} y={210} text="A presión" color={C.yellow} size={34}/><Label x={450} y={635} text="Llenado a contrapresión" size={32}/></Stage>}
 {i===8&&<Stage><Bottle f={f} cap={p(f,0,24)}/><path d="M630 170 530 95" stroke={C.yellow} strokeWidth="2"/><Label x={690} y={180} text="SELLADA" color={C.yellow} size={34}/><Label x={450} y={635} text="El envase conserva la presión." size={31}/></Stage>}
 {i===9&&<Stage><g transform="translate(-125 0) scale(.83)"><Bottle f={f} open/></g><g transform="translate(350 70) scale(.63)"><Pressure f={f} rising={false}/></g><Label x={450} y={635} text="Al abrir, baja la presión." color={C.red} size={36}/></Stage>}
 {i===10&&<Stage><Nucleation f={f} mode="start"/></Stage>}
 {i===11&&<Stage><Nucleation f={f} mode="grow"/></Stage>}
 {i===12&&<Stage><Nucleation f={f} mode="rise"/></Stage>}
 {i===13&&<Stage><g transform={`translate(440 300) scale(${1+.1*p(f,0,50)})`}><circle r="190" fill="url(#bubble)" stroke="#dae9df" strokeWidth="2"/><path d="M-110-130Q-30-175 55-155" stroke="#e9f5e8" strokeWidth="5" strokeLinecap="round" fill="none"/><Molecule x={0} y={0} scale={.8} angle={f*.13}/></g></Stage>}
 </>;
};
const CaptionText=({text,highlight}:{text:string;highlight:string})=>{
 const at=text.indexOf(highlight);
 if(!highlight||at<0)return <>{text}</>;
 return <>{text.slice(0,at)}<span style={{color:C.yellow}}>{highlight}</span>{text.slice(at+highlight.length)}</>;
};
const Shot=({i}:{i:number})=>{
 const f=useCurrentFrame(),s=parts[i];
 const fade=i===13?0:p(f,s.frames-5,s.frames-1);
 return <AbsoluteFill style={{opacity:1-fade,filter:`blur(${fade*5}px)`}}>
 <Visual i={i}/>
 <h1 style={{position:'absolute',left:100,top:265,width:810,margin:0,fontSize:64,lineHeight:1.12,letterSpacing:-2,fontWeight:800,color:C.white}}>{s.title}<br/><span style={{color:i>=9&&i<=11?C.red:C.yellow}}>{s.accent}</span></h1>
 <div style={{position:'absolute',left:100,top:1160,width:780,textAlign:'center',fontSize:47,lineHeight:1.27,fontWeight:700,letterSpacing:-.8,color:C.white,textWrap:'balance'}}><CaptionText text={s.caption} highlight={s.highlight}/></div>
 </AbsoluteFill>;
};
export const Carbonation40=()=>{
 const f=useCurrentFrame();const {durationInFrames}=useVideoConfig();let from=0;
 return <AbsoluteFill style={{background:C.bg,fontFamily:'Manrope, Arial, sans-serif',overflow:'hidden'}}>
 <style>{`@font-face{font-family:Manrope;src:url('${staticFile('gasificacion/Manrope.ttf')}');font-weight:200 800}`}</style>
 <AbsoluteFill style={{background:'radial-gradient(ellipse at 50% 42%,#292c2d 0%,#191a1b 68%)'}}/>
 {parts.map((part,i)=>{const start=from;from+=part.frames;return <Sequence key={part.id} from={start} durationInFrames={part.frames} name={part.id}><Shot i={i}/></Sequence>})}
 <div style={{position:'absolute',left:100,top:1330,width:780,height:3,background:'#393c3b'}}><div style={{height:'100%',width:`${f/(durationInFrames-1)*100}%`,background:C.yellow}}/></div>
 </AbsoluteFill>;
};
