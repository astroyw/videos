import React from 'react';
import {Composition, registerRoot} from 'remotion';
import {Carbonation40} from './Reel';
import parts from './storyboard.json';

const Root=()=> <Composition id="Reel" component={Carbonation40}
  width={1080} height={1920} fps={30}
  durationInFrames={parts.reduce((sum, part)=>sum+part.frames,0)}/>;
registerRoot(Root);
