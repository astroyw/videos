import React from 'react';
import {Easing, interpolate} from 'remotion';
export const C={bg:'#191a1b',white:'#f5f3eb',muted:'#acb0b1',yellow:'#ffd24a',red:'#ff6b61',blue:'#83c9e4'};
const ease=Easing.bezier(.16,1,.3,1);
export const p=(f:number,a:number,b:number)=>interpolate(f,[a,b],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp',easing:ease});
export const Molecule=({x=450,y=280,scale=1,angle=0}:{x?:number;y?:number;scale?:number;angle?:number})=><g transform={`translate(${x} ${y}) rotate(${angle}) scale(${scale})`}>
  <path d="M-84-7H84M-84 7H84" stroke="#b4b7b6" strokeWidth="5"/>
  <circle cx="-105" cy="0" r="49" fill="url(#oxygen)"/><circle r="43" fill="url(#carbon)"/><circle cx="105" cy="0" r="49" fill="url(#oxygen)"/>
  <text x="-105" y="14" textAnchor="middle" fontSize="38" fontWeight="700" fill="#451c1b">O</text><text y="14" textAnchor="middle" fontSize="36" fontWeight="700" fill="#2b2c2d">C</text><text x="105" y="14" textAnchor="middle" fontSize="38" fontWeight="700" fill="#451c1b">O</text>
</g>;
export const Defs=()=><defs>
  <radialGradient id="oxygen" cx="30%" cy="25%"><stop stopColor="#ffb5a9"/><stop offset=".55" stopColor={C.red}/><stop offset="1" stopColor="#9b352d"/></radialGradient>
  <radialGradient id="carbon" cx="30%" cy="25%"><stop stopColor="#fff"/><stop offset="1" stopColor="#909b9e"/></radialGradient>
  <linearGradient id="glass"><stop stopColor="#749195" stopOpacity=".17"/><stop offset=".2" stopColor="#b3e0e4" stopOpacity=".06"/><stop offset=".75" stopColor="#487181" stopOpacity=".12"/><stop offset="1" stopColor="#dcf5ef" stopOpacity=".26"/></linearGradient>
  <linearGradient id="liquid" x1="0" y1="0" x2="1" y2="1"><stop stopColor="#f4b34f" stopOpacity=".8"/><stop offset="1" stopColor="#815b22" stopOpacity=".65"/></linearGradient>
  <radialGradient id="bubble" cx="32%" cy="25%"><stop stopColor="#faf7e9" stopOpacity=".24"/><stop offset=".7" stopColor="#d2edeb" stopOpacity=".02"/><stop offset="1" stopColor="#e3e8da" stopOpacity=".55"/></radialGradient>
  <clipPath id="bottleClip"><path d="M390 90H510V195C510 237 570 250 570 310V565Q570 595 540 595H360Q330 595 330 565V310C330 250 390 237 390 195Z"/></clipPath>
</defs>;
export const Bottle=({f,open=false,fill=1,cap=1}:{f:number;open?:boolean;fill?:number;cap?:number})=>{
 const o=open?p(f,8,24):0;
 return <g>
 <ellipse cx="450" cy="612" rx="185" ry="18" fill="#000" opacity=".3"/>
 <path d="M390 90H510V195C510 237 570 250 570 310V565Q570 595 540 595H360Q330 595 330 565V310C330 250 390 237 390 195Z" fill="url(#glass)" stroke="#a6c2bf" strokeOpacity=".65" strokeWidth="3"/>
 <g clipPath="url(#bottleClip)"><rect x="330" y={595-310*fill} width="240" height={310*fill} fill="url(#liquid)"/><path d={`M330 ${595-310*fill}q60-8 120 0t120 0`} stroke="#f4d38b" strokeWidth="3" fill="none"/>
 {Array.from({length:open?23:12},(_,i)=>{const t=(f/30*(open?80:8)+i*37)%270;return open?<circle key={i} cx={350+(i*47%195)} cy={570-t} r={2+t*.023} fill="url(#bubble)" stroke="#fbefc5" strokeWidth=".7" opacity={o*.8}/>:<g key={i} opacity=".45" transform={`translate(${355+i*41%180+Math.sin(f*.035+i)*5} ${350+i*43%210+Math.cos(f*.03+i)*5})`}><circle r="2" fill="#eee5cc"/></g>})}
 </g>
 <path d="M350 330V555" stroke="#d8ede5" strokeOpacity=".27" strokeWidth="8" strokeLinecap="round"/>
 <g opacity={cap} transform={`translate(${o*210} ${-o*50-(1-cap)*60}) rotate(${o*32} 450 85)`}><rect x="382" y="65" width="136" height="37" rx="8" fill={C.red}/>{[0,1,2,3,4,5,6,7].map(i=><path key={i} d={`M${390+i*16} 72v24`} stroke="#8f302a" strokeWidth="2"/>)}</g>
 {open&&Array.from({length:13},(_,i)=>{const t=Math.max(0,f-10-i*2);return <circle key={i} cx={410+i*7+Math.sin(i*2)*t*.7} cy={80-t*3.2} r={3+t*.1} fill="#e4f0ed" opacity={Math.max(0,.65-t/60)*o}/>})}
 </g>
};
export const Stage=({children}:{children:React.ReactNode})=><svg width="900" height="650" viewBox="0 0 900 650" style={{position:'absolute',left:40,top:450}}><Defs/>{children}</svg>;
