import {copyFileSync,mkdirSync} from 'node:fs';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);
mkdirSync(new URL('assets/',import.meta.url),{recursive:true});
copyFileSync(require.resolve('gsap/dist/gsap.min.js'),new URL('assets/gsap.min.js',import.meta.url));
console.log('GSAP disponible localmente en assets/gsap.min.js');
