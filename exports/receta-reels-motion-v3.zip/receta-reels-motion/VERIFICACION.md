# Verificación de la actualización v3

Fecha: 29 de octubre de 2026. Alcance: documentación, ejemplos editoriales y empaquetado. No se generó ni renderizó otro video.

## Comprobaciones de esta entrega

- Prompt Markdown y TXT idénticos.
- Tres CSV: intervalos contiguos de 0 a 1200 cuadros, cuatro escenas por ejemplo, IDs de subtítulo únicos, primera pregunta de 3 s y CTA final de 37 a 40 s.
- Coherencia editorial revisada: 2–4 escenas diferentes, pregunta solo inicial, sin encabezados fijos y voz configurable. Las reglas anteriores incompatibles fueron reemplazadas en documentos activos; CAMBIOS-V2.md permanece como historia.
- Integridad ZIP: CRC, extracción a carpeta independiente, rutas seguras y hashes SHA-256 de todos los archivos del manifiesto. El informe externo de entrega registra recuentos y hash del ZIP.
- Preservación: comparación de los hashes de código, dependencias, assets y scripts de la plantilla con el paquete v2. Se conservaron todos sus archivos; solo se actualizaron sus cuatro documentos de advertencia.
- El paquete no incluye node_modules, cachés ni renders finales antiguos.

## No ejecutado / pendiente

No se reinstalaron dependencias, ejecutaron motores de render, generaron voces ni reprodujeron videos nuevos en v3. La plantilla antigua necesita adaptar sus 14 Shot y títulos superiores. Los ejemplos nuevos son planes editoriales, no implementaciones verificadas. La fluidez, la legibilidad final y la sincronización con voz se deben probar al producir el siguiente video.

Las siguientes pruebas son un **registro histórico de la versión original**; no se ejecutaron de nuevo y no validan la dirección v3. Sus rutas de salida se refieren a aquella demo, cuyos renders finales no se incluyen en este ZIP.

---

# Verificación del paquete

Fecha: 29 de octubre de 2026. Entorno de pruebas: Linux, Node.js 24.19.0, npm 11.9.0, Chromium y FFmpeg/FFprobe 7.1.5.

## Pasó

- Prompt en Markdown y TXT: contenido idéntico; los valores editados del brief tienen prioridad sobre los valores iniciales.
- CSV editorial: 14 intervalos contiguos, 40 segundos, 1200 cuadros y CTA entre 37 y 40 segundos.
- Demo ejecutable: instalación con `npm ci`, TypeScript y validación de storyboard sin errores.
- HyperFrames: instalación desde lockfile y check del HTML incluido. Detalles y límites en `plantilla-remotion/PRUEBAS.md`.
- Render completo de la demo: 1080×1920, H.264, yuv420p, 30 FPS, 1200 cuadros, 40.000 segundos y ausencia de pista de audio. Decodificación completa sin errores.
- Inspección visual de una muestra de cada una de las 14 partes: subtítulos, palabras destacadas, diagramas, CTA y ausencia de números de slide.
- Muestreo de movimiento del diagrama: cambios detectados en las 14 partes. No equivale a una certificación automática de fluidez o exactitud científica.
- Prueba desde una extracción del ZIP en otra carpeta fuera del repositorio: `npm ci`, `npm run check` y `npm run verify` pasaron. Se renderizaron además 30 cuadros nuevos del segmento molecular, a escala reducida, para comprobar fuentes, medios y rutas del paquete extraído.
- Integridad del ZIP comprobada mediante CRC y hashes SHA-256 de sus contenidos, listados en `MANIFEST.sha256`.

## Alcance y pendientes para cada video nuevo

- Windows y macOS tienen instrucciones de configuración, pero no se ejecutaron pruebas en esos sistemas.
- Las skills oficiales no se incluyen redistribuidas: se instalan con los comandos de la guía. No es un paquete de instalación sin conexión.
- Se revisaron dos videos de referencia. El tercero excede el límite de transferencia; ver `REFERENCIAS.md`.
- El ejemplo es una demostración, no una simulación física cuantitativa. Para un nuevo tema se deben investigar y registrar las fuentes factuales, adaptar los diagramas y repetir la revisión.
- La plantilla usa un clip HyperFrames ya renderizado; se comprobó su código y su integración en el render nuevo. No se volvió a renderizar el clip por separado en esta preparación.
- Los MP4 originales de referencia, sus logos y sus audios no están dentro del paquete.
- El kit no configura publicaciones automáticas en redes ni promete resultados de alcance.
