# PROMPT EDITABLE — copiá desde acá

Quiero que produzcas un video educativo con motion graphics para Instagram Reels, YouTube Shorts y TikTok. Ejecutá el trabajo hasta entregar un MP4 renderizado y verificado, con sus fuentes editables. No te detengas en una propuesta o en imágenes de muestra.

## 1. Mi brief — EDITÁ ESTOS CAMPOS

TEMA: [Cómo se gasifican las bebidas]
IDEA_QUE_DEBE_ENTENDERSE: [El CO₂ se disuelve mejor en líquido frío bajo presión; al abrir, la presión baja y aparecen burbujas.]
PUBLICO: [Personas curiosas, sin conocimientos técnicos previos]
DURACION_SEGUNDOS: [40]
PULSOS_NARRATIVOS: [14 ideas o avances del guion; NO equivalen a planos ni cortes]
ESCENAS_VISUALES: [4; elegir entre 2 y 4 escenas distintas para unos 40 segundos]
TRANSICIONES: [Movimientos motivados que conectan el resultado de una escena con la siguiente; evitar cortes bruscos]
CONTINUIDAD: [Varias acciones por escena, objetos estables durante esas acciones y continuidad de una pieza, dato o acción entre escenas; sin exigir un único escenario]
IDIOMA_Y_TONO: [Español rioplatense, cercano, claro, preciso; usar vos, mirá, pensá]
HOOK: [Usar la pregunta principal como primer subtítulo, acompañada del fenómeno desde el inicio]
PREGUNTA_PRINCIPAL: [¿Cómo llegó ese gas a la bebida?]
GIRO_O_DETALLE_SORPRENDENTE: [Cuando está disuelto, el CO₂ no está formando burbujitas visibles]
CTA_UNICA: [Compartíselo a ese amigo curioso.]
PREGUNTA_TAMANO_PX: [72; referencia 64–84 para 1080×1920]
PREGUNTA_DURACION_SEGUNDOS: [3; referencia 2–4 según extensión]
TITULO_O_ENCABEZADO_PERMANENTE: [NO; tampoco marca o nombre de sección fijo]
VOZ: [NO; cambiar a SI si querés narración]
DIRECCION_DE_VOZ: [Español rioplatense natural, cálido y acogedor; género/timbre configurable]
MUSICA_Y_EFECTOS: [NO; si VOZ=SI conservar la narración; si ambos son NO entregar sin pista de audio]
SUBTITULOS: [Incrustados y archivo SRT separado]
FUENTES_O_DATOS_OBLIGATORIOS: [Investigar fuentes fiables y registrar sus enlaces]
REFERENCIAS_VISUALES: [Los videos que adjunto y la guía visual de este kit, si está disponible]
RESTRICCIONES_DEL_TEMA: [Evitar afirmaciones absolutas cuando haya excepciones relevantes]

Los corchetes delimitan valores editables: no deben aparecer en pantalla. Si algo opcional falta, usá una decisión razonable y registrala. Preguntá solo si falta un dato imprescindible. No dependas de una aprobación intermedia del guion para renderizar: este pedido ya solicita la entrega final.

## 2. Estructura narrativa obligatoria

- **Hook:** la pregunta principal como primer subtítulo durante aproximadamente 2–4 segundos. Puede ser mayor que los siguientes (64–84 px); retirarla suavemente al comenzar la explicación. No duplicarla arriba como título. Mostrar el objeto o fenómeno desde el primer cuadro útil.
- **Promesa abierta:** dejar claro qué pregunta se va a resolver. No esconder todo el valor hasta el final.
- **Cuerpo:** explicar una sola cadena causal. Cada pulso aporta una idea y una acción visible. Varios pulsos y subtítulos conviven en cada escena; una escena desarrolla varias acciones.
- **Retención:** en la mitad, introducir una comparación, una predicción o un detalle que cambie cómo se entiende el fenómeno. Después mostrar su respuesta. No usar «esperá al final» como recurso vacío.
- **Payoff:** resolver la pregunta inicial de forma visual y con una frase breve antes del cierre.
- **CTA:** reservar los últimos 3 segundos para UNA acción de `CTA_UNICA`, relacionada con el tema. Mantener el objeto o diagrama en movimiento suave. No pedir compartir, seguir y dar like a la vez.

Con los valores iniciales, desarrollá 14 pulsos narrativos en 40 segundos, distribuidos en 2–4 escenas visuales diferentes conectadas con fluidez. La suma debe dar **1200 fotogramas a 30 FPS**. Las divisiones sirven para escribir el guion y los subtítulos; no obligan a cambiar de plano. No crees 14 composiciones que desaparecen y vuelven a aparecer. Si edito duración o cantidad, respetá el brief y recalculá el tiempo conservando 3 segundos para la CTA.

**Prioridad de esta versión: continuidad y animación del mecanismo.** Quiero ver un objeto que se construye, se mueve, cambia o se desarma de forma comprensible a lo largo del video. Evitá «entra dibujo, queda quieto, corte, entra otro dibujo». Un fundido entre placas no resuelve este problema. Conservá posición, escala, identidad y estado entre acciones, o mostrá el recorrido que los cambia. Diseñá el enlace antes de animar: resultado final → objeto o acción que seguimos → encuadre de llegada. Evitá cortes bruscos. No impongas un único escenario durante todo el video; variá contextos y detalles conservando la orientación del espectador.

Planificá cambios significativos cada 1–3 segundos dentro de cada escena: piezas que avanzan, uniones que se completan, flechas que recorren un mecanismo, curvas que se trazan o acercamientos a un detalle. Variá el ritmo y dejá pausas de lectura. No sustituyas la animación del mecanismo por zoom constante, vibración, partículas decorativas o títulos flotantes. El subtítulo no debe activar una nueva escena.

## 3. Dirección visual

Quiero divulgación con diagramas animados, como los archivos adjuntos:

- Fondo carbón uniforme o con una viñeta muy sutil; base sugerida `#202123`.
- Texto blanco cálido `#F5F3EB`; palabras clave amarillas `#F6C945`.
- Rojo `#F05B59` para error, peligro o contraste; azul `#70BCE2` para frío, flujo o comparación; verde solo si representa una condición correcta.
- Un protagonista visual grande en el centro: objeto, corte esquemático, moléculas, carretera, flechas o gráfico que explique el tema.
- Ilustración vectorial limpia en SVG/Canvas. Volumen y sombras discretas, trazos consistentes. El gráfico debe tener movimiento causal: algo entra, cambia, se desplaza, se acumula o sale.
- Tipografía sans serif gruesa y legible. Subtítulos de 48–60 px sobre el lienzo de 1080 px, máximo dos líneas y preferentemente 4–9 palabras por bloque. Resaltar solo 1–2 palabras.
- La pregunta principal es el primer subtítulo: 64–84 px si entra cómodamente, 2–4 segundos y salida suave. Después, solamente subtítulos y etiquetas breves necesarias junto al mecanismo. Sin título permanente, encabezado fijo, marca ni nombre de sección. No repetir la pregunta en otra capa.
- Márgenes conservadores para elementos esenciales: x entre 90 y 900, y entre 240 y 1450. Poner subtítulos preferentemente entre y=1180 y y=1420. El fondo y las ilustraciones no esenciales pueden llegar al borde. Estos márgenes no reemplazan la revisión en la aplicación de destino.
- Mantener el objeto entre ideas; encadenar acciones y acercamientos con propósito. Usar movimientos de cámara suaves de unos 12–30 cuadros cuando la lectura lo permita, sin zoom permanente. No reintroducir un titular grande en cada frase. La CTA aparece integrada en la escena final. Aprovechá el espacio del antiguo título para ampliar la animación dentro de los márgenes seguros.
- Nada de números de slide, barras de navegador, tarjetas de dashboard, listas estáticas, emojis como ilustración principal, logos ajenos ni marcas de agua.

## 4. Tecnología y producción

Usá **Remotion** para composición, timing, tipografía, subtítulos y exportación. Usá **HyperFrames** para al menos un segmento animado útil, integrando su render local en Remotion. Guardá también el HTML/GSAP de ese segmento. No alcanza con instalar las skills y afirmar que se usaron ambas herramientas.

Si está disponible este kit, leé `02-RECETA-PARA-EL-AGENTE.md`, `03-GUIA-VISUAL.md`, `05-CONTROL-DE-CALIDAD.md` y el README de `plantilla-remotion/`. Leé además `07-CONTINUIDAD-Y-ANIMACION.md` y `ejemplos/03-ventana-continuidad-40s.md`: son obligatorios para la dirección actual. La plantilla antigua demuestra instalación y render; su montaje fragmentado y sus encabezados grandes durante las partes NO son el modelo visual aprobado. Código pendiente de adaptación a 2–4 escenas y pregunta solo inicial; no se presenta como ejemplo actualizado. Refactorizá su arquitectura antes de usarla para una nueva entrega.

Inspeccioná el repositorio y sus instrucciones antes de cambiarlo. Preservá su aplicación, dependencias y archivos. Creá una subcarpeta si hace falta. Verificá Node.js, npm, FFmpeg, FFprobe y navegador. Instalá las skills oficiales dentro del proyecto, preferentemente `.agents/skills`, y leé las pertinentes. Mantené todos los paquetes Remotion en la misma versión.

Animá de manera determinista con fotogramas en Remotion y una timeline pausada registrada en HyperFrames. Usá recursos y fuentes locales al renderizar. Conservá sus licencias. No inventes simulaciones científicas: si el diagrama es esquemático, indicálo cuando sea relevante y respetá el mecanismo real.

## 5. Texto y audio

Con `VOZ=NO`, no generes narración ni agregues una voz provisional. Con `VOZ=NO` y `MUSICA_Y_EFECTOS=NO`, el MP4 no debe tener ninguna pista de audio. Los subtítulos deben permitir entender el video por sí solos, con tiempo suficiente de lectura. Prepará el guion por intervalos para que yo pueda grabar mi voz después.

Si cambio el brief para pedir voz, usá español rioplatense natural, cálido y acogedor. Generá o usá el archivo autorizado, medí el audio real y sincronizá tanto subtítulos como acciones con sus frases y pausas. No afirmes sincronización por palabra si solo alineaste frases. No clones la voz del creador de las referencias. Si falta una capacidad de audio necesaria, informá el límite real.

## 6. Formato y control final

Entregá 1080 × 1920, 9:16, 30 FPS, MP4 H.264, yuv420p y duración exacta del brief. Con 40 segundos son 1200 cuadros. Usá metadatos de color coherentes y faststart para reproducción web.

Antes de entregar:

1. Comprobá el contenido factual y guardá fuentes y matices en `FUENTES.md`.
2. Ejecutá las verificaciones de código y `hyperframes check` cuando corresponda. Corregí errores; no cuentes auditorías sin muestras como aprobaciones visuales.
3. Revisá fotogramas decodificados del MP4 de cada escena y de los cortes. Verificá tamaño de texto, márgenes, continuidad, CTA y ausencia de números.
4. Revisá continuidad temporal: verificá 2–4 escenas con varias acciones cada una, sin saltos repentinos de posición/escala ni reinicios por subtítulo. Revisá que cada transición tenga una causa y un destino; no resolverlas todas con fundidos. Inspeccioná secuencias de cuadros antes, durante y después de las uniones. Dos cuadros diferentes no prueban fluidez. Rechazá el montaje si sigue pareciendo una sucesión de placas, aunque el codec, la duración y el movimiento medido pasen.
5. Comprobá que la pregunta inicial se lea a tamaño de celular, aparezca una sola vez durante 2–4 s y salga suavemente. Después no debe quedar ningún título, marca ni encabezado fijo; revisá también que no haya un duplicado de la pregunta.
6. Usá FFprobe para verificar resolución, codec, FPS, duración, cuadros y presencia o ausencia de audio. Decodificá el archivo completo con FFmpeg para detectar errores.
7. Si hay narración, revisá que corresponda con los subtítulos. Diferenciá mediciones técnicas de escucha humana.

Entregables: `video-final.mp4`, `subtitulos.srt`, `GUION.md` con tiempos, `FUENTES.md`, proyecto editable, assets utilizados y `VERIFICACION.md` con resultados reales. Entregá un enlace o adjunto que exista; no presentes una ruta interna como si fuera una descarga comprobada. No publiques en redes ni hagas push al repositorio sin mi autorización.
