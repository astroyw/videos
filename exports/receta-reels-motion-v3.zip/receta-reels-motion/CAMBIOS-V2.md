> **Registro histórico, reemplazado por CAMBIOS-V3.md.** Las menciones de escenario persistente y hasta dos cortes describen la v2; no son instrucciones vigentes. Se conserva este archivo para documentar la evolución.

# Qué cambió en la receta

- Se eliminó la equivalencia entre 14 ideas y 14 escenas visuales.
- El prompt ahora pide 14 pulsos dentro de 4 bloques conectados, con un escenario persistente.
- Se reemplazó la regla de cortar al cambiar de idea por continuidad de objetos y acciones causales.
- Se añadió un presupuesto editable de hasta 2 cortes bruscos en 40 segundos, preferentemente cero.
- Se exige más desarrollo de animación dentro de cada bloque, con pausas de lectura y cámara motivada.
- Los subtítulos tienen una pista independiente; no reinician el gráfico.
- Se agregó un ejemplo de la ventana con cuatro bloques, un CSV de continuidad y recomendaciones de implementación para Remotion y HyperFrames.
- La aceptación incluye revisar uniones y reinicios; medir movimiento en dos muestras ya no alcanza para aprobar el ritmo.
- La plantilla antigua queda identificada como referencia técnica. Su código no fue modificado y sus renders se excluyen del ZIP v2 para no presentarlos como demostración del estilo corregido.

Esta entrega solo actualiza la receta y su documentación. No se produjo otro video. Las instrucciones nuevas orientan futuras producciones; su resultado visual deberá verificarse cuando se haga el siguiente video.
