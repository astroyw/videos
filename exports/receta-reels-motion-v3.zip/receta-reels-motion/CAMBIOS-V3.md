# Qué cambió — receta v3

- Se reemplaza la exigencia de escenario único por 2–4 escenas distintas para unos 40 segundos, cada una con varias acciones. Se elimina el presupuesto que permitía hasta dos cortes bruscos.
- Se separan escenas visuales, pulsos narrativos y subtítulos. Se diseñan enlaces mediante piezas, datos, cámara y acciones compartidas; los fundidos no son la solución automática.
- La pregunta principal aparece solamente al comienzo como primer subtítulo: referencia 64–84 px, unos 2–4 s y salida suave. No se duplica.
- Se eliminan títulos permanentes, marcas y nombres de sección fijos. El espacio se usa para gráficos mayores; después solo subtítulos y etiquetas necesarias.
- Se mantienen base vertical 1080×1920, 30 FPS, unos 40 s, carbón/blanco/amarillo, márgenes seguros y una CTA durante los últimos 3 s.
- La voz sigue siendo configurable. Si se pide: español rioplatense natural, cálido y acogedor, con subtítulos y acciones sincronizados al audio real. Música y efectos se configuran por separado.
- Se actualizaron prompt MD/TXT, instrucciones, guías, ejemplos de gasificación y ventana, CSV, AGENTS.md y CLAUDE.md. Se agregaron ejemplo y CSV de Bluetooth en cuatro escenas enlazadas.
- Los controles ahora incluyen uniones, reinicios, salida y legibilidad de la pregunta, ausencia de encabezados y aprovechamiento del espacio.

## Preservado y pendiente

No se borraron archivos ni se creó otro video. La plantilla técnica mantiene su código, dependencias y assets: sus 14 Shot y títulos superiores durante las partes están **pendientes de adaptación**. README, AGENTS, CLAUDE y PRUEBAS la identifican como histórica; no se presenta como ejemplo del nuevo estilo. Los renders finales antiguos se excluyen de este ZIP, pero se preservan en su ubicación anterior.

CAMBIOS-V2.md y las pruebas antiguas se conservan como registros históricos claramente identificados. Los ZIP v1 y v2 se mantienen. La v3 valida documentación y empaquetado; no se probó visualmente un estilo de video nuevo. Ver VERIFICACION.md.
