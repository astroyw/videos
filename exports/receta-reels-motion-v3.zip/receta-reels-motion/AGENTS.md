# Instrucciones del kit — v3

Esta carpeta contiene una receta y una plantilla histórica. Leer `00-EMPEZA-ACA.md`, las guías 02, 03, 05 y 07. Ejecutar el prompt editable solo cuando el usuario pida producir un video. Si pide actualizar la receta, modificar documentación y empaquetar; no renderizar otro video.

- Prioridad a las instrucciones explícitas del usuario. Base editable: aproximadamente 40 s (40 exactos = 1200 cuadros), 1080×1920, 30 FPS, H.264, carbón/blanco/amarillo, subtítulos grandes y voz configurable.
- Elegir 2–4 escenas visuales diferentes; varias acciones y varios pulsos por escena. Separar escenas, pulsos narrativos y subtítulos. No imponer un único escenario.
- Conectar mediante pieza/dato/acción compartida, acercamiento al interior o revelación de contexto. Evitar cortes bruscos, reinicios y saltos de posición o escala; no resolver todo con fundidos.
- Pregunta principal solo como primer subtítulo, 2–4 s, referencia 64–84 px, salida suave. No duplicarla. Después, solo subtítulos y etiquetas necesarias: sin título permanente, marca ni encabezado fijo. Sin números de escena/slide.
- Ampliar animaciones en el espacio liberado y respetar márgenes seguros. Una única CTA integrada en la escena final durante los últimos 3 s.
- Si se pide voz: español rioplatense natural, cálido y acogedor; sincronizar acciones y subtítulos con el audio real. Silencio por defecto, sin narración provisional.
- Leer skills locales de Remotion y HyperFrames cuando se produzca un video. Usar ambas realmente, conservar fuentes HTML, assets y licencias. No copiar el montaje ni los encabezados de la plantilla histórica: están pendientes de adaptación.
- Validar uniones y salida de la pregunta visualmente; las pruebas de formato y movimiento no bastan para aprobar estilo. Verificar MP4 con FFprobe y decodificación completa cuando se produzca uno; declarar pruebas reales y pendientes.
- Preservar el proyecto y sus archivos. Integrar estas instrucciones sin reemplazar las de un repositorio ajeno. No borrar, publicar ni hacer push sin autorización. No inventar enlaces de entrega.
