# Versión 3 — escenas conectadas y pregunta solo al comienzo

Dirección vigente: **2–4 escenas distintas en unos 40 segundos**, unidas mediante acciones y cámara con sentido. Los pulsos y subtítulos no son escenas. La pregunta principal aparece solo al inicio como primer subtítulo; no queda título, marca ni encabezado fijo. Leer `07-CONTINUIDAD-Y-ANIMACION.md` y `ejemplos/05-bluetooth-4-escenas-40s.md` antes de programar. Esta entrega actualiza la receta; no genera otro video. Los renders antiguos no se incluyen en este ZIP para evitar confundirlos con una demostración de la nueva dirección.

# Tu receta para Reels, Shorts y TikTok

Este kit sirve para pedirle a **Claude Code o Codex** que investigue un tema, escriba el guion, construya motion graphics y entregue un MP4 real. La dirección visual está basada en los videos de referencia que pudimos inspeccionar: diagramas sobre fondo carbón, texto blanco, énfasis amarillo y animación que muestra causas y consecuencias.

## Lo que tenés que hacer

1. Descomprimí esta carpeta y abrila como proyecto en Claude Code o Codex. Si ya tenés un proyecto, agregala en una subcarpeta sin reemplazar sus archivos.
2. Abrí **01-PROMPT-EDITABLE.md**. Cambiá, como mínimo, `TEMA` y `IDEA_QUE_DEBE_ENTENDERSE`. Podés dejar los demás valores iniciales.
3. Pegá **todo el prompt** en el chat del agente. Si puede leer archivos, también podés decirle: «Leé `01-PROMPT-EDITABLE.md` y ejecutalo usando esta carpeta como receta».
4. El agente instala lo necesario, arma el guion y los diagramas, renderiza y comprueba el video. El prompt autoriza esa ejecución, no una publicación en redes ni un push a GitHub.
5. Recibí el MP4, los subtítulos SRT, el guion con tiempos y el código. Pedí cambios concretos: «agrandá el diagrama», «acortá el texto», «hacé más claro qué provoca qué».

**Configuración inicial:** aproximadamente 40 segundos (base: 40 exactos) · 14 pulsos orientativos dentro de 2–4 escenas conectadas · 1080 × 1920 · 30 FPS · H.264 · voz configurable (base sin audio) · subtítulos incrustados · sin números de slide · una llamada a la acción al final. Todo esto se puede editar en el prompt.

## Qué hay en el kit

| Archivo o carpeta | Para qué sirve |
| --- | --- |
| `01-PROMPT-EDITABLE.md` / `.txt` | Tu pedido completo, listo para copiar y adaptar. Ambos tienen el mismo contenido. |
| `02-RECETA-PARA-EL-AGENTE.md` | Procedimiento: investigar, escribir, diseñar, animar, renderizar y verificar. |
| `07-CONTINUIDAD-Y-ANIMACION.md` | Reglas obligatorias de continuidad, cámara y arquitectura. |
| `CAMBIOS-V3.md` | Cambios de esta entrega y pendientes técnicos. |
| `CAMBIOS-V2.md` | Registro histórico; no es la regla vigente. |
| `03-GUIA-VISUAL.md` | Colores, márgenes, tipografía, encuadres y movimiento. |
| `04-HOOKS-RETENCION-Y-CTA.md` | Fórmulas y ejemplos para abrir, sostener atención y cerrar. |
| `05-CONTROL-DE-CALIDAD.md` | Condiciones que debe cumplir la entrega. |
| `06-INSTALACION-Y-SKILLS.md` | Cómo preparar Remotion y HyperFrames con skills locales. |
| `ejemplos/` | Gasificación, ventana y Bluetooth; tablas que separan escenas, pulsos y subtítulos. |
| `plantilla-remotion/` | Ejemplo técnico antiguo de instalación/render; sus escenas separadas y encabezados durante las partes requieren adaptación; no es una demo de la versión 3. |
| `REFERENCIAS.md` | Qué referencias se revisaron y los límites del análisis. |
| `AGENTS.md` / `CLAUDE.md` | Instrucciones que ambos agentes pueden leer dentro de esta carpeta. |
| `VERIFICACION.md` | Pruebas efectivamente realizadas sobre este paquete. |

## Si solo querés copiar un mensaje

Usá `01-PROMPT-EDITABLE.md`: incluye las reglas esenciales aun si no adjuntás el resto del kit. Adjuntar la carpeta completa le da al agente una guía y un ejemplo que puede ejecutar.

La plantilla muestra un tema concreto, la gasificación. Cambiar sus textos **no genera automáticamente diagramas de otro tema**: el agente tiene que diseñarlos y programarlos. Tampoco una receta garantiza alcance o viralidad; sí fija criterios claros para producir y revisar el video.

Los MP4 originales de referencia no están incluidos. Podés guardarlos en una carpeta local `referencias/` si querés que el agente vuelva a inspeccionarlos. No se usan el logo, el nombre de usuario ni el audio de sus autores.
