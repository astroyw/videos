# Cómo funciona el Bluetooth — Reel continuo

40 segundos, 1080×1920, 30 FPS, H.264. Subtítulos en español, sin audio. Un escenario continuo con celular y auriculares; 14 pulsos de texto y cuatro bloques narrativos. No hay una escena nueva por frase ni números de slide.

## Ejecutar

Node.js 22+, npm, FFmpeg y FFprobe en PATH. Chrome/Chromium compatible con Remotion.

```bash
npm ci
npm run check
npm run studio
npm run render
```

Si hace falta, configurar `REMOTION_BROWSER_EXECUTABLE` con la ruta real del navegador. En Linux se probó `/usr/bin/chromium`. El script de render usa rutas relativas, exporta `out/reel.mp4`, genera SRT y comprueba duración, cuadros, resolución, ausencia de audio y decodificación completa.

## Arquitectura de continuidad

`hyperframes/index.html` dibuja un único mundo SVG mediante una timeline GSAP pausada de 40 segundos. El celular, los auriculares y el enlace tienen IDs persistentes. Su posición y estado dependen del tiempo global; los subtítulos no reinician esas animaciones.

El mundo se renderiza a `public/bluetooth/world.mp4` (1080×820, 40 s, sin audio). Remotion lo monta **una sola vez**, a tamaño nativo, dentro del lienzo de 1080×1920. Agrega título y subtítulos con un reloj independiente.

Para modificar la animación, entrar en `hyperframes`, ejecutar `npm ci`, `npm run check`, `npm run preview`, revisar y luego `npm run render`. Usar `HYPERFRAMES_BROWSER_PATH` si se necesita seleccionar Chromium. Los assets de GSAP se copian durante postinstall. No se usa CDN al renderizar.

`src/storyboard.json` controla texto, resaltados y duración de los subtítulos. Cambiarlo no cambia automáticamente la animación; al modificar tiempos hay que coordinar la timeline global del mundo visual. `src/index.tsx` fija 1200 cuadros a 30 FPS.

## Comprobaciones

`npm run review` genera una hoja del MP4; el script `scripts/verify-continuity.mjs` mide diferencias de cuadros consecutivos del área visual, sin subtítulos, y genera secuencias de revisión. Esas mediciones detectan anomalías, pero no certifican calidad narrativa ni fluidez. Revisar el movimiento y las uniones además de los metadatos.

En `documentacion/` se incluyen guion, alcance factual y verificación cuando se distribuye el ZIP. La fuente Manrope lleva su licencia SIL OFL. Remotion, React, HyperFrames y GSAP conservan sus licencias. Ilustraciones propias; no se incluyen voces, música ni logos de terceros.
