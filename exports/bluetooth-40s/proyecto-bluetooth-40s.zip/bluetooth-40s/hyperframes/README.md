# Mundo continuo de Bluetooth

Un único SVG, 40 segundos, 1080×820, 30 FPS. Remotion lo ubica a tamaño nativo dentro de 1080×1920 y agrega título y subtítulos. El tamaño de este segmento no es la resolución del Reel final.

```bash
npm ci
npm run check
npm run preview
npm run render
```

Salida: `../public/bluetooth/world.mp4`. Usar `HYPERFRAMES_BROWSER_PATH` con un Chrome/Chromium compatible si hace falta. En entornos con home no escribible, asignar `XDG_STATE_HOME` y `HYPERFRAMES_FONT_CACHE_DIR` a carpetas escribibles. No desactivar TLS ni cambiar credenciales del entorno.

La timeline pausada y el evento `hf-seek` llaman a `draw(t)`. Todos los estados se calculan desde el tiempo global. Los elementos `phone` y `headphones` permanecen montados; el esquema se despliega debajo de ellos. Los paquetes se desvanecen al entrar/salir del enlace, y los cambios adaptativos de ruta se asignan al inicio de un recorrido, sin teletransportar paquetes ya emitidos.

Los cinco canales y su temporización son ilustrativos. Las rutas no son una captura de radio ni una implementación del algoritmo Bluetooth. Ver `../documentacion/FUENTES.md`.

La búsqueda del registro por «frequency hopping» no devolvió una composición apropiada, por lo que se construyó un SVG propio. La fuente local Manrope incluye licencia SIL OFL. GSAP se copia durante postinstall; no hay descargas en el render.

Check ejecutado: lint/runtime/layout sin errores; auditoría de movimiento de 300 muestras y 15 comprobaciones de contraste aprobadas. Se revisaron capturas de estados y se renderizaron 1200 cuadros, 40 s y ninguna pista de audio. Estas pruebas técnicas no certifican la exactitud física ni la fluidez percibida; el montaje final tiene su propia revisión.

El CLI también permite editar con la aplicación de escritorio HyperFrames: https://hyperframes.dev/studio/download?os=linux. Su instalación es opcional para continuar con los archivos locales.
