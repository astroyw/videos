import React from 'react';
import {AbsoluteFill,OffthreadVideo,staticFile,useCurrentFrame} from 'remotion';
import parts from './storyboard.json';
const Caption=({text,highlight}:{text:string;highlight:string})=>{const i=text.indexOf(highlight);return <>{text.slice(0,i)}<span style={{color:'#F6C945'}}>{highlight}</span>{text.slice(i+highlight.length)}</>};
export const BluetoothReel=()=>{
 const frame=useCurrentFrame();let sum=0;
 const active=parts.find(p=>{const start=sum;sum+=p.frames;return frame>=start&&frame<sum;})??parts[parts.length-1];
 return <AbsoluteFill style={{background:'#202123',fontFamily:'Manrope,Arial,sans-serif',color:'#F5F3EB'}}>
 <style>{`@font-face{font-family:Manrope;src:url('${staticFile('bluetooth/Manrope.ttf')}');font-weight:200 800;}`}</style>
 <div style={{position:'absolute',zIndex:2,left:105,top:245,fontSize:25,letterSpacing:4,color:'#A7ABB0'}}>LA CIENCIA DE LO COTIDIANO</div>
 <h1 style={{position:'absolute',zIndex:2,left:100,top:295,fontSize:76,lineHeight:1.08,letterSpacing:-2,margin:0,fontWeight:800}}>Cómo funciona<br/><span style={{color:'#F6C945'}}>el Bluetooth.</span></h1>
 <OffthreadVideo muted src={staticFile('bluetooth/world.mp4')} style={{position:'absolute',left:0,top:420,width:1080,height:820,maskImage:'linear-gradient(to bottom, transparent, black 5%, black 94%, transparent)'}}/>
 <div style={{position:'absolute',left:100,top:1210,width:790,textAlign:'center',fontSize:51,lineHeight:1.25,fontWeight:750,textWrap:'balance'}}><Caption text={active.caption} highlight={active.highlight}/></div>
 </AbsoluteFill>;
};
