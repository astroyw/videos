import React from 'react';
import {Composition,registerRoot} from 'remotion';
import {BluetoothReel} from './Reel';
const Root=()=> <Composition id="Reel" component={BluetoothReel} width={1080} height={1920} fps={30} durationInFrames={1200}/>;
registerRoot(Root);
