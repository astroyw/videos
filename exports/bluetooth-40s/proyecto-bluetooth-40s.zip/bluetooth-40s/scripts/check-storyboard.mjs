import {parts,totalFrames} from './common.mjs';
if(totalFrames!==1200||parts.length!==14||parts.at(-1).frames!==90)throw new Error('Duración o CTA incorrecta.');
for(const p of parts)if(!Number.isInteger(p.frames)||!p.caption.includes(p.highlight))throw new Error('Texto o tiempo inválido.');
console.log('PASS: 14 subtítulos, 1200 cuadros. Mundo visual continuo e independiente.');
