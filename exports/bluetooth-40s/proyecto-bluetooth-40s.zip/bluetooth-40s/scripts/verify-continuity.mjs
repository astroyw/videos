import {writeFileSync,mkdirSync} from 'node:fs';
import path from 'node:path';
import {root,run,finalFile,parts} from './common.mjs';
// Exclude title and captions; inspect the persistent visual world only.
const raw=run('ffmpeg',['-v','error','-i',finalFile,'-vf','crop=1080:700:0:480,scale=108:70','-pix_fmt','gray','-f','rawvideo','-'],{encoding:null,maxBuffer:24*1024*1024});
const size=108*70,count=raw.length/size;
if(count!==1200)throw new Error('No se decodificaron 1200 cuadros para continuidad.');
const differences=[];
for(let f=1;f<count;f++){let sum=0;for(let i=0;i<size;i++)sum+=Math.abs(raw[f*size+i]-raw[(f-1)*size+i]);differences.push(sum/size);}
let start=0;const ranges=parts.map(p=>{const a=start;start+=p.frames;const values=differences.slice(a,start-1);return {id:p.id,fromFrame:a,toFrameExclusive:start,mean:values.reduce((s,v)=>s+v,0)/values.length,max:Math.max(...values)};});
const highest=differences.map((difference,i)=>({frame:i+1,difference})).sort((a,b)=>b.difference-a.difference).slice(0,12);
const report={method:'Diferencias absolutas medias entre cuadros consecutivos, área del mundo visual sin título ni subtítulos, reducida a108×70.',frames:count,hardCutsInEdit:0,maximumMeanAbsoluteDifference:Math.max(...differences),highest,ranges,limitation:'No certifica fluidez ni detecta todos los cortes; requiere revisión de secuencias. hardCutsInEdit describe el montaje de un clip continuo, no una clasificación automática.'};
writeFileSync(path.join(root,'out/continuidad.json'),JSON.stringify(report,null,2)+'\n');
const dir=path.join(root,'out/continuidad');mkdirSync(dir,{recursive:true});
for(const center of [12,14,18,21,25,30,33,37]){
 for(let i=0;i<9;i++){const t=center-.4+i*.1;run('ffmpeg',['-y','-v','error','-ss',t.toFixed(3),'-i',finalFile,'-frames:v','1','-vf','scale=216:384',path.join(dir,`${center}-${i}.jpg`)]);}
 run('ffmpeg',['-y','-v','error','-framerate','1','-i',path.join(dir,`${center}-%d.jpg`),'-vf','tile=9x1','-frames:v','1',path.join(root,`out/continuidad-${center}.jpg`)]);
}
console.log(`PASS: ${count} cuadros analizados. Pico de diferencia media: ${report.maximumMeanAbsoluteDifference.toFixed(3)} / 255. Revisar 8 tiras de continuidad.`);
