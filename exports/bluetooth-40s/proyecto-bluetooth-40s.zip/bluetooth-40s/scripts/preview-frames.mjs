import {bundle} from '@remotion/bundler';
import {selectComposition,renderStill} from '@remotion/renderer';
import {mkdirSync} from 'node:fs';
import path from 'node:path';
import {root,parts,run} from './common.mjs';
const dir=path.join(root,'out/preview');mkdirSync(dir,{recursive:true});
const serveUrl=await bundle({entryPoint:path.join(root,'src/index.tsx'),publicDir:path.join(root,'public')});
const browserExecutable=process.env.REMOTION_BROWSER_EXECUTABLE;
const composition=await selectComposition({serveUrl,id:'Reel',browserExecutable});
let start=0;
for(const [i,s] of parts.entries()){
 await renderStill({serveUrl,composition,browserExecutable,frame:start+Math.floor(s.frames/2),imageFormat:'jpeg',scale:.3,output:path.join(dir,`${String(i).padStart(2,'0')}.jpg`)});
 start+=s.frames;
}
run('ffmpeg',['-y','-v','error','-framerate','1','-i',path.join(dir,'%02d.jpg'),'-vf','tile=7x2','-frames:v','1',path.join(root,'out/preview.jpg')]);
console.log('Preview de 14 pulsos: out/preview.jpg');
