# Continuidad de este Reel

Leer README.md y SPEC.md. Preservar un único mundo visual: no dividir el HTML ni Remotion en una escena por subtítulo. Usar tiempo global y estados deterministas al solicitar cuadros fuera de orden.

Caso de audio Bluetooth explicado mediante celular y auriculares. Conservar matices de FUENTES.md; el esquema de canales no indica cantidades ni temporizaciones reales. Silencio total salvo nueva indicación del usuario.

Antes de entregar cambios: check de TypeScript y HyperFrames, revisión de capturas, render completo, verificación de codec/duración/audio, revisión temporal alrededor de movimientos y uniones. No declarar fluidez por una medición de píxeles. No publicar ni borrar archivos sin autorización.
