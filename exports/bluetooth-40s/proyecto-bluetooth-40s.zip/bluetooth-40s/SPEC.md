# Cómo funciona Bluetooth

40 s exactos, 1200 cuadros a 30 FPS, 1080×1920 H.264, silencio total. Fondo #202123; Manrope blanca, palabras amarillas; radio azul, coordinación verde, interferencia roja. Título literal «Cómo funciona Bluetooth». Sin numeración ni marcas ajenas.

Receta v2 confirmada por hash del ZIP recibido. Se construye un único mundo visual persistente: celular izquierdo y auriculares derechos. Los 14 subtítulos son una pista editorial independiente; no cambian de escena ni reinician el reloj. Cero cortes bruscos previstos.

Bloques conectados: 0–12 s radio/detección/conexión; 12–21 s audio→datos→paquetes; 21–30 s canales/interferencia/recepción; 30–40 s sonido/enlace local/CTA. El esquema de canales se despliega debajo de los mismos dispositivos; estos se desplazan y reducen suavemente para abrir espacio, y vuelven al concluir el detalle. No se reemplazan por otros dibujos.

HyperFrames: mundo SVG/GSAP continuo de 40 s, 1080×820, render real incorporado a tamaño nativo en Remotion. Remotion: composición 1080×1920, título, subtítulos, montaje, exportación. La posición de objetos depende exclusivamente del tiempo global, incluso al solicitar cuadros fuera de orden.

Exactitud: Bluetooth opera en 2,4 GHz; varios protocolos y perfiles existen. Se explica el caso de audio inalámbrico, sin generalizar un codec ni cantidad de canales. Cinco líneas ilustran canales; no son todos los canales de Bluetooth. Saltos y movimiento ralentizados con fines didácticos. La coordinación no implica transmisión y recepción simultáneas. La adaptación reduce interferencia, no garantiza que desaparezca. El enlace local no necesita internet; una aplicación de streaming puede necesitarlo.

Revisar continuidad con secuencias densas cerca de 12, 14, 18, 21, 24, 30, 33 y 37 s, además de muestras internas de cada bloque. Revisar la CTA hasta el cuadro1199. No presentar diferencias de píxeles como certificación de fluidez.
