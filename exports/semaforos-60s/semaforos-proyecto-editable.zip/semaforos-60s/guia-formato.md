# Guía de formato — v4 · fuente única de verdad

Vigente para TODOS los videos nuevos de este kit. Fuente: guía aportada por el usuario y aprobación posterior con énfasis en **SUBTÍTULOS CENTRADOS**. No se afirma haber analizado cinco referencias nuevas. Las preferencias v2/v3 quedan como historia, no como reglas activas. Las instrucciones explícitas posteriores del usuario tienen prioridad.

Los agentes referencian los apartados G1–G6; no mantienen copias independientes de parámetros. El bloque técnico al final forma parte de esta misma guía: la configuración de ejecución se deriva de él. Si se modifica un valor, actualizar aquí el texto y el bloque juntos y regenerar los derivados. Un proyecto concreto elige sus recursos y tiempos sin redefinir el formato.

## G1 — Técnico y audio

- Vertical 9:16, **1080×1920, 60 FPS constantes**, MP4 con video **H.264 y audio AAC**. Renderizar la animación a esa frecuencia: duplicar cuadros de un clip antiguo no lo convierte en animación nativa nueva.
- Versión **corta: 50–65 segundos**, por defecto. Punto de partida operativo: 60 segundos. Versión **profunda: 120–165 segundos**, solo con justificación de pasos adicionales que el tema necesite; no para estirar el guion.
- Audio final normalizado a **−14 LUFS integrados**, pico de muestras **máximo −1 dBFS**. Medir después de la codificación AAC. Registrar método, valores medidos y correcciones; no basta con escribir parámetros de FFmpeg.
- dBFS y dBTP no son equivalentes. Medir true peak como dato adicional y etiquetarlo como dBTP; no reemplaza el control del pico de muestras pedido. Tolerancia operativa del objetivo de sonoridad: ±0,5 LU, declarada en el informe; el techo de pico no es un promedio.
- Formato de píxel yuv420p, metadatos de color coherentes y faststart como implementación compatible para reproducción web.
- La voz es parte del formato. Si faltan narración o alineación reales, la entrega no cumple: no producir un MP4 silencioso como sustituto ni un karaoke ficticio. No generar voz ni video cuando la tarea sea actualizar esta receta.

## G2 — Estilo visual

- Fondo **siempre oscuro**, azul pizarra base aproximada **#101E28**. Nunca fondos claros, incluso durante transiciones.
- Acentos principales: cian **#2E93BE**, naranja/ámbar **#F2A33A**, crema/blanco **#FFF6E6**. Verde, amarillo y rojo se reservan para comparación de opciones, peligro o ganancia; las cifras importantes pueden usar azul o amarillo según G4. No usar amarillo como resaltado general de todas las frases.
- Ilustración vectorial plana con volumen suave, sombras cortas, formas redondeadas y personajes estilizados cuando ayuden a la explicación.
- **Variante A, por defecto:** 2D sobre fondo liso, sujeto central grande.
- **Variante B, para temas físicos/espaciales:** escena nocturna 2.5D con perspectiva, niebla suave, luces cálidas y nubes o ciudad de fondo. Máquinas, rutas y ciudades son candidatos. Elegir con criterio narrativo; no insertar personajes o ciudades sin función.
- **Máximo una metáfora visual central por video**; puede haber cero si un diagrama literal explica mejor. Todo elemento debe reforzar el concepto. La metáfora no autoriza a falsificar física, escala ni datos.

## G3 — Cámara, beats y movimiento

- Sensación de plano continuo, **0–6 cortes en todo el video**. Priorizar cero; los cortes permitidos deben estar motivados y registrados. No es una cuota a completar ni una obligación de mantener el mismo encuadre.
- Conectar por zoom, paneo, rotación de cámara o transformación del objeto siguiente: match-cut/morph con referencia espacial o causal. Variar escala y contexto sin reiniciar objetos al cambiar de texto.
- Cada **beat dura 2–4 segundos e introduce una sola novedad narrativa**. Una cifra y su visual pueden representar la misma novedad. Ningún elemento aparece sin motivo; varios movimientos pueden explicar esa única idea.
- Entradas con easing suave, principalmente ease-out. Números, barras, calendarios, baterías y grillas evolucionan animados; no aparecen completos de golpe.
- Al menos un **salto de escala** significativo en el **último tercio**: zoom out, multiplicación o ampliación conceptual que permita comprender la magnitud. No basta un pequeño zoom decorativo. A 60 s, el último tercio empieza en 40 s; para otra duración calcularlo proporcionalmente.
- Separar **beat**, **bloque de subtítulo**, **escena/contexto** y **corte**. Un beat puede contener varios bloques de texto; cambiar un subtítulo no crea una escena o corte. El estado final de una acción inicia la siguiente.

## G4 — Subtítulos CENTRADOS y karaoke

- **Siempre quemados en el video**, no depender solo de un archivo SRT.
- **Centrados horizontalmente respecto del lienzo completo: eje x=540 px. Texto centrado dentro del bloque.** Ninguna alineación izquierda ni desplazamiento hacia un lateral para compensar otros elementos.
- Ubicación en el **tercio superior**, con el borde superior del bloque a **8–15 % de la altura**: aproximadamente y=154…288 px. Base operativa: 12 %, y≈230 px. “Centrados” significa centrado horizontal en esa zona superior; no en el centro vertical de la pantalla ni abajo.
- Usar bloque simétrico de ancho limitado, por ejemplo `left:50%; transform:translateX(-50%); text-align:center`. Ajustar el gráfico alrededor del texto. Si hay riesgo de superposición con la interfaz de una plataforma, revisar dentro de la franja permitida, manteniendo el eje horizontal.
- **1–2 líneas, 2–5 palabras por bloque**, sans-serif geométrica tipo Figtree/Montserrat, grande y legible en móvil. Base operativa de la plantilla: Figtree 68 px, fuente local. Ajustar tamaño y cortes de línea con pruebas reales sin truncar ni ampliar a párrafos. La pregunta inicial larga también se segmenta: no se duplica como título permanente.
- **Karaoke por palabra:** palabra pronunciada en blanco y negrita; las demás en gris semitransparente. Reservar métricas/ancho para que el énfasis no mueva el bloque. Usar tiempos por palabra obtenidos del audio final; no repartir automáticamente una frase en tiempos iguales y llamarlo sincronización.
- Términos clave en negrita o con píldora cian redondeada detrás. Cifras importantes azules o amarillas. La palabra activa debe seguir siendo inequívoca y legible; separar la cifra destacada del subtítulo si los estilos compiten.
- Sin cuadros de selección, manijas, guías de seguridad renderizadas ni artefactos de editor. No mostrar IDs ni números de escena/slide.
- Los márgenes conservadores de versiones antiguas no deben volver a colocar los subtítulos abajo. Validar en vista de celular y en la aplicación de destino cuando esté disponible.

## G5 — Elementos gráficos recurrentes

- Etiquetas en **píldora blanca**, texto oscuro en negrita y sombra corta. Son rótulos de objetos o datos; el fondo general sigue oscuro.
- Tags técnicos en mayúsculas pequeñas con línea guía, por ejemplo MAZA o CILINDRO. Legibles, ligados al objeto y sin reemplazar los subtítulos.
- Datos nativos y animados: barras crecientes, contadores, calendarios, baterías, tablas, fórmulas en tarjeta, relojes y grillas que se multiplican. Elegir los que explican el mecanismo; no convertir el video en una presentación de interfaces.
- **Una cifra o etiqueta principal por beat**, grande y legible en móvil. Puede permanecer al siguiente beat si sigue siendo relevante. Jerarquizar las etiquetas secundarias para que no compitan.
- Escalas, unidades y comparaciones honestas. Registrar fuentes de cifras; si un número no aporta, usar una comparación concreta sustentada. Nunca inventar datos para llenar un beat.

## G6 — Narración, estructura y cierre

- **Una sola voz en off**, español neutro rioplatense, natural, cálido y acogedor. Aproximadamente **2,5 palabras por segundo**, con micropausas antes de cifras. Es orientación de ritmo, no obligación de acelerar audio artificialmente.
- Gancho **0–3 s**: pregunta intrigante o demostración visual inmediata. Mostrar el objeto/fenómeno desde el inicio útil. La pregunta es subtítulo, sin duplicado como encabezado fijo.
- Desarrollo: **un único concepto que escala en pasos**, cada uno con cifra o comparación concreta verificable. Aproximadamente 125–163 palabras para la versión corta a ese ritmo, ajustadas a pausas y duración real.
- Giro o salto de escala que sorprende y explica. Resolver la promesa del inicio; no usar una sorpresa ajena al concepto.
- Cierre: **“Enviáselo a ese amigo que…”** con remate ingenioso ligado al tema, **o una placa de título que revela el concepto**. Elegir una vía; no sumar pedidos de compartir, like y suscripción. La antigua obligación de CTA exacta de tres segundos queda reemplazada por este cierre.
- Un título revelador al final está permitido; no mantener el título durante todo el video. El cierre debe tener tiempo real de lectura/locución dentro de la duración elegida.
- Loop opcional: último fotograma puede volver al primero. Si se elige, revisar continuidad visual y de audio, no solo igualdad de dos capturas.

## Aplicación y verificación

Flujo: Tema → Guionista → Director de arte/animación → Revisor. Ver `README.md`. El checklist único vive en `agentes/revisor-formato.md` y remite a G1–G6. Los documentos 02–07 explican procesos; no redefinen estos requisitos.

Los tiempos editoriales son propuestas. Producir o recibir una narración autorizada, medir/alinear palabras y corregir el guion antes de cerrar animación y subtítulos. SRT es una salida adicional; el JSON de palabras conserva el detalle necesario para karaoke. Si una herramienta o una revisión no está disponible, reportar “no comprobado”, no “cumple”.

Los ejemplos y componentes del kit no sustituyen la investigación ni diseñan automáticamente el mecanismo de cualquier tema. Las muestras técnicas de preview no son videos de entrega. Las pruebas históricas no validan este formato nuevo.

## Parámetros técnicos derivados de esta misma guía

Este bloque es la representación ejecutable de G1–G6. Las copias generadas en la plantilla llevan procedencia/hash y no se editan directamente. La tolerancia LUFS, tamaño inicial de fuente y posición inicial son decisiones operativas explícitas, dentro de los requisitos de arriba.

<!-- formato-config:start -->
```json
{
  "version": 4,
  "width": 1080,
  "height": 1920,
  "fps": 60,
  "duration": {"defaultSeconds": 60, "shortMin": 50, "shortMax": 65, "deepMin": 120, "deepMax": 165},
  "audio": {"integratedLufs": -14, "maxSamplePeakDbfs": -1, "lufsTolerance": 0.5},
  "palette": {"background": "#101E28", "cyan": "#2E93BE", "amber": "#F2A33A", "cream": "#FFF6E6"},
  "captions": {"topRatio": 0.12, "minTopRatio": 0.08, "maxTopRatio": 0.15, "centerXRatio": 0.5, "fontFamily": "Figtree", "fontFile": "formato-v4/Figtree.ttf", "fontSize": 68, "minWords": 2, "maxWords": 5, "maxLines": 2},
  "beats": {"minSeconds": 2, "maxSeconds": 4, "maxCuts": 6},
  "voice": {"wordsPerSecond": 2.5}
}
```
<!-- formato-config:end -->
