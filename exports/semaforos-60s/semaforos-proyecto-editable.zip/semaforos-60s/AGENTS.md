# Instrucciones del proyecto

Seguir la guía v4 incluida. Preservar salidas. Animación nativa a 60 FPS, voz y timestamps fonémicos; no inventar alineación. Revisar que calles incompatibles no tengan verde simultáneo. Subtítulos centrados x540 en zona superior. No publicar sin autorización.
