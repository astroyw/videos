# Cómo cambian de luz los semáforos

Proyecto Remotion + HyperFrames. La animación completa vive en `hyperframes/index.html`; el clip local está en `public/mundo.mp4`. Remotion define la composición y renderiza la pista de subtítulos centrados en `src/index.tsx`. Para acelerar la exportación, FFmpeg integra esa pista con el mundo animado de HyperFrames y la voz; el resultado es un MP4 único. La composición Semaforos permite previsualizar el conjunto.

Para editar/renderizar: Node >=22, FFmpeg/FFprobe y Chromium. Ejecutar `npm ci`, `npm run check`, `npm run studio` y `npm run render`. Configurar `REMOTION_BROWSER_EXECUTABLE` si se usa un navegador existente. El render deja un máster y el MP4 normalizado en out.

La voz generada y su alineación están incluidas, de modo que no hace falta descargar un modelo para volver a renderizar. `scripts/voice.py` documenta la generación original con Piper/VITS; para regenerarla definir PIPER_MODEL_DIR con la carpeta del modelo Daniela y proveer, Python con piper-tts, onnx, onnxruntime, numpy y soundfile. El modelo no se redistribuye. Cualquier cambio de narración requiere regenerar sus tiempos.

Para regenerar la animación: instalar HyperFrames y GSAP según `hyperframes/package.json`, preparar assets y ejecutar su render a 60 FPS. No duplicar cuadros del clip para simular otro ritmo. Fuente Figtree con licencia OFL, voz con créditos en VOZ-MODEL-CARD. Fuentes técnicas y límites en FUENTES.md.
