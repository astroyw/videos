import React from 'react';
import {registerRoot,Composition,AbsoluteFill,OffthreadVideo,Audio,staticFile,useCurrentFrame} from 'remotion';
import captions from './captions.json';
const Reel=({track=false}:{track?:boolean})=>{const t=useCurrentFrame()/60*1000;const cue=captions.find(c=>t>=c.startMs&&t<c.endMs);return <AbsoluteFill style={{background:'#101E28',fontFamily:'Figtree',overflow:'hidden'}}>
<style>{`@font-face{font-family:Figtree;src:url('${staticFile('Figtree.ttf')}');font-weight:100 900}`}</style>
{!track&&<OffthreadVideo muted src={staticFile('mundo.mp4')} style={{position:'absolute',top:440,left:0,width:1080,height:1080}}/>}
{cue&&<div style={{position:'absolute',left:'50%',transform:'translateX(-50%)',top:230,width:880,textAlign:'center',fontSize:68,lineHeight:1.17,fontWeight:800,textWrap:'balance'}}>{cue.words.map((w,i)=><React.Fragment key={i}>{i>0?' ':null}<span style={{color:t>=w.startMs&&t<w.endMs?'#fff':'rgba(210,216,220,.48)'}}>{w.text}</span></React.Fragment>)}</div>}
{!track&&<Audio src={staticFile('voz.wav')}/>} </AbsoluteFill>};
registerRoot(()=> <><Composition id="Semaforos" component={Reel} durationInFrames={3600} fps={60} width={1080} height={1920}/><Composition id="CaptionTrack" component={()=> <Reel track/>} durationInFrames={3600} fps={60} width={1080} height={420}/></>);
