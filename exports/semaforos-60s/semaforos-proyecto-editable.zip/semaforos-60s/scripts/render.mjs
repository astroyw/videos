import fs from 'node:fs';import path from 'node:path';import {run,remotion,root} from './cli.mjs';import {measureAudio,normalizationFilter,assertLevels} from './audio.mjs';
fs.mkdirSync(path.join(root,'out'),{recursive:true});const c={audio:{integratedLufs:-14,maxSamplePeakDbfs:-1,lufsTolerance:.5}};
if(process.env.CAPTIONS_READY!=='1') remotion(['render','src/index.tsx','CaptionTrack','out/captions.mp4','--codec=h264','--pixel-format=yuv420p','--concurrency=4','--crf=18']);
run('ffmpeg',['-v','error','-y','-i','out/captions.mp4','-i','public/mundo.mp4','-i','public/voz.wav','-filter_complex','[0:v]pad=1080:1920:0:0:color=0x101E28[base];[base][1:v]overlay=0:440:shortest=1[v]','-map','[v]','-map','2:a','-c:v','libx264','-preset','fast','-crf','18','-c:a','aac','-b:a','192k','-t','60','out/master.mp4']);
const first=measureAudio(path.join(root,'out/master.mp4'),c);
run('ffmpeg',['-v','error','-y','-i','out/master.mp4','-map','0:v','-map','0:a','-vf','scale=in_range=auto:out_range=tv,format=yuv420p','-c:v','libx264','-preset','fast','-crf','18','-color_range','tv','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-af',normalizationFilter(first,c),'-c:a','aac','-ar','48000','-b:a','192k','-movflags','+faststart','out/como-cambian-los-semaforos.mp4']);
const file=path.join(root,'out/como-cambian-los-semaforos.mp4');let levels=measureAudio(file,c);
if(levels.integratedLufs < -14.5 && levels.integratedLufs > -15){
 const gain=Math.min(-14.2-levels.integratedLufs,-1.15-levels.samplePeakDbfs);
 if(gain>0){const previous=path.join(root,'out/preajuste-audio.mp4');fs.renameSync(file,previous);run('ffmpeg',['-v','error','-y','-i',previous,'-c:v','copy','-af',`volume=${gain}dB`,'-c:a','aac','-ar','48000','-b:a','192k','-movflags','+faststart',file]);levels=measureAudio(file,c);}
}
assertLevels(levels,c);
const probe=JSON.parse(run('ffprobe',['-v','error','-count_frames','-show_streams','-show_format','-of','json',file]).stdout);const v=probe.streams.find(s=>s.codec_type==='video');if(v.width!==1080||v.height!==1920||v.r_frame_rate!=='60/1'||+v.nb_read_frames!==3600||v.codec_name!=='h264'||!probe.streams.some(s=>s.codec_name==='aac'))throw Error('Formato incorrecto');run('ffmpeg',['-v','error','-xerror','-i',file,'-f','null','-']);fs.writeFileSync('out/verificacion.json',JSON.stringify({fullDecode:'passed',levels,probe},null,2));console.log('VERIFICADO 60s/1080x1920/60fps/H264/AAC',levels);
