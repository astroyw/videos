import {spawnSync} from 'node:child_process';import {createRequire} from 'node:module';import path from 'node:path';import {fileURLToPath} from 'node:url';
export const root=fileURLToPath(new URL('../',import.meta.url));
export function run(bin,args,opts={}){const r=spawnSync(bin,args,{cwd:root,encoding:'utf8',maxBuffer:64*1024*1024,...opts});if(r.status!==0)throw new Error(r.stderr||`exit ${r.status}`);return r;}
export function remotion(args){const req=createRequire(import.meta.url);return run(process.execPath,[path.join(path.dirname(req.resolve('@remotion/cli/package.json')),'remotion-cli.js'),...args,...(process.env.REMOTION_BROWSER_EXECUTABLE?['--browser-executable',process.env.REMOTION_BROWSER_EXECUTABLE]:[])],{stdio:'inherit'});}
