from pathlib import Path
import os,onnx,json,numpy as np,soundfile as sf
from piper import PiperVoice,SynthesisConfig
r=Path(__file__).resolve().parents[1];model=Path(os.environ['PIPER_MODEL_DIR'])
m=onnx.load(model/'es_AR-daniela-high.onnx');m.graph.output.append(onnx.helper.make_tensor_value_info('/Ceil_output_0',onnx.TensorProto.FLOAT,[1,1,None]));onnx.save(m,'/tmp/daniela-align.onnx')
v=PiperVoice.load('/tmp/daniela-align.onnx',config_path=str(model/'es_AR-daniela-high.onnx.json'))
texts=['¿Quién decide cuándo cambia un semáforo?', 'No es la lámpara, es un controlador.', 'Organiza el paso de cada calle.', 'El verde habilita una dirección del cruce.', 'Mientras tanto, la calle transversal espera.', 'Después, el amarillo anuncia que termina el paso.', 'Luego llega el rojo para esa dirección.', 'Puede existir una pausa con todos en rojo.', 'Así se despeja el cruce antes del cambio.', 'Recién entonces recibe verde la otra calle.', 'Algunos equipos repiten tiempos programados.', 'Otros reciben información de sensores.', 'Por ejemplo, un detector bajo el pavimento.', 'Reconoce vehículos y avisa al controlador.', 'Eso puede ajustar cuánto dura el verde.', 'Pero no cambia las luces sin restricciones.', 'Ahora mirá varios cruces de una avenida.', 'Sus ciclos pueden coordinarse entre sí.', 'La idea es reducir paradas, no eliminarlas.', 'Enviáselo a ese amigo que discute con el rojo.']
sr=v.config.sample_rate;mix=np.zeros(sr*60,dtype=np.float32);cues=[];metadata=[]
for i,text in enumerate(texts):
 start=i*3;available=2.84
 chunk=list(v.synthesize(text,SynthesisConfig(length_scale=1,noise_scale=.35,noise_w_scale=.35),include_alignments=True))[0]
 duration=len(chunk.audio_float_array)/sr
 scale=min(1.5,available/duration)
 chunk=list(v.synthesize(text,SynthesisConfig(length_scale=scale,noise_scale=.35,noise_w_scale=.35),include_alignments=True))[0]
 # Retry inference length-scale if stochastic durations exceed budget; no audio time-stretch.
 while len(chunk.audio_float_array)/sr>2.94:
  scale*=.96;chunk=list(v.synthesize(text,SynthesisConfig(length_scale=scale,noise_scale=.3,noise_w_scale=.3),include_alignments=True))[0]
 a=chunk.audio_float_array*.72;mix[int(start*sr):int(start*sr)+len(a)]=a
 groups=[];t=0;begin=None
 for ph in chunk.phoneme_alignments:
  end=t+int(ph.num_samples)
  if ph.phoneme in [' ','$']:
   if begin is not None:groups.append((begin,t));begin=None
  elif ph.phoneme not in ['^','_'] and begin is None:begin=t
  t=end
 if begin is not None:groups.append((begin,t))
 words=text.split();assert len(groups)==len(words),(text,groups,chunk.phonemes)
 ww=[dict(text=w,startMs=round(start*1000+b/sr*1000),endMs=round(start*1000+e/sr*1000),timestampMs=None,confidence=None) for w,(b,e) in zip(words,groups)]
 # Balanced groups with 2-4 words; keep exact audio intervals.
 n=len(ww);sizes=([3]*(n//3));rem=n%3
 if rem==1:
  if sizes:sizes[-1]+=1
  else:sizes=[1]
 if rem==2:sizes+=[2]
 pos=0
 for size in sizes:
  part=ww[pos:pos+size];pos+=size
  cues.append(dict(startMs=part[0]['startMs'],endMs=part[-1]['endMs'],words=part))
 metadata.append(dict(start=start,end=start+len(a)/sr,text=text,lengthScale=scale,wordCount=len(ww)))
 print(i,round(len(a)/sr,2),round(scale,2),flush=True)
sf.write(r/'public/voz.wav',mix,sr,subtype='PCM_24')
(r/'src/captions.json').write_text(json.dumps(cues,ensure_ascii=False));(r/'guion.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2))
(r/'alineacion.md').write_text('Tiempos por palabra derivados de duraciones fonémicas del mismo pase ONNX que generó el audio (Ceil duración VITS × hop_length), agrupadas por espacios fonémicos; sin distribuir palabras por igual. Voz Piper es_AR-daniela-high. Sin estiramiento posterior. Revisión humana de escucha no disponible.\n')
