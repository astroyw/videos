import {run} from './cli.mjs';
export function measureAudio(file,c){
 const first=run('ffmpeg',['-hide_banner','-nostats','-i',file,'-map','0:a:0','-af',`loudnorm=I=${c.audio.integratedLufs}:TP=${c.audio.maxSamplePeakDbfs-.5}:LRA=11:print_format=json`,'-f','null','-']);
 const match=first.stderr.match(/\{\s*"input_i"[\s\S]*?\}/);if(!match)throw new Error('No se pudieron medir LUFS y true peak');
 const l=JSON.parse(match[0]);
 const peak=run('ffmpeg',['-hide_banner','-nostats','-i',file,'-map','0:a:0','-af','astats=metadata=0:reset=0','-f','null','-']).stderr;
 const values=[...peak.matchAll(/Peak level dB:\s*(-?[\d.]+|inf)/g)].map(x=>Number(x[1]));
 if(!values.length)throw new Error('No se pudo medir pico de muestras');
 return {integratedLufs:Number(l.input_i),samplePeakDbfs:Math.max(...values),truePeakDbtp:Number(l.input_tp),loudnorm:l};
}
export function assertLevels(measured,c){
 if(!Number.isFinite(measured.integratedLufs)||Math.abs(measured.integratedLufs-c.audio.integratedLufs)>c.audio.lufsTolerance)throw new Error(`LUFS fuera de tolerancia: ${measured.integratedLufs}`);
 if(!Number.isFinite(measured.samplePeakDbfs)||measured.samplePeakDbfs>c.audio.maxSamplePeakDbfs)throw new Error(`Pico de muestras excede máximo dBFS: ${measured.samplePeakDbfs}`);
}
export function normalizationFilter(measured,c){
 const m=measured.loudnorm;for(const key of ['input_i','input_tp','input_lra','input_thresh','target_offset'])if(!Number.isFinite(Number(m[key])))throw new Error('Audio no normalizable: silencio o medición inválida');
 return `loudnorm=I=${c.audio.integratedLufs}:TP=${c.audio.maxSamplePeakDbfs-.5}:LRA=11:measured_I=${m.input_i}:measured_TP=${m.input_tp}:measured_LRA=${m.input_lra}:measured_thresh=${m.input_thresh}:offset=${m.target_offset}:linear=true:print_format=json`;
}
