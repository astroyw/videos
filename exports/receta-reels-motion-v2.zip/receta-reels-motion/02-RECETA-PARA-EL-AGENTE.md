> Dirección vigente v2: leer `07-CONTINUIDAD-Y-ANIMACION.md`. La tabla de tiempos organiza el relato; no prescribe cortes. Planificar primero la evolución continua de los objetos. La plantilla histórica requiere adaptar su montaje.

# Receta de producción para Claude Code o Codex

## Resultado esperado

Un video educativo donde el espectador **ve el mecanismo** mientras lee una explicación breve. El diseño usa el lenguaje visual de las referencias; el guion, los gráficos, la marca y el audio son propios. La entrega incluye un archivo reproducible, no solo una descripción de lo que debería verse.

## Paso 1 — Entender el encargo y el entorno

Leer el brief y las instrucciones del repositorio. Registrar duración, número de escenas, audio y CTA. Revisar primero qué ya existe. Si hay aplicación, agregar el video en una subcarpeta. No sobrescribir AGENTS.md, CLAUDE.md ni manifests existentes para instalar el kit.

Verificar herramientas y skills con `06-INSTALACION-Y-SKILLS.md`. La documentación y la instalación son cosas distintas: encontrar un SKILL.md no prueba que el motor de render funcione.

Si hay referencias locales, medir sus metadatos y mirar cuadros repartidos por el inicio, desarrollo y cierre, además de secuencias cortas para entender el movimiento. Anotar solo lo observado. Un título de archivo no permite inferir cómo se ve un video que no pudo abrirse.

## Paso 2 — Investigar una sola explicación

Escribir una frase: «Al terminar, la persona va a entender que…». Separar premisa, causa, efecto y matiz. Buscar fuentes primarias o técnicas fiables según el tema; registrar enlaces, fecha de consulta y qué afirmación sostiene cada fuente.

Los clips de referencia sirven para la dirección artística, no como autoridad sobre física o leyes. En tránsito, fijar país, normativa y vigencia. En refrigeración, distinguir tecnología y condiciones. En ciencia, no presentar un dibujo simplificado como cálculo o simulación validada.

Si la premisa del pedido es falsa, corregirla en el guion. La curiosidad no necesita una afirmación engañosa.

## Paso 3 — Guion con retención honesta

Preparar tres hooks breves, elegir el más visual y continuar. Usar:

**Situación → pregunta → causa → cambio visible → detalle inesperado → resolución → CTA.**

Cada dato nuevo debe responder a la pregunta anterior o plantear una pregunta útil. Dar pequeñas respuestas durante todo el video. El microgancho de la mitad debe tener una resolución clara antes de pedir la acción final.

Con 40 segundos silenciosos, usar aproximadamente 75–105 palabras en los subtítulos como punto de partida, luego medir cada bloque. No acelerar los textos para acomodar un guion demasiado largo. Se puede explicar más mostrando una flecha o un cambio de estado que agregando una oración.

Elegir una CTA ligada al contenido. Ejemplo: «Compartíselo a ese amigo curioso». Mantenerla visible los últimos 3 segundos completos. Los 14 pulsos incluyen la CTA; no agregarla por fuera de los 40 segundos.

## Paso 4 — Storyboard antes de programar

Crear una tabla con: inicio/final en fotogramas, texto visible, diagrama, acción causal, transición y propósito narrativo. Intervalos de la forma `[inicio, final)`: el cuadro final pertenece al pulso siguiente, sin obligar a reemplazar el escenario.

Para 40 segundos a 30 FPS: total 1200. Una distribución posible para 14 bloques de subtítulos es 0–3, 3–5, 5–8, 8–11, 11–14, 14–17, 17–20, 20–23, 23–26, 26–29, 29–32, 32–35, 35–37 y 37–40 segundos. Estos intervalos NO son límites de planos. Agruparlos en 3–5 bloques visuales, con objetos persistentes entre ellos. Los títulos se usan en código, nunca como numeración en pantalla. Agregar columnas: objeto que permanece, estado anterior, transformación, estado final, cámara y continuidad hacia el siguiente pulso.

Definir para cada escena **qué cambia en el dibujo y por qué**. Si la respuesta es solo «aparece una frase», falta diseñar la explicación. Mantener objetos reconocibles de una escena a otra; cambiar el encuadre cuando cambia la escala del fenómeno.

## Paso 5 — Construir una gramática visual

Leer `03-GUIA-VISUAL.md` y elegir una paleta, tipografía y escala de trazos consistentes. Crear componentes reutilizables para rótulos, flechas, valores, gráficos, subtítulos y transiciones. Dibujar objetos del tema, no llenar el video con formas decorativas intercambiables.

El diagrama ocupa el centro; el subtítulo cuenta lo que ese estado significa. Evitar que un titular y el subtítulo repitan toda la misma frase. Los detalles secundarios pueden ser más pequeños, pero ninguna condición esencial debe depender de leer letra diminuta.

## Paso 6 — Animar con Remotion y HyperFrames

**Remotion:** composición vertical, secuencias con límites en cuadros, `useCurrentFrame()` y `interpolate()` o springs controlados. Sin CSS animations, timers, reloj del sistema ni aleatoriedad sin semilla que rompan el render cuadro a cuadro. El subtítulo y el gráfico comparten la misma fuente de tiempos.

**HyperFrames:** elegir un segmento concreto que aporte valor: flujo, partículas, moléculas o un gráfico. Construir HTML y GSAP deterministas, timeline pausada registrada, duración explícita y assets locales. Ejecutar check y revisar capturas; renderizar a archivo local y usarlo con `OffthreadVideo` en Remotion. Si el video es silencioso, el clip va muted y la exportación final no conserva audio.

La plantilla del kit contiene un ejemplo real de esa integración. El HTML molecular es un esquema educativo; para otro tema se reemplaza por el mecanismo adecuado. Usar ambas herramientas no exige recrear todos los planos en ambas.

Las transiciones no deben alterar la duración total. Una superposición que resta cuadros exige compensar el montaje; mantener una línea de tiempo global y estados continuos evita descontar cuadros de forma accidental. No reiniciar el objeto dentro de una Sequence nueva por cada subtítulo.

## Paso 7 — Subtítulos y voz opcional

En modo silencioso, diseñar el tiempo para lectura y acción visual. Exportar SRT con las mismas frases y límites que los subtítulos incrustados. Usar índices del formato SRT únicamente en el archivo, no renderizarlos.

Con futura voz del usuario, el SRT es una guía de montaje, no una alineación con un audio que todavía no existe. Si llega una grabación, volver a medir y sincronizar. Guardar por separado la versión silenciosa.

Si el brief pide sonido, producir efectos pertinentes y una mezcla que priorice la voz. Registrar procedencia y licencia de sonidos y modelo/servicio. No asumir que todo recurso de Internet se puede redistribuir.

## Paso 8 — Previsualizar, renderizar y revisar

Generar muestras de todos los estados clave. Corregir recortes, baja legibilidad, oclusiones, saltos y superposiciones. Ejecutar tipos y validaciones de HyperFrames. Un check sin textos muestreados no prueba contraste tipográfico.

El prompt del kit pide explícitamente el MP4: renderizarlo cuando las verificaciones previas estén bien. Medir el archivo real con FFprobe, decodificarlo completo y revisar sus cuadros. Seguir `05-CONTROL-DE-CALIDAD.md`.

## Paso 9 — Entregar y explicar límites

Empaquetar código, fuentes necesarias, subtítulos, guion, fuentes factuales y resultado de verificaciones. Excluir node_modules, cachés, credenciales, renders fallidos y originales de terceros que no formen parte de la entrega autorizada.

El archivo final debe estar disponible mediante el mecanismo real del cliente: adjunto/exportación, carpeta descargable o enlace autorizado. No inventar un panel «Archivos» ni un enlace sandbox si la interfaz no los ofrece. La publicación en redes y en GitHub es un paso aparte que necesita autorización.

Informar qué se verificó, qué no y cómo reproducir el resultado. No afirmar que se escuchó audio cuando solo se midieron niveles. No afirmar que se vio una referencia que no se pudo abrir.
