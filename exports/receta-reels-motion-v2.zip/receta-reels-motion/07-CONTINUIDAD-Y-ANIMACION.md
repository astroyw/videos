# Dirección obligatoria v2: explicar con una animación continua

## El resultado que buscamos

El espectador sigue un objeto o sistema que cambia mientras se explica. Una carretera sigue presente cuando un auto se mueve; un aire acondicionado permanece mientras cambia el control y se desarrolla la comparación. Tomar esa continuidad de las referencias inspeccionadas, además de sus colores y subtítulos.

El video de la ventana dejó una lección concreta: aunque cada segmento tenga movimiento, reemplazar todo el dibujo y el encabezado cada 2–3 segundos genera sensación de diapositivas. Esta revisión corrige esa arquitectura.

## Separar tres tiempos

1. **Pulso narrativo:** una idea o avance de la explicación. Puede durar 2–3 s.
2. **Subtítulo:** una frase que aparece durante el tiempo necesario para leerla. Puede cambiar mientras una acción continúa.
3. **Plano o escenario:** el mundo visual que contiene los objetos. Puede durar 8–15 s o más y abarcar varios pulsos.

Para 40 s, usar como punto de partida 10–20 pulsos agrupados en 3–5 bloques visuales conectados. La base del prompt es 14 pulsos y 4 bloques. **No crear un plano nuevo por cada fila del guion.** Los límites entre bloques tampoco requieren cortes.

## Conservar el objeto y su historia

Antes de programar, identificar protagonista, piezas, posición, escala y estado. Completar para cada avance:

> Venimos de este estado → ocurre esta acción → queda este resultado → ese resultado inicia el siguiente avance.

Ejemplo: una barra se mide; la misma barra se corta; el tramo cortado gira y ocupa un lado del marco; las otras piezas llegan a sus esquinas. El marco terminado permanece mientras se muestra la hoja móvil. No reaparecen barras nuevas en el centro como si la acción anterior no hubiera existido.

Al cambiar de escala, acercar la cámara a una esquina identificable. Mantener un borde, color o silueta que ubique al espectador. Volver al conjunto alejando la cámara por el recorrido inverso. Un detalle ampliado puede ser esquemático: indicarlo si evita confusión; no deformar físicamente una pieza solo para conseguir un morph vistoso.

## Más animación con una función clara

Planificar varias acciones encadenadas por bloque, no una entrada y una espera larga. Por ejemplo:

- La cota recorre una pieza mientras se prepara la herramienta.
- La herramienta avanza; el material se separa donde corresponde.
- La pieza cortada se desplaza y gira; el conector se acerca cuando ya hay espacio.
- La unión se completa; el movimiento se transfiere a la pieza siguiente.
- Las diagonales se trazan; el marco se corrige; el resultado queda visible antes de continuar.

Usar anticipación breve, acción y asentamiento. Solapar acciones secundarias cuando no distraigan; no hacer que todo arranque y termine simultáneamente. Reservar el mayor movimiento para la causa que el subtítulo está explicando.

Introducir novedades significativas aproximadamente cada 1–3 s sin forzar movimientos absurdos. Un resultado puede quedar quieto para entenderlo. Si el bloque se congela durante varias frases, revisar si falta mostrar el mecanismo. No resolverlo agregando partículas, pulsaciones, vibración, movimiento de títulos o zoom lento permanente.

## Cámara, cortes y transiciones

Por defecto, buscar cero cortes bruscos y permitir hasta dos justificados en 40 s. Este presupuesto responde a la preferencia del usuario; no es una ley ni un conteo de las referencias. Registrar dónde se corta y por qué. Un corte útil puede saltar una espera industrial o presentar otra escala que no conviene simular.

Para enlazar, preferir:

- Seguir una pieza hasta su destino.
- Acercarse a un detalle del mismo objeto y regresar.
- Abrir una vista por capas conservando el eje y la posición del conjunto.
- Trazar una curva o recorrido a partir del estado ya visible.
- Introducir una comparación dentro del mismo escenario, manteniendo escalas consistentes.

Un fundido de dibujo A a dibujo B sigue siendo un reemplazo de escenario. Agregar fundidos a las 14 escenas viejas no satisface esta receta. Tampoco lo hace una barrida decorativa que tapa el reinicio.

La cámara acompaña una acción o dirige la atención. Evitar saltos de escala al comenzar una frase y recorridos permanentes que dificulten leer. Como referencia inicial, movimientos de 12–30 cuadros y aterrizajes suaves; ampliar el tiempo si el recorrido es grande. Conservar dirección y velocidad al encadenar movimientos. No imponer el mismo easing a todas las piezas.

## Texto y cierre

El subtítulo cuenta el significado del cambio; el dibujo lo muestra. No rearmar la pantalla como «nuevo titular + nueva ilustración + nueva frase» en cada pulso. Usar un gancho inicial y etiquetas junto al mecanismo. Los titulares posteriores son opcionales y ocasionales.

Conservar los colores, tamaño de subtítulos y márgenes de la guía visual. Mantener el texto estable mientras se lee. En silencio, el énfasis de palabras es editorial, no sincronización con una locución inexistente.

La conclusión se ve en el resultado del proceso. La CTA de los últimos 3 s se superpone al mismo escenario; el objeto continúa una acción suave y pertinente. No pasar a una placa final aislada.

## Implementación en Remotion

Separar la pista del mundo visual de la pista de subtítulos. Un `Sequence` puede abarcar un bloque largo con varios subtítulos; no necesita desmontar el mundo cada vez que cambia una frase. Usar IDs estables y evitar claves dependientes del subtítulo.

Esquema conceptual, no código de producción probado:

```tsx
const Reel = () => {
  const frame = useCurrentFrame();
  const state = sampleWorldAtFrame(frame); // posición, forma, cámara, materiales
  const caption = captionAtFrame(frame);  // reloj editorial independiente
  return <AbsoluteFill>
    <World state={state} />
    <Caption text={caption.text} highlight={caption.highlight} />
  </AbsoluteFill>;
};
```

`sampleWorldAtFrame` debe ser una función determinista del cuadro, sin acumular estado del render anterior. Los renders pueden pedir cuadros fuera de orden. Para cada pieza, interpolar entre estados conocidos; la posición final de una acción es la inicial de la siguiente. Conservar el estado al terminar una interpolación. Si se usan cuadros locales dentro de una Sequence, convertirlos al reloj global para los objetos compartidos.

No usar `parts.map` para montar y desmontar un `<Shot>` completamente diferente por frase como solución visual predeterminada. Esa estructura de la demo antigua debe refactorizarse. `Sequence` sigue siendo válido para capas y unidades de edición; el problema es el reinicio del escenario, no el componente.

## Implementación en HyperFrames e integración

Usar una timeline pausada con IDs de objetos persistentes y estados explícitos. Continuar el movimiento desde su valor anterior; evitar varios `.from()` que restablecen una pieza cada vez que cambia el texto. Registrar la timeline y respetar el contrato de clips de HyperFrames. No usar reproducción en tiempo real, timers ni aleatoriedad sin semilla.

Si se integra un clip de HyperFrames, preferir un bloque continuo con varias acciones. Montarlo una sola vez durante ese bloque y cambiar los subtítulos por encima. Igualar fondo, cámara, escala y posición con los gráficos contiguos. Si se pasa del clip a SVG/React, diseñar un estado compartido al comienzo y al final y comprobarlo visualmente. Usar ambas herramientas no obliga a alternarlas cada pocos segundos.

## Cómo aprobar la continuidad

Antes del render de entrega, revisar el montaje en movimiento cuando el cliente lo permita. Si solo se pueden extraer cuadros, revisar secuencias densas alrededor de todas las uniones: por ejemplo, cada 3 cuadros durante medio segundo a cada lado, más muestras dentro de cada bloque. Registrar ese límite de revisión.

Preguntas de aceptación:

- ¿Se puede seguir la misma pieza cuando cambia el subtítulo?
- ¿Cada acción hereda el resultado anterior, o todo vuelve al centro?
- ¿Se entiende qué provoca el movimiento?
- ¿Hay un salto de posición, escala o cámara sin explicación?
- ¿El título y el fondo se reinician con cada idea?
- ¿Una acción ocurre durante el bloque o solo al entrar?
- ¿La CTA sigue dentro del mismo mundo?

Anotar los cortes y los reinicios encontrados. Corregirlos antes de entregar. Un análisis de diferencias de píxeles o un render con 30 FPS no prueba fluidez por sí mismo. Las pruebas de codec, duración y decodificación siguen siendo necesarias, pero no sustituyen esta evaluación.
