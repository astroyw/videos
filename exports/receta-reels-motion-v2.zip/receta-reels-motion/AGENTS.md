# Instrucciones de este kit

Esta carpeta es una receta y ejemplo para crear motion graphics verticales. Leer `00-EMPEZA-ACA.md` y ejecutar el brief de `01-PROMPT-EDITABLE.md` cuando el usuario lo solicite.

- Las instrucciones explícitas del usuario tienen prioridad sobre los valores iniciales del kit.
- Base: 40 s, 14 pulsos narrativos en 4 bloques visuales conectados, 1080×1920, 30 FPS, H.264, sin audio, subtítulos y una CTA final de 3 s. Nunca dibujar números de escena.
- Fondo carbón, texto blanco, énfasis amarillo y diagramas causales en movimiento; leer la guía visual.
- Preservar el proyecto existente. No copiar este AGENTS.md encima de otro; integrar solo reglas pertinentes con cuidado.
- Leer las skills locales de Remotion y HyperFrames. Usar ambas realmente si el brief lo pide; guardar el segmento HTML y su render.
- Leer obligatoriamente 07-CONTINUIDAD-Y-ANIMACION.md. La plantilla sobre gasificación es un ejemplo técnico histórico, no un modelo de ritmo. No copiar su enrutamiento de una escena por frase para videos nuevos. Conservar un escenario persistente, subtítulos independientes y máximo 2 cortes bruscos por defecto en 40 s.
- Renderizar cuando el usuario pide el archivo final. El prompt editable de este kit lo pide explícitamente.
- Verificar el MP4 final con FFprobe, decodificación completa y revisión visual. Distinguir pruebas ejecutadas de comprobaciones pendientes.
- No publicar, hacer push, borrar archivos existentes ni inventar enlaces de descarga.
