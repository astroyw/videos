## Puerta de aceptación v2: continuidad

- [ ] Los 10–20 pulsos del guion se desarrollan en 3–5 bloques visuales conectados; las cifras son guías editables.
- [ ] Máximo 2 cortes bruscos en 40 s por defecto; se enumeran y justifican. El límite incluye saltos encubiertos por un fundido.
- [ ] Cada cambio de subtítulo conserva el objeto y su estado salvo una razón narrativa explícita.
- [ ] Hay acciones causales encadenadas; el movimiento no se reduce a entradas, zooms o bucles decorativos.
- [ ] Se revisaron secuencias temporales alrededor de cada unión y los pasajes que quedan inmóviles después de una entrada.
- [ ] Se pudo seguir el objeto sin volver a orientarse en cada frase.
- [ ] La CTA permanece sobre el mismo escenario.

Un render técnicamente correcto con movimiento en 14 muestras puede fallar esta revisión. Si falta reproducción del video, declarar que se revisaron secuencias de cuadros y no afirmar fluidez certificada.


# Lista de entrega: registrar evidencia real

## Historia y exactitud

- [ ] El hook se entiende en los primeros 3 segundos.
- [ ] El cuerpo explica una cadena causal coherente y una sola idea principal.
- [ ] El microgancho tiene respuesta; el payoff aparece antes de la CTA.
- [ ] Las afirmaciones tienen fuentes; condiciones y excepciones importantes están claras.
- [ ] Hay una CTA legible en los últimos 3 segundos.

## Imagen y movimiento

- [ ] El objeto explicativo cambia dentro de cada escena; el movimiento no se limita al texto o una barra de progreso.
- [ ] Se revisaron cuadros del principio, mitad y final de cada escena y los cortes problemáticos.
- [ ] No hay números de slide ni logos ajenos.
- [ ] No hay texto cortado, demasiado pequeño o tapado por otras capas.
- [ ] Los subtítulos tienen máximo dos líneas, tiempo de lectura y contraste suficiente.
- [ ] Los elementos esenciales respetan la zona segura elegida.
- [ ] Las escalas, flechas, trayectorias y etiquetas del diagrama no inducen errores.
- [ ] La CTA forma parte de la duración total.

## Archivo final

Medir el MP4 que se va a entregar, no solo la composición ni un máster anterior.

```bash
ffprobe -v error -count_frames -show_streams -show_format -of json video-final.mp4
ffmpeg -v error -xerror -i video-final.mp4 -f null -
```

Comprobar: video H.264, 1080 × 1920, 30 FPS constantes, yuv420p, duración pedida y número de cuadros. Para 40 segundos: **1200 cuadros** y **40.000 s**. Si se pidió silencio, la lista de streams no debe contener audio. Un audio con volumen cero no equivale a ausencia de pista.

En el proyecto de ejemplo, `npm run verify` ejecuta comprobaciones técnicas y escribe el informe indicado en su README. Un proceso con salida 0 no prueba que el guion sea bueno: la revisión editorial y visual se registra aparte.

## Texto y sonido

- [ ] SRT y subtítulos incrustados tienen el mismo texto y los mismos intervalos.
- [ ] No se promete sincronización con una voz que todavía no se grabó.
- [ ] Si hay voz, se revisó su correspondencia con el montaje y se anotó cómo se comprobó.
- [ ] Si hay audio, se registraron licencias, niveles y cualquier limitación de escucha.

## Entrega

- [ ] MP4 reproducible, guion, SRT, código, fuentes factuales y licencias.
- [ ] Sin dependencias pesadas, cachés ni credenciales dentro del ZIP.
- [ ] ZIP extraído y comprobado; no basta con que exista.
- [ ] Un enlace de descarga real o un adjunto del cliente; no inventar rutas publicadas.
- [ ] No publicar ni hacer push sin autorización.

En `VERIFICACION.md`, separar **pasó**, **falló** y **no ejecutado**. Explicar cómo se midió cada afirmación importante.
