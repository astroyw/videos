> **Aviso v2:** este es un ejemplo técnico histórico. Su estructura de 14 escenas separadas no es el estilo solicitado actualmente. Antes de crear otro video, leer `../07-CONTINUIDAD-Y-ANIMACION.md`, conservar los objetos en un escenario persistente y separar sus tiempos de los subtítulos. El código no se reescribió ni se renderizó en esta actualización de documentación.

# Claude Code

Leé y seguí `AGENTS.md` y `README.md` de esta carpeta, además de la receta principal del kit. Esta demo usa Remotion para el montaje y un clip de HyperFrames para las moléculas. La especificación vigente del usuario tiene prioridad sobre los valores del ejemplo.
