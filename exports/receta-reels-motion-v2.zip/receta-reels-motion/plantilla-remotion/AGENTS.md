> **Aviso v2:** este es un ejemplo técnico histórico. Su estructura de 14 escenas separadas no es el estilo solicitado actualmente. Antes de crear otro video, leer `../07-CONTINUIDAD-Y-ANIMACION.md`, conservar los objetos en un escenario persistente y separar sus tiempos de los subtítulos. El código no se reescribió ni se renderizó en esta actualización de documentación.

# Trabajo con esta demo

Leé el README de esta carpeta y la receta del kit. Conservá el proyecto existente y creá variantes en archivos separados cuando convenga. No publiques ni borres contenido sin una instrucción del usuario.

La demo tiene 40 segundos a 30 FPS y 14 partes. La última es un cierre de 3 segundos con una única llamada a la acción. No mostrar números de slide. Por defecto, silencio total y subtítulos incrustados.

Leé las skills locales de Remotion y HyperFrames si están instaladas en el proyecto que recibe este kit. Para las instrucciones de instalación, usá la receta principal. Los archivos fuente de HyperFrames viven separados de React.

Animaciones deterministas por cuadro/tiempo. Sin timers, aleatoriedad sin semilla, CSS animation ni fetch durante el render. Tipografías y medios locales. El contenido visual debe explicar causas y consecuencias; adaptar los diagramas al nuevo tema, no solo reemplazar textos del JSON.

Para verificar: `npm run check`, revisar Studio, `npm run render`, inspeccionar cuadros y el MP4 completo. `npm run verify` vuelve a verificar la salida existente. Declarar solamente las pruebas efectivamente ejecutadas. Preservar licencias y no incluir node_modules en entregas ZIP.
