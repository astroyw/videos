# Gancho, cuerpo, retención y cierre

## Un esqueleto que podés completar

> **HOOK:** ¿Por qué [situación cotidiana] si [lo que parecería lógico]?
>
> **PROMESA:** Para entenderlo, mirá qué pasa con [objeto o variable].
>
> **CUERPO:** Cuando [causa], [mecanismo]. Por eso [consecuencia visible].
>
> **MICROGANCHO:** Pero falta un detalle: [pregunta o excepción pertinente].
>
> **DEMOSTRACIÓN:** Si cambiamos solo [variable], pasa [resultado].
>
> **PAYOFF:** Entonces, [respuesta breve a la pregunta inicial].
>
> **CTA:** [Una acción relacionada con el tema].

Usalo como estructura de razonamiento, no como frases obligatorias para todos los videos. Mostrar el mecanismo puede reemplazar parte de la explicación verbal.

## Elegí un tipo de hook

| Tipo | Fórmula | Ejemplo |
| --- | --- | --- |
| Pregunta cotidiana | «¿Por qué [algo familiar]?» | «¿De dónde salen las burbujas de tu gaseosa?» |
| Predicción | «Si [acción], ¿qué pensás que pasa?» | «Si calentás una gaseosa, ¿retiene igual el gas?» |
| Contraste | «Parece [A], pero ocurre [B]» | «El gas está ahí incluso antes de que veas burbujas». |
| Demostración directa | Mostrar el efecto y preguntar su causa | Abrir una botella; aparecen burbujas; «¿Qué cambió?» |

El hook tiene que poder dibujarse. Evitar promesas absolutas, números inventados, «nadie te lo cuenta» o «lo hiciste mal toda tu vida» sin fundamento.

## Recursos para sostener atención

- **Pregunta visual:** congelar brevemente dos posibles recorridos y mostrar cuál ocurre.
- **Comparación controlada:** mismo objeto, misma escala, una sola variable diferente.
- **Acercamiento:** pasar del objeto cotidiano al mecanismo interno y luego volver.
- **Detalle que reorganiza:** revelar una condición que explica lo anterior, sin contradecirlo de forma engañosa.
- **Progreso conceptual:** cada plano responde algo, no solo anuncia que después llegará la respuesta.

Para 40 segundos, ubicar un microgancho alrededor de 15–20 s y resolverlo en los siguientes planos. El final debe pagar la promesa del inicio antes de pedir una acción.

## Una CTA por video

| Objetivo | Texto editable |
| --- | --- |
| Compartir | «Compartíselo a ese amigo curioso». |
| Compartir sobre un tema | «Mandáselo a quien siempre pregunta por [tema]». |
| Seguir | «Seguime para entender la ciencia de todos los días». |
| Suscribirse en YouTube | «Suscribite para más explicaciones así». |
| Like | «Si te sirvió, dejá un me gusta». |
| Guardar | «Guardalo para acordarte la próxima vez». |

La base del kit usa compartir porque sirve en las tres plataformas. Si cambiás a «suscribite», adaptá la versión para YouTube. Mantener el texto en pantalla durante 3 segundos y no agregar otra petición simultánea.
