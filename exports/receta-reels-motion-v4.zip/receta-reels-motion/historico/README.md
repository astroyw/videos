# Historial

Los archivos de esta carpeta conservan evidencia de versiones anteriores. No son instrucciones de producción. La autoridad vigente está en `../guia-formato.md`. Los ZIP v1/v2/v3 y los videos anteriores se preservan fuera del paquete nuevo.
