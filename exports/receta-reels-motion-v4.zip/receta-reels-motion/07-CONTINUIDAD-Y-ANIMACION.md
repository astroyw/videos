# Aplicación de continuidad y animación

Leer [guia-formato.md](guia-formato.md), especialmente G3 y G4. Sus valores gobiernan la producción. Este documento explica la arquitectura para cumplirlos.

## Diseñar estados y enlaces

Para cada beat escribir: estado previo → novedad → acción → resultado. La siguiente acción hereda ese resultado. Un cambio de bloque de subtítulo no desmonta el mundo ni reinicia una pieza.

Para cada transición anotar referencia compartida, pose de salida, trayectoria de cámara/objeto y pose de llegada. Puede variar la escala o el contexto conservando la orientación. Un morph debe representar una relación comprensible, no simular transformaciones físicas falsas. Registrar cortes reales por separado de escenas/contextos.

El salto de escala tiene que revelar significado, por ejemplo un elemento que pasa a formar parte de una grilla o un detalle que explica un conjunto. Planearlo en el tramo definido por G3. Toda multiplicación es la novedad del beat, no una excusa para agregar varias ideas a la vez.

## Remotion

Separar estado visual, cámara, beats, bloques de subtítulo y palabras. Derivarlos de tiempo global determinista; no depender del cuadro solicitado anteriormente. Mantener IDs de objetos estables y conversiones explícitas entre relojes locales y globales. `Sequence` puede organizar capas; evitar una escena completamente nueva por frase.

El karaoke lee intervalos de palabras del audio real. La capa de texto se mantiene independiente del movimiento de cámara para conservar la posición de G4. El mundo puede panear o rotar; los subtítulos no deben desplazarse con él. Mantener métricas estables para el énfasis de palabra activa.

## HyperFrames

Leer las skills locales para el contrato vigente. Timeline pausada registrada, assets locales y estado determinista. Cada clip útil puede desarrollar varias acciones; integrar su render nativo a la frecuencia de G1. No reciclar un clip histórico a menor frecuencia afirmando que su movimiento ya es nativo del nuevo formato.

Al pasar entre HTML/GSAP y React/SVG, compartir pose, escala, fondo y cámara. Usar ambas herramientas no obliga a intercalarlas constantemente. El texto puede componerse en Remotion por encima de la animación HyperFrames para conservar alineación y legibilidad.

## Revisión

Aplicar el checklist único del Revisor. Revisar trayectorias, continuidad de referencias, cambios de palabra, escala y cierre; conservar muestras/evidencias. Una captura técnica es útil para layout, pero no prueba fluidez ni sincronización de una película completa.
