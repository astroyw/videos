# Ejemplos editoriales

Norma única: [guia-formato.md](../guia-formato.md). Los planes actuales son:

- [Gasificación, 60 s](07-gasificacion-60s.md).
- [Ventana, 60 s](08-ventana-60s.md).
- [Bluetooth, 60 s](09-bluetooth-60s.md).

Son guiones y planes visuales; no videos generados ni voces sincronizadas. Los tiempos se ajustarán al audio real. Usar la [plantilla de salida del Guionista](../plantillas/salida-guionista.md) y su [CSV](../plantillas/salida-guionista.csv).

Los seis archivos numerados 01–06 se conservan como **históricos de v3**. Sus 40 segundos, 30 FPS, subtítulos y cierre describen el formato anterior, no instrucciones vigentes. Los Markdown tienen aviso y enlace al reemplazo; los CSV conservan sus datos y agregan las columnas `estado_documento` y `guia_vigente` para evitar que una cabecera de comentario rompa su estructura.
