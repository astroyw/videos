# Bluetooth — propuesta de un minuto

Norma única: [guia-formato.md](../guia-formato.md), G1–G6. **Plan editorial de 60 s, no render ni voz producidos.** Los tiempos de cada beat son provisionales; se ajustan a la grabación y alineación reales antes de animar karaoke. Los `/` separan bloques de subtítulos y no se muestran.

**Concepto:** un enlace de radio transmite datos coordinados; el receptor reconstruye audio. **Variante A.** Una única metáfora: paquetes como pequeños envíos de información, siempre identificados como esquema; no agregar rutas, carteros ni otras metáforas independientes.

**Continuidad:** cero cortes propuestos. Celular → datos → emisión → banda → receptor → transductor → enlace completo. Cada cambio conserva una referencia espacial. El salto de escala de 51–54 s revela que muchos envíos sostienen una experiencia sonora continua.

**Alcance:** ejemplo de audio, sin afirmar que todas las variantes de Bluetooth usen el mismo perfil o codec. La banda compartida no implica que todas las transmisiones interfieran siempre.

| tiempo | narración | bloque de subtítulo | visual | etiqueta/cifra en pantalla | movimiento de cámara |
| --- | --- | --- | --- | --- | --- |
| 00–03 s | ¿Cómo llega música sin cables a tus auriculares? | ¿Cómo llega música / sin cables / a tus auriculares? | Celular y auriculares; onda breve abre la pregunta. | BLUETOOTH | Acercamiento a la conexión. |
| 03–06 s | Bluetooth conecta dispositivos cercanos usando señales de radio. | Bluetooth conecta / dispositivos cercanos / usando señales de radio. | Mostrar enlace de radio entre los dos dispositivos. | RADIO | Seguir señal sin cortar. |
| 06–09 s | Primero, se detectan y pueden establecer una conexión. | Primero, se detectan / y pueden establecer / una conexión. | Intercambio de detección y conexión esquemático. | CONEXIÓN | Paneo leve entre extremos. |
| 09–12 s | Emparejarlos puede guardar información para reconocerse después. | Emparejarlos puede / guardar información / para reconocerse después. | Mostrar identificación compartida sin confundirla con internet. | EMPAREJAMIENTO | Volver al celular manteniendo referencia del auricular. |
| 12–15 s | Dentro del celular, el audio se prepara como datos. | Dentro del celular, / el audio se prepara / como datos. | Representar audio digital listo para transmisión. | DATOS | Entrar al interior del celular. |
| 15–18 s | Esos datos viajan organizados en paquetes. | Esos datos viajan / organizados en paquetes. | Agrupar datos como paquetes gráficos, única metáfora. | PAQUETES | Acompañar agrupación hasta salida. |
| 18–21 s | Son envíos de información, no cajitas reales. | Son envíos de información, / no cajitas reales. | Conservar paquetes esquemáticos y aclarar representación. | ESQUEMA | Seguir el paquete protagonista. |
| 21–24 s | La antena transmite una señal de radio. | La antena transmite / una señal de radio. | Representar emisión; bloque no se confunde con objeto físico. | ANTENA | Revelar contorno de antena y salida. |
| 24–27 s | Usa la banda de dos coma cuatro gigahercios. | Usa la banda de / dos coma cuatro gigahercios. | Ubicar señal en banda esquemática. | 2,4 GHz | Alejar para revelar banda, pausa antes de cifra. |
| 27–30 s | Pero otros equipos también pueden usar esa banda. | Pero otros equipos / también pueden usar / esa banda. | Introducir una señal vecina como única novedad. | BANDA COMPARTIDA | Paneo corto al canal vecino. |
| 30–33 s | ¿Cómo evita quedarse en el mismo problema? | ¿Cómo evita quedarse / en el mismo problema? | Mantener señales; aislar zona de interferencia. | INTERFERENCIA | Detener cámara sobre conflicto para plantear giro. |
| 33–36 s | Los dispositivos coordinan cuándo transmitir y qué canal usar. | Los dispositivos coordinan / cuándo transmitir / y qué canal usar. | Mostrar coordinación entre extremos, una relación causal. | COORDINACIÓN | Alejar para ver ambos extremos. |
| 36–39 s | Los siguientes paquetes pueden usar canales distintos. | Los siguientes paquetes / pueden usar / canales distintos. | Cada nueva emisión usa un canal; no mover emisión pasada. | CAMBIO DE CANAL | Seguir una nueva emisión en paralelo al canal. |
| 39–42 s | Así reducen el efecto de algunas interferencias. | Así reducen / el efecto / de algunas interferencias. | Comparar recepción con interferencia y transmisión posterior. | MENOS INTERFERENCIA | Mantener escala común para comparar. |
| 42–45 s | La señal llega al receptor de los auriculares. | La señal llega / al receptor / de los auriculares. | Receptor convierte señal recibida en datos. | RECEPTOR | Entrar al auricular siguiendo la llegada. |
| 45–48 s | Allí, los datos permiten reconstruir el audio. | Allí, los datos / permiten reconstruir el audio. | Representar decodificación sin imponer codec universal. | DECODIFICACIÓN | Acercarse al bloque que reconstruye audio. |
| 48–51 s | Una señal eléctrica hace vibrar el pequeño transductor. | Una señal eléctrica / hace vibrar / el pequeño transductor. | Mostrar vibración ligada a señal de audio. | TRANSDUCTOR | Acompañar movimiento del diafragma. |
| 51–54 s | Alejate: muchos paquetes sostienen esa música que parece continua. | Alejate: muchos paquetes / sostienen esa música / que parece continua. | Multiplicar envíos esquemáticos; revelar canción como continuidad. | MUCHOS PAQUETES | Salto de escala al enlace completo. |
| 54–56 s | El enlace local funciona sin necesitar internet. | El enlace local funciona / sin necesitar internet. | Eliminar dependencia de red externa; enlace local continúa. | ENLACE LOCAL | Volver al par de dispositivos. |
| 56–60 s | Enviáselo a ese amigo que vive enredado con la tecnología. | Enviáselo a ese amigo / que vive enredado / con la tecnología. | Auriculares siguen reproduciendo, cierre con mismo enlace. | Sin etiqueta adicional | Asentar plano; posible vuelta suave al inicio. |

## Fuentes y comprobaciones pendientes

Antes de producir, verificar en documentación técnica Bluetooth la banda de 2,4 GHz, descubrimiento/conexión, emparejamiento, paquetes y coordinación de canales; documentar perfil de audio elegido. No prometer interferencia cero ni presentar el salto de canal como trayectoria física cambiante del mismo paquete. Una aplicación de streaming puede necesitar internet aunque el enlace Bluetooth local no lo necesite. Este documento no representa una nueva consulta de fuentes.

El ritmo escrito se aproxima a la locución de G6; no prueba duración real. Usar una sola voz y dejar micropausas antes de las cifras sin forzar una lectura rápida. Medir palabras y pausas, corregir bloques y luego comprobar karaoke, cámara y audio. Los subtítulos irán **centrados horizontalmente en el tercio superior**, según G4, nunca en la ubicación inferior de los ejemplos históricos.
