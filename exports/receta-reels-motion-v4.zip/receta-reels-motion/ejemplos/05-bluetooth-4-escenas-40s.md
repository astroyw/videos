> **HISTÓRICO V3 — no usar como formato de nuevos videos.** Se conserva este ejemplo de 40 s como registro. La norma vigente está en [guia-formato.md](../guia-formato.md). Usar el [nuevo ejemplo de 60 s](09-bluetooth-60s.md). Sus tiempos anteriores no son una alineación real de audio.

# ¿Cómo funciona el Bluetooth? — ejemplo editorial v3

Plan propuesto, no video generado ni estilo probado. 1080×1920, 30 FPS, 40 s (1200 cuadros). El CSV asociado separa escena, pulso y subtítulo; sus IDs nunca se muestran en pantalla. Los tiempos son de lectura, no una alineación con una voz existente.

| Escena interna | Tiempo / cuadros | Varias acciones dentro de la escena | Enlace motivado |
| --- | --- | --- | --- |
| Celular y auriculares | 0–9 s / 0–270 | Pregunta «¿Cómo funciona el Bluetooth?» como primer subtítulo de 0–3 s a 72 px de referencia. Se detectan dispositivos, se emparejan y aparece el enlace. La pregunta sale suavemente y no vuelve. | Entre 8,5 y 9,5 s, acercarse a la pantalla del celular manteniendo su contorno como referencia; revelar el audio en su interior. |
| Interior del celular | 9–18 s / 270–540 | Audio representado esquemáticamente como datos; agruparlos en paquetes; uno se acerca a la salida de radio. Mantener los objetos mientras cambian los subtítulos. | Entre 17,5 y 18,5 s, seguir el paquete seleccionado desde la salida al espacio que representa la transmisión. Su posición, color y dirección continúan. |
| Recorrido de un paquete | 18–30 s / 540–900 | Mostrar transmisión por radio, coordinación de canales y efecto de una interferencia. Los paquetes siguientes usan otros canales; representar la emisión con un esquema, no una pelota física. | Entre 29,5 y 30,5 s, acompañar el paquete hasta el receptor; la silueta del auricular revela el nuevo contexto. |
| Interior del auricular y sonido | 30–40 s / 900–1200 | Datos recibidos, decodificación y señal que mueve el transductor; alejarse hacia los auriculares reproduciendo sonido. Resolver la pregunta antes de 37 s; CTA única de 37 a 40 s. | La acción continúa suavemente hasta el final; sin placa nueva. |

Los intervalos de transición atraviesan los límites editoriales y se resuelven en una única línea de tiempo global; no se suman a los 40 s. Los contextos cambian, el recorrido mantiene la orientación. No usar cuatro pantallas independientes con un fundido automático.

Durante el desarrollo solo subtítulos (48–60 px) y etiquetas breves como «datos», «radio» o «decodificación» junto a los objetos. No hay título permanente, marca fija ni nombre de sección. Ampliar los objetos en el espacio libre arriba y mantener la zona esencial x=90…900, y=240…1450. Revisar el resultado en celular.

## Retención y matices

La pregunta principal tiene respuesta progresiva. A mitad del recorrido, «¿Y si otra señal interfiere?» funciona como microgancho en subtítulo normal, sin reiniciar escena ni reponer el título inicial. Mostrar la coordinación y reducción de interferencias como respuesta.

La radio usa la banda de 2,4 GHz. Los datos se representan por paquetes; sus bloques visibles son un esquema. El salto entre canales es coordinado, no un cambio arbitrario del camino físico de una onda. Evitar mostrar el mismo paquete cambiando mágicamente de canal a mitad de emisión. No afirmar que desaparecen todas las interferencias. Un enlace Bluetooth local no necesita internet, aunque una aplicación de streaming sí pueda necesitarlo. El ejemplo de audio no describe todos los perfiles ni todas las variantes de Bluetooth; investigar fuentes técnicas antes de producirlo.

## Voz y comprobación pendiente

Base sin voz. Si se solicita: español rioplatense natural, cálido y acogedor; generar o recibir la narración y medir sus frases y pausas antes de cerrar tiempos de subtítulos y acciones. Ajustar el guion si hace falta para conservar 40 s, sin forzar una velocidad antinatural.

Al implementarlo, revisar las tres transiciones, la salida de la pregunta a los 3 s, muestras del desarrollo sin encabezados y CTA de 37–40 s. Este documento y su CSV no prueban una animación ni una sincronización real.
