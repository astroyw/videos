> **HISTÓRICO V3 — no usar como formato de nuevos videos.** Se conserva este ejemplo de 40 s como registro. La norma vigente está en [guia-formato.md](../guia-formato.md). Usar el [nuevo ejemplo de 60 s](08-ventana-60s.md). Sus tiempos anteriores no son una alineación real de audio.

# Ventana: ejemplo de planificación continua

Este documento muestra cómo aplicar la corrección del usuario. **No es un video nuevo ni una implementación ya probada.** El MP4 anterior sirve para identificar el problema de los cortes; no es la referencia de ritmo a copiar.

Caso: ventana de aluminio abatible. Conservar los matices técnicos del sistema, no inventar cotas ni procedimientos universales. Las cuatro escenas siguientes presentan contextos o escalas distintos con varias acciones; se conectan siguiendo las piezas. La pregunta «¿Cómo se hace una ventana?» aparece solo como primer subtítulo a 72 px de referencia, 0–3 s, y sale suavemente. Después, solo subtítulos y etiquetas necesarias: sin título, marca o encabezado fijo.

| Escena | Tiempo / cuadros | Desarrollo visual continuo | Enlace hacia el siguiente |
| --- | --- | --- | --- |
| Del resultado a las piezas | 0–11 s / 0–330 | Mostrar la ventana terminada. Separar sus capas de manera esquemática; seguir un perfil que se desplaza hacia la zona de trabajo. Una cota recorre esa misma pieza. La herramienta corta y el tramo se separa. Los subtítulos cambian sin borrar la escena. | La cámara sigue el tramo cortado mientras gira hacia la posición que ocupará en el marco. |
| Construir el marco | 11–20 s / 330–600 | Mostrar los mecanizados previstos en la pieza. El tramo llega al conjunto; los otros lados se acercan y las escuadras se insertan. Las diagonales se dibujan sobre ese mismo marco; un sesgo se corrige y queda rectangular. | La cámara se aleja ligeramente; el marco permanece y deja espacio para la hoja. |
| Completar la hoja | 20–32 s / 600–960 | La hoja se arma junto al marco y se aproxima a él. Las bisagras y el cierre se colocan; una apertura demuestra su función. El vidrio seleccionado aparece a un costado; los calzos entran en sus apoyos y el paño se aproxima y asienta. | Acercamiento a un borde del vidrio ya colocado, conservando su esquina como referencia. |
| Sellar y comprobar | 32–40 s / 960–1200 | En el detalle, se ve cómo junquillo y burlete cumplen funciones distintas. La cámara vuelve al conjunto; la hoja cierra y la manija completa el recorrido. Sobre la ventana terminada aparece la CTA entre 37 y 40 s. | Cierre integrado en esta escena final, sin placa independiente. |

Evitar cortes bruscos. Mostrar los cambios de tiempo o escala mediante recorridos y referencias compartidas; no ocultar reinicios con fundidos. Un cambio de forma no debe fingir que el metal se estira físicamente: separar las piezas, moverlas y mostrar la unión real de forma esquemática.

El archivo `04-storyboard-continuo.csv` desglosa 14 pulsos y conserva estas cuatro escenas. Las columnas de objeto, acción y enlace deben completarse para cualquier otro tema antes de programar. No reutilizar el dibujo de una ventana para explicar otro mecanismo.

En la integración técnica, el ensamble puede desarrollarse íntegro en HyperFrames y continuar en Remotion desde una pose compartida. El corte de herramientas se hace por necesidad narrativa, no por la cantidad de subtítulos. La selección exacta de tecnología no debe introducir saltos visuales.
