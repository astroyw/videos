# Ventana de aluminio — propuesta de un minuto

Norma única: [guia-formato.md](../guia-formato.md), G1–G6. **Plan editorial de 60 s, no render ni voz producidos.** Los tiempos de cada beat son provisionales; se ajustan a la grabación y alineación reales antes de animar karaoke. Los `/` separan bloques de subtítulos y no se muestran.

**Concepto:** una ventana es un sistema de piezas medidas, mecanizadas, unidas y ajustadas; el orden y los detalles dependen del sistema elegido.

**Variante B:** taller nocturno 2.5D con perspectiva, fondo discreto y luces cálidas; maquinaria esquemática sin convertir el fondo en protagonista. **Metáfora: ninguna.** La misma pieza conduce las acciones. No mostrar dimensiones inventadas; el ángulo recto es una referencia geométrica, no una tolerancia industrial.

**Continuidad:** cero cortes propuestos. Perfil → unión → marco → hoja → borde del vidrio → conjunto. Un gesto de cámara o una referencia espacial conecta cada escala. El salto de 48–51 s revela cómo colaboran los detalles.

| tiempo | narración | bloque de subtítulo | visual | etiqueta/cifra en pantalla | movimiento de cámara |
| --- | --- | --- | --- | --- | --- |
| 00–03 s | ¿Cómo una barra se convierte en ventana? | ¿Cómo una barra / se convierte / en ventana? | Perfil protagonista a un lado de una ventana esquemática. | PERFIL | Seguir perfil hacia mesa de trabajo. |
| 03–06 s | Vamos a seguir una ventana de aluminio abatible. | Vamos a seguir / una ventana / de aluminio abatible. | Identificar marco y hoja del caso elegido. | ABATIBLE | Acercarse al borde que contiene el perfil. |
| 06–09 s | Primero se definen las medidas del proyecto. | Primero se definen / las medidas / del proyecto. | Cota animada recorre el hueco sin inventar dimensiones. | MEDIDAS DEL PROYECTO | Alejar para revelar hueco y cota. |
| 09–12 s | El sistema elegido determina perfiles, uniones y accesorios. | El sistema elegido / determina perfiles, / uniones y accesorios. | Destacar el perfil correspondiente como una selección. | SISTEMA | Volver al perfil elegido. |
| 12–15 s | Después se mide la pieza que vamos a cortar. | Después se mide / la pieza / que vamos a cortar. | Trasladar la longitud de proyecto a la pieza. | LONGITUD | Seguir extremo del perfil en mesa. |
| 15–18 s | La herramienta corta; el tramo se separa. | La herramienta corta; / el tramo / se separa. | Corte esquemático y separación de la misma pieza. | CORTE | Acompañar el tramo sin salto de posición. |
| 18–21 s | Recibe los mecanizados que requiere ese sistema. | Recibe los mecanizados / que requiere / ese sistema. | Mostrar un mecanizado identificado en el plano. | MECANIZADO | Acercarse a zona de trabajo; mantener borde. |
| 21–24 s | Cada extremo debe coincidir con su unión correspondiente. | Cada extremo / debe coincidir / con su unión correspondiente. | Conector entra en posición sin deformar metal. | UNIÓN | Girar cámara para revelar el encaje. |
| 24–27 s | Las piezas se juntan y forman el marco. | Las piezas se juntan / y forman / el marco. | Completar ensamblaje del marco como resultado de uniones. | MARCO | Alejar siguiendo la esquina ensamblada. |
| 27–30 s | Se comprueba que las esquinas queden a escuadra. | Se comprueba / que las esquinas / queden a escuadra. | Escuadra se aproxima y revela ángulo recto. | 90° | Recorrer esquina y detenerse para la comprobación. |
| 30–33 s | La hoja móvil se arma para encajar adentro. | La hoja móvil / se arma / para encajar adentro. | Revelar hoja correspondiente y acercarla al marco. | HOJA | Paneo corto desde marco hacia hoja. |
| 33–36 s | Las bisagras permiten el giro de esa hoja. | Las bisagras permiten / el giro / de esa hoja. | Instalar bisagra y demostrar un giro contenido. | BISAGRA | Seguir eje de giro sin perder marco. |
| 36–39 s | El herraje de cierre mantiene la hoja en posición. | El herraje de cierre / mantiene la hoja / en posición. | Mostrar cierre actuando sobre la misma hoja. | CIERRE | Seguir borde hasta punto de cierre. |
| 39–42 s | Para colocar el vidrio, preparamos sus apoyos. | Para colocar el vidrio, / preparamos sus apoyos. | Revelar calzos especificados para el sistema. | APOYOS | Entrar al borde inferior de la hoja. |
| 42–45 s | Los calzos distribuyen la carga según el diseño. | Los calzos distribuyen / la carga / según el diseño. | Vidrio asienta sobre apoyos; flechas explican carga. | CARGA | Mantener detalle para leer la causa. |
| 45–48 s | Junquillos y juntas cumplen funciones diferentes alrededor del vidrio. | Junquillos y juntas / cumplen funciones diferentes / alrededor del vidrio. | Comparar retención y sellado como una relación funcional. | RETENCIÓN Y SELLADO | Recorrer sección del borde hacia la esquina. |
| 48–51 s | Del detalle al conjunto: todas esas piezas trabajan juntas. | Del detalle al conjunto: / todas esas piezas / trabajan juntas. | Una esquina revela hoja, marco y ventana completa. | CONJUNTO | Salto de escala hacia ventana terminada. |
| 51–54 s | Abrimos y cerramos para comprobar su funcionamiento. | Abrimos y cerramos / para comprobar / su funcionamiento. | Mostrar una apertura y cierre continuo. | FUNCIONAMIENTO | Acompañar arco de apertura. |
| 54–56 s | Después se revisan ajustes y sellos del sistema. | Después se revisan / ajustes y sellos / del sistema. | Resaltar recorrido de comprobación sin afirmar ensayo normativo. | REVISIÓN | Deslizar atención por perímetro y asentar. |
| 56–60 s | Enviáselo a ese amigo que siempre deja todo abierto. | Enviáselo a ese amigo / que siempre deja / todo abierto. | La ventana termina cerrando con suavidad. | Sin etiqueta adicional | Fijar encuadre final con luz cálida. |

## Fuentes y comprobaciones pendientes

Antes de producir, elegir y documentar un sistema real de aluminio abatible: manual del fabricante, selección de herrajes, mecanizados, ensamblaje, acristalamiento y calzado. No generalizar tipo de corte, tornillos, sellos, drenajes o posición de calzos de un sistema a todos. El video explica el proceso; no reemplaza instrucciones de instalación ni ensayos. Las fuentes no fueron consultadas de nuevo en esta actualización.

El ritmo escrito se aproxima a la locución de G6; no prueba duración real. Usar una sola voz y dejar micropausas antes de las cifras sin forzar una lectura rápida. Medir palabras y pausas, corregir bloques y luego comprobar karaoke, cámara y audio. Los subtítulos irán **centrados horizontalmente en el tercio superior**, según G4, nunca en la ubicación inferior de los ejemplos históricos.
