# Gasificación — propuesta de un minuto

Norma única: [guia-formato.md](../guia-formato.md), G1–G6. **Plan editorial de 60 s, no render ni voz producidos.** Los tiempos de cada beat son provisionales; se ajustan a la grabación y alineación reales antes de animar karaoke. Los `/` separan bloques de subtítulos y no se muestran.

**Concepto:** frío y presión favorecen la disolución; al abrir, baja la presión y el exceso de gas alimenta burbujas.

**Variante A. Metáfora central: ninguna.** El propio mecanismo sirve como protagonista. Los diagramas moleculares y de fábrica son esquemas, no escalas físicas ni simulaciones cuantitativas. El salto del último tercio conecta una cavidad con muchos puntos de nucleación. No agregar cifras industriales universales: las comparaciones mantienen explícitamente la otra variable.

**Continuidad:** cero cortes propuestos; conducto, volumen de líquido, pared y burbuja conducen los encuadres. Una novedad principal por beat; las partes existentes siguen actuando.

| tiempo | narración | bloque de subtítulo | visual | etiqueta/cifra en pantalla | movimiento de cámara |
| --- | --- | --- | --- | --- | --- |
| 00–03 s | ¿De dónde salen las burbujas? | ¿De dónde salen / las burbujas? | Botella cerrada: una burbuja ampliada plantea el mecanismo. | CO₂ | Acercamiento al cuello; conservar silueta. |
| 03–06 s | El protagonista es un gas: dióxido de carbono. | El protagonista es / un gas: / dióxido de carbono. | Introducir una molécula lineal, como esquema. | CO₂ | Seguir la molécula al conducto del tanque. |
| 06–09 s | En la fábrica, ese gas toca la bebida. | En la fábrica, / ese gas toca / la bebida. | Revelar interfaz gas-líquido, sin nueva escena abrupta. | CONTACTO | Alejar desde la molécula hasta el tanque. |
| 09–12 s | Favorecer la disolución es la clave. | Favorecer la disolución / es la clave. | Resaltar el intercambio en la misma interfaz. | DISOLUCIÓN | Sostener encuadre para leer la causa. |
| 12–15 s | Primero, el líquido se mantiene bien frío. | Primero, el líquido / se mantiene / bien frío. | Bajar gradualmente la temperatura representada. | FRÍO | Paneo corto al indicador junto al tanque. |
| 15–18 s | A igual presión, puede retener más gas disuelto. | A igual presión, / puede retener / más gas disuelto. | Comparar dos estados del mismo líquido a igual presión. | MÁS CO₂ DISUELTO | Abrir encuadre conservando el tanque original. |
| 18–21 s | También se aumenta la presión del dióxido de carbono. | También se aumenta / la presión / del dióxido de carbono. | Elevar manómetro suavemente; temperatura ahora constante. | PRESIÓN DE CO₂ | Volver al manómetro integrado en el tanque. |
| 21–24 s | A igual temperatura, se disuelve más. | A igual temperatura, / se disuelve más. | Aumentar presencia de moléculas disueltas sin burbujas. | MÁS CO₂ DISUELTO | Acercarse a la interfaz manteniendo su borde. |
| 24–27 s | Disuelto significa moléculas repartidas dentro del líquido. | Disuelto significa / moléculas repartidas / dentro del líquido. | Revelar moléculas de CO₂ entre agua en movimiento. | DISUELTO | Entrar al detalle molecular esquemático. |
| 27–30 s | No son burbujitas esperando escondidas en la bebida. | No son burbujitas / esperando escondidas / en la bebida. | Contrastar moléculas individuales con una burbuja representativa. | MOLÉCULAS | Desplazar foco sin introducir otro protagonista. |
| 30–33 s | Después, el líquido llega al llenador. | Después, el líquido / llega al llenador. | Seguir un volumen de líquido por el conducto. | LLENADO | Seguir el flujo y revelar el envase. |
| 33–36 s | La contrapresión ayuda a perder menos gas allí. | La contrapresión ayuda / a perder / menos gas allí. | Mostrar transferencia conservando la condición de presión. | CONTRAPRESIÓN | Paneo continuo al cuello conectado al llenador. |
| 36–39 s | El cierre mantiene el envase sellado y presurizado. | El cierre mantiene / el envase sellado / y presurizado. | Bajar tapa y conservar líquido y gas superior. | SELLADO | Alejar ligeramente al completar el cierre. |
| 39–42 s | Cuando lo abrís, la presión empieza a caer. | Cuando lo abrís, / la presión empieza / a caer. | Abrir tapa; manómetro cae antes de formar burbujas. | MENOS PRESIÓN | Seguir la tapa y volver al líquido. |
| 42–45 s | Ahora hay más gas disuelto del que puede retener. | Ahora hay / más gas disuelto / del que puede retener. | Revelar exceso de CO₂ respecto del nuevo equilibrio. | SOBRESATURACIÓN | Acercamiento al borde del envase. |
| 45–48 s | Pequeñas cavidades pueden facilitar que nazca una burbuja. | Pequeñas cavidades / pueden facilitar / que nazca una burbuja. | Mostrar una cavidad con bolsillo de gas que crece. | NUCLEACIÓN | Entrar a una cavidad manteniendo la pared visible. |
| 48–51 s | El gas disuelto la alimenta; entonces empieza a crecer. | El gas disuelto / la alimenta; / entonces empieza a crecer. | Moléculas cruzan hacia una sola burbuja en crecimiento. | CRECIMIENTO | Seguir borde de la burbuja suavemente. |
| 51–54 s | Alejate: ese proceso puede repetirse en muchos puntos. | Alejate: ese proceso / puede repetirse / en muchos puntos. | Multiplicar sitios esquemáticos: una burbuja revela el conjunto. | MUCHOS PUNTOS | Salto de escala hacia el envase completo. |
| 54–56 s | Las burbujas ascienden y el gas se libera. | Las burbujas ascienden / y el gas / se libera. | Seguir ascenso hasta superficie y liberación. | GAS LIBERADO | Acompañar una burbuja y revelar la boca. |
| 56–60 s | Enviáselo a ese amigo que acusa a las burbujas. | Enviáselo a ese amigo / que acusa / a las burbujas. | Continuar una burbuja suave junto a la botella abierta. | Sin etiqueta adicional | Asentar encuadre; cierre sin corte. |

## Fuentes y comprobaciones pendientes

Antes de producir, verificar en fuentes de química física la dependencia de solubilidad con temperatura y presión parcial de CO₂, la sobresaturación y la nucleación; y en documentación del sistema industrial elegido el llenado a contrapresión. Registrar enlaces reales y afirmación respaldada. La secuencia industrial es un ejemplo, no una receta universal. No se realizó una búsqueda de fuentes nueva para este documento.

El ritmo escrito se aproxima a la locución de G6; no prueba duración real. Usar una sola voz y dejar micropausas antes de las cifras sin forzar una lectura rápida. Medir palabras y pausas, corregir bloques y luego comprobar karaoke, cámara y audio. Los subtítulos irán **centrados horizontalmente en el tercio superior**, según G4, nunca en la ubicación inferior de los ejemplos históricos.
