# Cómo comprobar el formato

La autoridad es [guia-formato.md](guia-formato.md). El **único checklist de 15 puntos** está en `agentes/revisor-formato.md`; registrar sus resultados en `plantillas/informe-revision.md`. Este documento explica métodos, no agrega otro estándar.

## Evidencia técnica

Medir el MP4 destinado a entrega, no un máster previo:

```bash
ffprobe -v error -count_frames -show_streams -show_format -of json video-final.mp4
ffmpeg -v error -xerror -i video-final.mp4 -f null -
ffmpeg -hide_banner -i video-final.mp4 -vn -af loudnorm=print_format=json -f null -
ffmpeg -hide_banner -i video-final.mp4 -vn -af volumedetect -f null -
```

El `input_i` del análisis loudnorm describe sonoridad integrada de entrada y su `input_tp` es true peak; no confundirlo con pico de muestras. Para la aceptación de G1, el pipeline debe medir el pico del audio decodificado con precisión adecuada y registrar las unidades; `volumedetect` sirve como inspección auxiliar, no para fingir exactitud sin revisar redondeo. Repetir medición tras cualquier nueva codificación AAC.

Validar duración usando el timeline a la frecuencia de G1 y tolerancia razonable del contenedor/audio; no comparar exclusivamente un valor redondeado. Registrar cuadros decodificados y duraciones de streams. Validar rango corto/profundo y justificación, no una duración vieja codificada en el script.

## Texto, audio y movimiento

Revisar tiempos de palabras ordenados y coherentes con el archivo de voz usado; hashes permiten detectar un cambio de audio posterior. Esos controles no certifican que un alineador reconoció cada palabra correctamente. Escuchar y corregir desfases cuando sea posible; declarar limitaciones.

Comprobar G4 con capturas de una y dos líneas: medir centro horizontal, posición superior, ancho y altura. Revisar también frames antes/durante/después de los cambios de palabra para descartar reflujo. No sustituir este control por buscar `textAlign:center` en el código.

Inspeccionar secuencias alrededor de cortes, morphs y cambios de escala, así como muestras dentro de cada beat. Una métrica de diferencias de píxeles detecta cambios, no garantiza continuidad. El conteo declarado de cortes necesita comparación con el resultado visible.

## Integridad de entrega

Distinguir pruebas documentales, de código, capturas y audiovisual completo. Comprobar ZIP por CRC, extraerlo y validar hashes; excluir dependencias instaladas, cachés, credenciales y renders ajenos a la entrega. Mantener licencias. Registrar resultados reales, fallos corregidos y pendientes sin reutilizar aprobaciones históricas para un video nuevo.
