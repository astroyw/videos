# Claude Code — receta v4

Leer `AGENTS.md`, `README.md` y [guia-formato.md](guia-formato.md). La guía es la única fuente del formato; no duplicar sus reglas aquí. Ejecutar los roles de `agentes/` en el orden del README y devolver al responsable cualquier fallo del Revisor.

Usar las plantillas de salida. Respetar el alcance del pedido: una actualización de documentación o código de la receta no solicita generar un video. Preservar el proyecto y no publicar sin autorización. Para tareas de video, leer las skills pertinentes del proyecto. No reemplazar alineación real por tiempos estimados ni declarar pruebas no ejecutadas.
