# Informe del Revisor de formato

Norma única: [guia-formato.md](../guia-formato.md). Usar el checklist oficial del [Revisor](../agentes/revisor-formato.md), sin mantener una segunda copia de sus criterios.

- Entrega y versión revisada: [ruta/hash].
- Tipo de revisión: [documentación/código/fotogramas/reproducción/audio].
- Fecha y herramientas: [completar].
- Alcance que no se pudo comprobar: [completar; no ocultar].

| punto del checklist oficial | regla de la guía | estado | evidencia concreta | corrección / responsable |
| --- | --- | --- | --- | --- |
| [ID] | [G1–G6] | [cumple / no cumple / no comprobado] | [medición, archivo o instante] | [acción] |

Completar los 15 puntos del checklist oficial. No convertir una comprobación no ejecutada en aprobación. En una actualización documental, duración real, voz, karaoke, loudness y fluidez del video quedan **no comprobados**, aunque las instrucciones sean coherentes.

## Resultado

[Conforme / requiere correcciones / revisión incompleta]. Enumerar fallos concretos, responsable y evidencia esperada. Comprobar subtítulos centrados horizontalmente en la posición superior establecida por G4, tanto en una como en dos líneas.

Separar pico de muestras en dBFS y true peak en dBTP cuando se mida este último; no sustituir una unidad por otra en el informe. Registrar sincronización técnica y escucha real como evidencias distintas.
