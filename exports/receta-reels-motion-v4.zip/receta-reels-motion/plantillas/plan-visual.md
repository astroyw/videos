# Plan de Dirección de arte y animación

Aplicar exclusivamente [guia-formato.md](../guia-formato.md), G1–G6. Recibir la tabla del Guionista, fuentes y, antes de cerrar la sincronización, audio y alineación reales.

- Concepto y metáfora central: [confirmar una o ninguna].
- Variante A/B y justificación: [completar según G2].
- Objetos con identidad persistente: [IDs, estado inicial y final].
- Mapa global de cámara: [encuadres conectados; cortes enumerados y justificados según G3].
- Salto de escala del último tercio: [momento propuesto, causa, comparación y efecto].
- Subtítulos: [aplicación de G4; centrado horizontal explícito en la zona superior; revisar bloque completo sin oclusiones].
- Elementos recurrentes: [componentes y función según G5].
- Audio y karaoke: [archivo real, alineación disponible y cuestiones por resolver].

| beat / tiempo | estado heredado | única novedad | referencia que continúa | cámara / transición | evidencia a revisar |
| --- | --- | --- | --- | --- | --- |
| [ID / intervalo] | [pose, escala y estado] | [causa nueva] | [objeto o acción] | [trayectoria con llegada] | [cuadros o reproducción] |

Mantener por separado las pistas de mundo visual, cámara y subtítulos. No montar otra escena por cada bloque de texto. En la integración Remotion/HyperFrames, definir estados compartidos en las uniones y tiempos deterministas; el número de herramientas no debe introducir cortes.

Los zooms, desplazamientos y la multiplicación son representaciones explicativas: aclarar cambios de escala y no deformar hechos para conseguir una transición. No usar cifras inventadas para llenar etiquetas. Resolver las discrepancias factuales con el Guionista antes de animar.

Entrega al Revisor: proyecto, guion, fuentes, audio y alineación, render cuando la tarea lo solicite, mapa de cortes y evidencia. Declarar por separado lo implementado, renderizado y revisado; este plan no prueba un resultado visual.
