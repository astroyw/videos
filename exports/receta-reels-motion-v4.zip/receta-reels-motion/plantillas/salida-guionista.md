# Plantilla de salida del Guionista

Norma única: [guia-formato.md](../guia-formato.md), especialmente G3, G4 y G6. Esta plantilla organiza la salida; no reemplaza la guía.

## Brief resuelto

- Tema y concepto que debe entenderse: [completar].
- Formato elegido y duración editorial: [corto/profundo y duración; justificar profundo].
- Variante visual propuesta: [A/B y razón; confirmar con Dirección de arte].
- Metáfora central: [una, o ninguna si el mecanismo literal es más claro].
- Pregunta/demostración inicial: [completar].
- Giro y salto de escala del último tercio: [qué revela y por qué aporta].
- Cierre: [remate para compartir o revelación del título].
- Fuentes por afirmación: [enlace, hecho que sostiene y estado de verificación].
- Voz: [dirección interpretativa; recurso pendiente o archivo real autorizado].

## Tabla editorial

Usar exactamente estas seis columnas. `tiempo` es el intervalo del beat; los bloques de subtítulos dentro de una fila se separan por `/`, que **no se imprime en pantalla**. Varias unidades de lectura pueden corresponder a una sola novedad visual. El contenido de las seis columnas es una propuesta, no un registro de audio ya grabado.

| tiempo | narración | bloque de subtítulo | visual | etiqueta/cifra en pantalla | movimiento de cámara |
| --- | --- | --- | --- | --- | --- |
| [inicio–fin] | [Frase hablada y pausa antes de cifra] | [Bloque breve uno] / [Bloque breve dos] | [Única novedad; estado que permanece] | [Dato principal; fuente en notas] | [Recorrido y referencia de llegada] |

Según G3, un beat dura 2–4 s y aporta un solo elemento narrativo nuevo. Según G4, cada bloque de subtítulo tiene 2–5 palabras: **beat y bloque no son equivalentes**. Con una locución de unas 2,5 palabras/s, un beat contiene aproximadamente 5–10 palabras y puede requerir dos o más bloques. La división debe preservar la sintaxis y seguir el audio, no cortar mecánicamente cada cierto número de caracteres.

Las micropausas se indican en las notas de narración, por ejemplo `[pausa breve]`, y no se pronuncian ni se queman como texto. Los números y unidades se escriben como se leen cuando haga falta facilitar la locución; mantener su representación visual clara.

## Después de producir la voz

1. Medir el audio final autorizado y obtener intervalos reales de cada palabra. Guardarlos en un artefacto técnico como `palabras.json`; esta tabla no inventa esos tiempos.
2. Ajustar beats, acciones y bloques a las frases y pausas reales, conservando los requisitos de G1, G3 y G6. Acortar o regrabar si la voz queda apurada.
3. Enviar a Dirección de arte el guion, audio, alineación, fuentes y límites pendientes. El karaoke de G4 se comprueba con la palabra pronunciada, no estimando todas las palabras a igual duración.

El CSV asociado ofrece 20 beats de tres segundos como esqueleto de un minuto. Son intervalos editoriales editables, no un límite fijo para todos los temas ni una narración sincronizada.
