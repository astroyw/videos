# Receta Reels · formato v4

**Tema → Guionista → Director de arte/animación → Revisor**

La autoridad para TODOS los videos nuevos es [guia-formato.md](guia-formato.md). Incluye la posición obligatoria de los **subtítulos centrados horizontalmente en la zona superior**, el estilo y los parámetros técnicos. No tomar especificaciones de las demos históricas.

## Cómo usar la carpeta

1. Abrí esta carpeta con Codex o Claude Code. En un repositorio existente, integrala como subcarpeta sin reemplazar su aplicación.
2. Completá `01-PROMPT-EDITABLE.md` con el tema y pegá su contenido. Adjuntá la carpeta: el prompt remite a la guía y no contiene una segunda copia de ella.
3. El agente sigue las tres responsabilidades de abajo. Pueden ejecutarse secuencialmente por un mismo asistente; estos archivos no instalan automáticamente subagentes en el cliente.
4. Para producir un video final hacen falta narración y alineación reales. La receta y las muestras técnicas no aportan una grabación de cada tema.

| Etapa | Lee | Entrega a la siguiente etapa |
| --- | --- | --- |
| Tema / brief | `01-PROMPT-EDITABLE.md` y guía | Tema, público, idea, versión y restricciones |
| Guionista | `agentes/guionista.md` | Concepto, fuentes y tabla de `plantillas/salida-guionista.md` |
| Director de arte/animación | `agentes/director-arte-animacion.md` | Plan visual, narración/alineación, fuentes Remotion/HyperFrames y archivo final cuando se solicite producirlo |
| Revisor | `agentes/revisor-formato.md` | 15 resultados con evidencia y correcciones; retorno al responsable si falla algo |

El revisor comprueba borradores antes de exportar y el archivo real después. Un control pendiente no se convierte en aprobación. Los tiempos del Guionista se ajustan al audio antes de cerrar montaje y karaoke.

## Edición y tecnología

`guia-formato.md` contiene también el bloque de parámetros ejecutables. La plantilla genera su configuración a partir de él; no editar los archivos derivados para cambiar el formato. Los agentes y guías de proceso enlazan a la misma fuente.

`plantilla-remotion/README.md` explica los comandos de la nueva ruta y los comandos explícitos de la demo histórica. Los componentes son una base técnica: cada tema necesita su mecanismo, assets y animación; no basta reemplazar textos. Los ejemplos editoriales nuevos están en `ejemplos/` y los nombres con `40s` se conservan como historia.

## Qué contiene esta actualización

- Guía única, agentes, prompt editable y plantillas de salida.
- Guías prácticas para narración, animación y comprobación.
- Ejemplos editoriales vigentes y anteriores identificados.
- Base técnica nueva y demo anterior preservada.
- `CAMBIOS-V4.md`, `RESULTADO-POR-ARCHIVO.md` y `VERIFICACION.md` para saber qué cambió y qué se probó.

Esta entrega actualiza la receta. No incluye un Reel nuevo ni afirma que una animación completa del estilo v4 fue renderizada. La verificación de código o de una captura no sustituye escuchar y revisar el futuro video.
