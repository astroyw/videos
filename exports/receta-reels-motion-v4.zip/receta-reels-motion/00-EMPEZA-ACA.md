# Empezá acá — receta v4

Leé [README.md](README.md) para usar el flujo **Tema → Guionista → Director de arte → Revisor**. La única especificación vigente es [guia-formato.md](guia-formato.md), incluido el centrado obligatorio de los subtítulos.

Completá `01-PROMPT-EDITABLE.md` (o su copia TXT idéntica), adjuntá esta carpeta y pegá el prompt. La guía contiene los valores de duración, formato, composición y sonido; el brief elige el tema y las variantes permitidas.

Los ejemplos viejos y la demo histórica se preservan para consulta, no se usan como valores iniciales. No copiar un AGENTS.md del kit encima del de otro proyecto. `CAMBIOS-V4.md` describe esta actualización y `VERIFICACION.md` distingue pruebas realizadas y pendientes.
