# Cambios de la receta v4

Actualización aprobada por el usuario después del diagnóstico y plan. Énfasis adicional incorporado: **SUBTÍTULOS CENTRADOS**. La especificación vigente está en `guia-formato.md`.

- Se creó la guía única con G1–G6 y su bloque de parámetros ejecutables. Los agentes consultan esa fuente, sin mantener configuraciones paralelas.
- Se creó el flujo Tema → Guionista → Director de arte/animación → Revisor, con tres archivos de rol y un checklist único de 15 puntos.
- Se actualizaron prompt MD/TXT, entrada al kit y guías de proceso. La fuente normativa pasó a ser la guía nueva; los documentos anteriores explican ahora su aplicación.
- Los subtítulos quedan centrados horizontalmente respecto del lienzo y con texto centrado, en la zona superior indicada por G4. La prueba de composición cubre una y dos líneas.
- La ruta nueva de Remotion deriva el formato de la guía, conserva objetos/cámara por tiempo y proporciona karaoke, píldoras, tags, barras, contadores, grillas y personaje. Cada tema todavía requiere diseñar y programar su mecanismo.
- La entrega requiere voz real y tiempos por palabra revisados. El pipeline contempla audio AAC, normalización y medición final; rechaza el proyecto de muestra sin audio en lugar de exportarlo como entrega.
- Se agregó una fuente HyperFrames de estudio de movimiento y un comando que usa los FPS de la guía. No se renderizó un clip nuevo ni se presenta el estudio como explicación científica aprobada.
- Se agregaron Figtree y su licencia, conservando Manrope y los recursos anteriores.
- Se agregaron plantillas de salida del Guionista, plan visual e informe del Revisor. Los nuevos ejemplos editoriales de gasificación, ventana y Bluetooth tienen sus propias acciones y propuesta de escala; no se afirma alineación con una voz inexistente.
- Se preservaron todos los paths existentes. Los ejemplos antiguos están identificados como históricos; los comandos de la demo técnica tienen prefijo `legacy:*`, y sus fuentes/MP4 originales siguen intactos.
- Se actualizó la sección de preferencia vigente del AGENTS.md del repositorio anfitrión para remitir a la nueva guía, conservando sus instrucciones de entorno.

## Entrega y límites

`RESULTADO-POR-ARCHIVO.md` muestra el resultado de cada archivo. `VERIFICACION.md` registra pruebas ejecutadas y límites. Se conserva evidencia de layout y audio de laboratorio en `verificacion/`; el audio de laboratorio es un tono sintético, no una narración.

Esta tarea actualiza carpeta, código de base y documentación. **No se creó otro video.** La fluidez, exactitud, escucha y sincronización de un Reel completo con el estilo nuevo se comprobarán al producirlo. Los ejemplos no están factual ni audiovisualmente aprobados por existir como tablas. Las pruebas anteriores permanecen como historia.
