# Agentes de la receta v4

Leer primero [guia-formato.md](guia-formato.md): es la **única fuente normativa de formato**. Sus apartados G1–G6 gobiernan toda nueva producción. Las instrucciones explícitas actuales del usuario prevalecen; no importar valores de v2/v3, ejemplos históricos ni defaults de skills que contradigan la guía.

Seguir `README.md`: `agentes/guionista.md` → `agentes/director-arte-animacion.md` → `agentes/revisor-formato.md`. Cada rol entrega los artefactos definidos por su plantilla. Consultar G4 en especial para el centrado de subtítulos; comprobarlo en la imagen renderizada además del código.

Los roles son instrucciones portables, no garantía de descubrimiento automático de subagentes. Un asistente puede ejecutar las tres fases con responsabilidades separadas.

Preservar archivos y dependencias existentes. No borrar ni publicar sin autorización. Leer skills locales de Remotion/HyperFrames para tareas técnicas, manteniendo precedencia de la guía y del usuario. Renderizar un video solo cuando el pedido sea producirlo: actualizar la receta no implica crear una nueva película.

Toda aprobación del Revisor necesita evidencia; distinguir resultado del código, captura, medición y escucha/reproducción humana. La plantilla técnica requiere contenido específico y audio/alineación reales para una entrega. Las vistas de muestra y las pruebas históricas no aprueban videos nuevos.
