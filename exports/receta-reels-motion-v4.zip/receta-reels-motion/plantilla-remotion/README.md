# Plantilla técnica V4

La fuente única de reglas es [guia-formato.md](../guia-formato.md). Los comandos normales usan `src/formato-v4/` y la composición **ReelFormatoV4**. La demo de gasificación anterior y sus salidas siguen intactas: consultar `README-LEGACY.md` y usar comandos `legacy:*` solo para reproducirla.

Esta entrega prepara la arquitectura, validadores y componentes; **no incluye un Reel nuevo ni una narración**. `src/formato-v4/project.json` está en modo `preview`, con una marca visible «NO ENTREGA». La exportación se bloquea hasta incorporar contenido, voz real, palabras alineadas y revisión. La muestra de subtítulos de preview tiene tiempos ficticios claramente identificados; nunca debe usarse como alineación real.

## Flujo de trabajo

1. Seguir Tema → Guionista → Director de arte → Revisor desde el README del kit.
2. Instalar dependencias con `npm ci` e instalar las skills locales según la guía 06. Mantener las versiones existentes.
3. Ejecutar `npm run sync:format`: genera la configuración técnica desde el bloque JSON de `../guia-formato.md`. No editar `formato.generated.json` a mano.
4. Completar una copia de `src/formato-v4/project.json` con el contenido del tema. El archivo que se pasa a los comandos es el objeto Project, no `{project: ...}`; el script genera las props internamente.
5. Usar `npm run check`, `npm run check:layout` y preview. Antes de exportar, ejecutar `npm run preflight -- ruta/proyecto.json`.
6. Solamente cuando se pide un video final: `npm run render -- ruta/proyecto.json`. El resultado se guarda en una subcarpeta con fecha bajo `out/formato-v4/`, para preservar salidas anteriores. Revisar el archivo final visual y auditivamente; el informe técnico no sustituye esa revisión.

Requisitos: Node >=22, FFmpeg/FFprobe y Chrome/Chromium compatible. Opcional `REMOTION_BROWSER_EXECUTABLE` para elegir navegador. Conservar proxy y certificados de una nube administrada; no desactivar TLS.

## Contrato de proyecto

- `edition`, `durationSeconds`, `deepReason`: seleccionar el rango definido en la guía; justificar versión profunda.
- `variant`, `metaphor`, `artReviewed`: variante A/B, una metáfora central (cadena vacía para un diagrama literal sin metáfora) y confirmación de revisión del diseño del tema. No marcar revisado si solo se usaron placeholders.
- `audio.src`: archivo relativo a `public/`. `audio.sha256`: SHA-256 del audio real que se alineó. `alignmentMethod`: cómo se midieron sus palabras. `alignmentReviewed`: confirmación de revisión; no generar timings uniformes y presentarlos como medición. Un cambio de audio invalida el hash y requiere realinear.
- `captions[]`: bloques con `id`, `startMs`, `endMs`, `words` y, opcionalmente, `lines`. Cada palabra usa campos de Caption: `text`, `startMs`, `endMs`, `timestampMs`, `confidence`; `key` puede activar una píldora cian. `lines: [[0,1],[2,3]]` coloca esas cuatro palabras en dos líneas. Cada línea y el bloque completo se centran respecto al lienzo; no desplazarlo por la interfaz lateral de redes.
- `beats[]`: `id`, `start/end` en segundos, `newElementId` del objeto afectado, `newElementDescription` de la única novedad (puede cambiar de estado un objeto existente), `narration`, `comparisonOrFigure`, cámara `{x,y,scale,rotation}`, transición y `scaleJump` cuando corresponda. La narración concatenada debe coincidir con las palabras de subtítulos. El beat y el subtítulo son unidades diferentes.
- `nodes[]`: objetos con ID estable, `kind`, texto/color/unidad y poses `{time,x,y,scale,rotation,opacity,value}`. La primera pose coincide con el beat que introduce ese objeto; si empieza después del inicio, parte de opacidad cero. Antes de la primera pose no se dibuja. Se interpolan desde un reloj global, sin reiniciar por subtítulo. Hay primitivas de círculo, caja, barra, contador, píldora, tag, grilla y personaje; el Director debe crear dibujos específicos del tema cuando sean necesarios. No fingir que cambiar textos produce otro mecanismo.
- `hyperframesClips[]`: necesario en entrega para usar ambas herramientas, `src` relativo a public, `start/duration` en segundos. Validar FPS observado, duración y continuidad al integrarlos; registrar procedencia para comprobar animación nativa, porque los metadatos no detectan duplicación de cuadros; la herramienta no obliga a alternar motores por frase.
- `closing`: tipo `cta` o `title`, instante de entrada y texto. La CTA debe estar en la narración/subtítulos; `title` permite revelar el concepto al final. No agregar títulos permanentes.

Las poses y movimientos de cámara son deterministas. El indicador de salto de escala y la declaración de revisión no prueban por sí solos calidad visual; el Revisor comprueba el movimiento real, la metáfora, el ritmo y la legibilidad.

## Comandos de revisión sin crear un video

```bash
npm run check
npm run check:layout
npm run still:format
```

`check` comprueba sincronización con la guía, TypeScript y validaciones de datos. `check:layout` carga la fuente y el componente de subtítulos real en Chromium: revisa una/dos líneas centradas y colores del karaoke. `still:format` produce solo un PNG de diagnóstico, marcado «NO ENTREGA», en `out/formato-v4-diagnostico/`; no contiene narración ni demuestra sincronía con voz. Se conserva fuera de los entregables de producción.

`npm run studio` abre la plantilla. Studio recibe el JSON importado por defecto; para previsualizar tu tema, apuntar el import de `index.tsx` a tu archivo o reemplazar el borrador conservando una copia. La ruta de exportación acepta cualquier archivo Project válido sin modificar el import.

## Audio y exportación futura

El renderer incluye la narración, conserva una pista AAC y ejecuta normalización en dos pasadas. Mide LUFS integrados y pico de muestras del **MP4 final**, no solo del WAV fuente. Informa true peak en dBTP por separado. Si los límites de la guía no se alcanzan, falla; no declara entrega verificada. El techo de trabajo del filtro usa un margen operativo de 0,5 dB bajo el techo de muestras para reducir sobrepicos de AAC y no redefine dBFS como dBTP.

```bash
npm run preflight -- proyecto.json
npm run render -- proyecto.json
npm run verify -- proyecto.json out/formato-v4/FECHA/video-final.mp4
```

El audio debe caber en la duración seleccionada; no se recorta ni acelera automáticamente. `verify` comprueba codec, resolución, FPS nominal/medio, cuadros, duración, AAC, niveles y decodificación completa. Guarda SRT por bloques además del karaoke quemado. La mezcla y la alineación con una narración nueva siguen pendientes hasta que se proporcione ese audio.

## HyperFrames V4

`hyperframes/formato-v4/index.html` es un estudio reusable de movimiento de seis segundos; **no es una explicación científica aprobada ni un render nuevo**. Adaptarlo al tema. Los scripts copian GSAP y generan la paleta desde la guía; conservan el clip molecular y la fuente antiguos.

```bash
cd hyperframes
npm ci
cd ..
npm run hyperframes:check
npm run hyperframes:preview
# Solo cuando el usuario pide producir el segmento:
npm run hyperframes:render
```

La nueva ruta pasa `--fps` desde la configuración y también declara `data-fps` en el HTML. El render se escribe en `hyperframes/formato-v4/renders/segmento-v4.mp4`; copiarlo a un path nuevo en `public/` antes de integrarlo, sin sobrescribir assets históricos. Si falta navegador, `HYPERFRAMES_BROWSER_PATH` selecciona uno instalado. Si el home es de solo lectura, elegir directorios escribibles para `HYPERFRAMES_FONT_CACHE_DIR` y `XDG_STATE_HOME`.

## Preservación y licencias

El código antiguo permanece en `src/index.tsx`, `src/Reel.tsx`, `src/visuals.tsx`, `src/storyboard.json` y scripts originales; las salidas antiguas se mantienen en `out/`. `package-legacy.json` conserva los comandos anteriores. `legacy:studio`, `legacy:render`, `legacy:verify` y otros comandos originales siguen disponibles con ese prefijo, pero no representan el formato vigente.

Se conservan Manrope, su licencia y el clip molecular. Figtree y su licencia están en `public/formato-v4/`. No se incluye voz, música de terceros ni credenciales. Consultar `PRUEBAS.md` para pruebas efectivamente ejecutadas y pendientes.
