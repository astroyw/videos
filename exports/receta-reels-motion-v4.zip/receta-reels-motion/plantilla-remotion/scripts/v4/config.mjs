import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import crypto from 'node:crypto';
export const root=fileURLToPath(new URL('../../',import.meta.url));
export const guidePath=path.resolve(root,'../guia-formato.md');
export function readFormat(){
 const guide=fs.readFileSync(guidePath,'utf8');
 const section=guide.split('<!-- formato-config:start -->')[1]?.split('<!-- formato-config:end -->')[0];
 const json=section?.match(/```json\s*([\s\S]*?)```/)?.[1];
 if(!json)throw new Error('Falta bloque formato-config en ../guia-formato.md.');
 const config=JSON.parse(json);
 return {config,sourceSha256:crypto.createHash('sha256').update(json.trim()).digest('hex')};
}
export function publicPath(relative){
 if(typeof relative!=='string'||!relative||relative.includes('\\')||path.isAbsolute(relative))throw new Error('Asset debe tener ruta relativa a public/.');
 const p=path.resolve(root,'public',relative),base=path.resolve(root,'public')+path.sep;
 if(!p.startsWith(base))throw new Error('Asset fuera de public/.');
 return p;
}
