import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {root,readFormat} from './config.mjs';
import {run} from './cli.mjs';
import {measureAudio,normalizationFilter,assertLevels} from './audio.mjs';
const c=readFormat().config;
test('real two-pass normalization and final AAC measurement (synthetic tone, not speech)',()=>{
 const dir=path.join(root,'out/formato-v4-diagnostico/audio-fixture');fs.mkdirSync(dir,{recursive:true});
 const input=path.join(dir,'signal.wav'),output=path.join(dir,'normalized.m4a');
 run('ffmpeg',['-y','-v','error','-f','lavfi','-i','aevalsrc=0.035*sin(2*PI*430*t)+0.015*sin(2*PI*997*t):s=48000:d=6','-c:a','pcm_s16le',input]);
 const first=measureAudio(input,c);assert.ok(first.integratedLufs<c.audio.integratedLufs-1,'fixture should need gain');
 run('ffmpeg',['-y','-v','error','-i',input,'-af',normalizationFilter(first,c),'-c:a','aac','-b:a','192k','-ar','48000',output]);
 const final=measureAudio(output,c);assertLevels(final,c);
 fs.writeFileSync(path.join(dir,'measurement.json'),JSON.stringify({kind:'Synthetic test tone, no voice or video',firstPass:{integratedLufs:first.integratedLufs,samplePeakDbfs:first.samplePeakDbfs},final:{integratedLufs:final.integratedLufs,samplePeakDbfs:final.samplePeakDbfs,truePeakDbtp:final.truePeakDbtp}},null,2)+'\n');
});
