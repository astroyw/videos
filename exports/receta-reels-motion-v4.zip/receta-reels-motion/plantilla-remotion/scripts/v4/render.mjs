import fs from 'node:fs';
import path from 'node:path';
import './sync-guide.mjs';
import {root,readFormat} from './config.mjs';
import {loadProject,validatePlan,validateAssets} from './validate.mjs';
import {run,remotion} from './cli.mjs';
import {measureAudio,normalizationFilter} from './audio.mjs';
import {verify} from './verify.mjs';
import {writeSubtitles} from './subtitles.mjs';
const project=loadProject(process.argv[2]),{config:c}=readFormat();
validatePlan(project,c);validateAssets(project,c); // Fail before creating an output or invoking renderer.
const dir=path.join(root,'out/formato-v4',new Date().toISOString().replace(/[:.]/g,'-'));fs.mkdirSync(dir,{recursive:true});
const props=path.join(dir,'props.json');fs.writeFileSync(props,JSON.stringify({project}));
const master=path.join(dir,'master.mp4'),final=path.join(dir,'video-final.mp4');
remotion(['render','src/formato-v4/index.tsx','ReelFormatoV4',master,'--props',props,'--codec=h264','--audio-codec=aac','--pixel-format=yuv420p','--crf=18','--concurrency=2']);
const firstPass=measureAudio(master,c);
run('ffmpeg',['-y','-v','warning','-i',master,'-map','0:v:0','-map','0:a:0','-vf','scale=in_range=auto:out_range=tv,format=yuv420p','-c:v','libx264','-crf','18','-color_range','tv','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-af',normalizationFilter(firstPass,c),'-c:a','aac','-b:a','192k','-ar','48000','-movflags','+faststart',final]);
const report=verify(final,project,c);fs.writeFileSync(path.join(dir,'verificacion.json'),JSON.stringify(report,null,2)+'\n');writeSubtitles(project,path.join(dir,'subtitulos.srt'));
console.log(`Entrega técnica: ${final}. Revisar visual y auditivamente antes de aprobar formato.`);
