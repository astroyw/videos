import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import React from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {buildSync} from 'esbuild';
import {openBrowser} from '@remotion/renderer';
import {root,readFormat,publicPath} from './config.mjs';
// Render the actual caption component into a standalone diagnostic DOM; no copied CSS.
const result=buildSync({entryPoints:[path.join(root,'src/formato-v4/ReelFormatoV4.tsx')],bundle:true,platform:'node',format:'cjs',write:false,packages:'external'});
const mod={exports:{}};new Function('require','module','exports',result.outputFiles[0].text)(createRequire(import.meta.url),mod,mod.exports);
const {Karaoke}=mod.exports,{config:c}=readFormat();
const browser=await openBrowser('chrome',{browserExecutable:process.env.REMOTION_BROWSER_EXECUTABLE});
const page=await browser.newPage({context:()=>null,logLevel:'error',indent:false,pageIndex:0,onBrowserLog:null,onLog:()=>{}});
try{
 await page.setViewport({width:c.width,height:c.height,deviceScaleFactor:1});
 const words=['¿Cómo','funcionan','estos','subtítulos?'].map((text,i)=>({text,startMs:i*900,endMs:(i+1)*900,timestampMs:null,confidence:null}));
 const font=fs.readFileSync(publicPath(c.captions.fontFile)).toString('base64');
 const checks=[];
 for(const lines of [[[0,1,2,3]],[[0,1],[2,3]]]){
 // The one-line case uses only two words to exercise both approved line structures.
 const cue=lines.length===1?{id:'one',startMs:0,endMs:1800,words:words.slice(0,2),lines:[[0,1]]}:{id:'two',startMs:0,endMs:3600,words,lines};
 const html=`<html><head><style>@font-face{font-family:${c.captions.fontFamily};src:url(data:font/ttf;base64,${font});font-weight:100 900}html,body{margin:0;width:${c.width}px;height:${c.height}px;background:${c.palette.background}}</style></head><body>${renderToStaticMarkup(React.createElement(Karaoke,{cue,timeMs:1200}))}</body></html>`;
 await page.evaluate((s)=>{document.open();document.write(s);document.close();},html);
 await page.evaluate(async()=>{await document.fonts.ready;});
 const measurement=await page.evaluate(()=>{
  const el=document.querySelector('[data-caption]'),rect=el.getBoundingClientRect(),style=getComputedStyle(el);
  const rows=[...el.querySelectorAll('[data-caption-line]')].map(line=>{
   const range=document.createRange();range.selectNodeContents(line);const bounds=range.getBoundingClientRect();return {center:bounds.x+bounds.width/2,width:bounds.width,top:bounds.y,bottom:bounds.bottom};
  });
  const colors=[...el.querySelectorAll('[data-word]')].map(w=>({active:w.getAttribute('data-active'),color:getComputedStyle(w).color,weight:getComputedStyle(w).fontWeight}));
  return {center:rect.x+rect.width/2,top:rect.y,textAlign:style.textAlign,rows,colors,fontLoaded:document.fonts.check('800 68px Figtree')};
 });
 assert.ok(Math.abs(measurement.center-c.width*.5)<.1);assert.equal(measurement.textAlign,'center');
 assert.ok(Math.abs(measurement.top-c.height*c.captions.topRatio)<.1);assert.ok(measurement.fontLoaded);
 for(const row of measurement.rows){assert.ok(Math.abs(row.center-c.width*.5)<1,'cada línea centrada en x540');assert.ok(row.width<=880,'texto excede ancho');}
 assert.equal(measurement.colors.filter(x=>x.active==='true').length,1);assert.equal(measurement.colors.find(x=>x.active==='true').color,'rgb(255, 255, 255)');assert.ok(measurement.colors.filter(x=>x.active==='false').every(x=>x.color.includes('0.48')));
 checks.push(measurement);
 }
 const dir=path.join(root,'out/formato-v4-diagnostico');fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(path.join(dir,'centrado-dom.json'),JSON.stringify({status:'passed',source:'Karaoke actual component',checks},null,2)+'\n');
 console.log('PASS: DOM real, 1 y 2 líneas centradas en x540; top 12%; fuente cargada; palabra activa blanca y otras gris semitransparente.');
}finally{await browser.close({silent:true});}
