import fs from 'node:fs';
import path from 'node:path';
import {root,readFormat} from './config.mjs';
const content=JSON.stringify(readFormat(),null,2)+'\n';
const dest=path.join(root,'src/formato-v4/formato.generated.json');
if(process.argv.includes('--check')){
 if(!fs.existsSync(dest)||fs.readFileSync(dest,'utf8')!==content)throw new Error('Configuración generada desactualizada: npm run sync:format');
 console.log('PASS: configuración generada coincide con guia-formato.md');
}else{fs.writeFileSync(dest,content);console.log('Generado src/formato-v4/formato.generated.json desde guia-formato.md');}
