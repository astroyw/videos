import {spawnSync} from 'node:child_process';
import path from 'node:path';
import {createRequire} from 'node:module';
import {root} from './config.mjs';
export function run(bin,args,opts={}){const r=spawnSync(bin,args,{cwd:root,encoding:'utf8',maxBuffer:32*1024*1024,...opts});if(r.error)throw r.error;if(r.status!==0)throw new Error(r.stderr||`${bin} exit ${r.status}`);return r;}
export function remotion(args){const req=createRequire(import.meta.url);const cli=path.join(path.dirname(req.resolve('@remotion/cli/package.json')),'remotion-cli.js');return run(process.execPath,[cli,...args,...(process.env.REMOTION_BROWSER_EXECUTABLE?['--browser-executable',process.env.REMOTION_BROWSER_EXECUTABLE]:[])],{stdio:'inherit'});}
