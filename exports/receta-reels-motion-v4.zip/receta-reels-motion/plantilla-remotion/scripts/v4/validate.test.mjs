import test from 'node:test';
import assert from 'node:assert/strict';
import {readFormat} from './config.mjs';
import {validatePlan,validateAssets,loadProject} from './validate.mjs';
import {normalizationFilter,assertLevels} from './audio.mjs';
const c=readFormat().config;
function fixture(){
 const p=structuredClone(loadProject());p.mode='delivery';p.artReviewed=true;p.audio={src:'missing.wav',sha256:'0'.repeat(64),alignmentMethod:'TEST FIXTURE ONLY',alignmentReviewed:true};
 p.closing={type:'cta',start:57,text:'Enviáselo a ese amigo que prueba subtítulos.'};
 p.beats=Array.from({length:20},(_,i)=>({id:`beat${i}`,start:i*3,end:(i+1)*3,newElementId:`n${i}`,newElementDescription:`Estado ${i}`,narration:'Una prueba breve.',comparisonOrFigure:'1',camera:{x:0,y:0,scale:i>=14?.6:1,rotation:0},transition:'continuous',scaleJump:i===14}));
 p.nodes=p.beats.map(b=>({id:b.newElementId,kind:'circle',poses:[{time:b.start,x:540,y:960,scale:1,rotation:0,opacity:0,value:0},{time:b.start+.5,x:540,y:960,scale:1,rotation:0,opacity:1,value:1}]}));
 p.captions=p.beats.map((b,i)=>({id:`c${i}`,startMs:i*3000,endMs:(i+1)*3000,words:['Una','prueba','breve.'].map((text,j)=>({text,startMs:i*3000+j*800,endMs:i*3000+(j+1)*800,timestampMs:null,confidence:null}))}));return p;
}
test('preview cannot export',()=>assert.throws(()=>validatePlan(loadProject(),c),/NO ENTREGA/));
test('delivery requires real audio metadata',()=>{const p=fixture();p.audio.src='';assert.throws(()=>validatePlan(p,c),/audio real/);});
test('missing audio file cannot pass assets',()=>assert.throws(()=>validateAssets(fixture(),c),/No existe/));
test('word timing gaps inside blocks are allowed; timing overlaps rejected',()=>{assert.equal(validatePlan(fixture(),c).words,60);const p=fixture();p.captions[0].words[1].startMs=20;assert.throws(()=>validatePlan(p,c),/Tiempos de palabra/);});
test('captions must correspond to narration',()=>{const p=fixture();p.captions[0].words[0].text='Otra';assert.throws(()=>validatePlan(p,c),/mismas palabras/);});
test('missing word timings rejected',()=>{const p=fixture();delete p.captions[0].words[0].endMs;assert.throws(()=>validatePlan(p,c),/Tiempos/);});
test('beat 5s, extra cuts and missing final scale jump rejected',()=>{let p=fixture();p.beats[0].end=5;assert.throws(()=>validatePlan(p,c),/2–4/);p=fixture();p.beats.slice(0,7).forEach(b=>b.transition='match-cut');assert.throws(()=>validatePlan(p,c),/cortes/);p=fixture();p.beats.forEach(b=>b.scaleJump=false);assert.throws(()=>validatePlan(p,c),/salto de escala/);});
test('duration 40 and unjustified deep rejected',()=>{let p=fixture();p.durationSeconds=40;assert.throws(()=>validatePlan(p,c),/Duración/);p=fixture();p.durationSeconds=120;p.edition='deep';assert.throws(()=>validatePlan(p,c),/justificar/);});
test('sample peak and LUFS are separate; true peak reported but not confused with dBFS',()=>{assert.doesNotThrow(()=>assertLevels({integratedLufs:-14.2,samplePeakDbfs:-1.1,truePeakDbtp:-.8},c));assert.throws(()=>assertLevels({integratedLufs:-14,samplePeakDbfs:-.9},c),/dBFS/);assert.throws(()=>assertLevels({integratedLufs:-17,samplePeakDbfs:-2},c),/LUFS/);});
test('second normalization pass includes measured values and silence rejected',()=>{const filter=normalizationFilter({loudnorm:{input_i:'-20',input_tp:'-3',input_lra:'2',input_thresh:'-30',target_offset:'.1'}},c);assert.match(filter,/measured_I=-20/);assert.match(filter,/I=-14/);assert.throws(()=>normalizationFilter({loudnorm:{input_i:'-inf'}},c),/no normalizable/);});

test('literal explanation and recurring object are allowed',()=>{const p=fixture();p.metaphor='';p.beats.forEach(b=>b.newElementId='n0');assert.doesNotThrow(()=>validatePlan(p,c));});

test('object cannot appear before its introductory beat',()=>{const p=fixture();p.nodes[1].poses[0].time=0;assert.throws(()=>validatePlan(p,c),/primera pose/);});
