import fs from 'node:fs';
import crypto from 'node:crypto';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {root,readFormat,publicPath} from './config.mjs';
export const assert=(value,message)=>{if(!value)throw new Error(message);};
export function validatePlan(p,c,{delivery=true}={}){
 assert(p.version===4,'Proyecto debe declarar version:4');
 const range=p.edition==='deep'?[c.duration.deepMin,c.duration.deepMax]:[c.duration.shortMin,c.duration.shortMax];
 assert(['short','deep'].includes(p.edition),'edition debe ser short o deep');
 assert(Number.isFinite(p.durationSeconds)&&p.durationSeconds>=range[0]&&p.durationSeconds<=range[1],'Duración fuera del rango de la guía');
 assert(Number.isInteger(p.durationSeconds*c.fps),'Duración debe corresponder a cuadros enteros');
 assert(p.edition!=='deep'||p.deepReason?.trim().length>=20,'Versión profunda requiere justificar los pasos adicionales');
 assert(['A','B'].includes(p.variant),'Variante debe ser A o B');
 assert(typeof p.metaphor==='string','metaphor debe ser texto: vacío significa explicación literal, sin metáfora');
 if(!delivery)return;
 assert(p.mode==='delivery','NO ENTREGA: modo preview. Completar narración, alineación y diseño antes de exportar.');
 assert(!p.diagnosticStill,'Una muestra diagnóstica no es una entrega');
 assert(p.artReviewed===true,'Falta revisión editorial y visual; los nodos de ejemplo no validan un tema');
 assert(p.audio?.src&&p.audio.sha256&&p.audio.alignmentMethod?.trim()&&p.audio.alignmentReviewed===true,'Falta audio real o constancia de alineación revisada');
 const beats=p.beats;assert(Array.isArray(beats)&&beats.length,'Falta plan de beats');
 let cursor=0;const ids=new Set();
 for(const b of beats){
  assert(!ids.has(b.id)&&b.id,'IDs de beat únicos');ids.add(b.id);
  assert(Math.abs(b.start-cursor)<1e-6,'Beats deben cubrir la duración sin huecos ni superposiciones');cursor=b.end;
  assert(b.end-b.start>=c.beats.minSeconds-1e-6&&b.end-b.start<=c.beats.maxSeconds+1e-6,'Cada beat dura 2–4 s');
  assert(typeof b.newElementId==='string'&&b.newElementId&&b.newElementDescription?.trim(),'Cada beat declara una sola novedad y el objeto afectado; puede conservar el objeto anterior');
  assert(b.narration?.trim()&&b.comparisonOrFigure?.trim(),'Cada beat necesita narración y cifra o comparación concreta');
  assert(['continuous','match-cut','morph','cut'].includes(b.transition),'Transición desconocida');
  assert(b.camera&&['x','y','scale','rotation'].every(k=>Number.isFinite(b.camera[k]))&&b.camera.scale>0,'Cámara inválida');
 }
 assert(Math.abs(cursor-p.durationSeconds)<1e-6,'Beats deben terminar en la duración total');
 assert(beats.filter(b=>['cut','match-cut'].includes(b.transition)).length<=c.beats.maxCuts,'Se supera el máximo de cortes, incluidos match-cuts');
 assert(beats.some(b=>b.scaleJump&&b.start>=p.durationSeconds*2/3),'Falta salto de escala en el último tercio');
 assert(['cta','title'].includes(p.closing?.type)&&p.closing.text?.trim(),'Cierre requiere CTA o título revelación');
 assert(p.closing.start>=p.durationSeconds*2/3&&p.closing.start<p.durationSeconds,'Cierre fuera del tramo final');
 assert(p.closing.type!=='cta'||/^enviáselo a ese amigo que\b/i.test(p.closing.text),'CTA debe comenzar “Enviáselo a ese amigo que…” y tener remate temático');
 assert(Array.isArray(p.nodes)&&p.nodes.length,'Falta diseño de objetos');
 const nodeIds=new Set();for(const n of p.nodes){
  assert(!nodeIds.has(n.id)&&n.id,'IDs de objetos únicos');nodeIds.add(n.id);
  assert(['circle','box','bar','counter','pill','tag','grid','character','custom'].includes(n.kind),'Tipo de objeto desconocido');
  assert(n.kind!=='custom','Implementar el dibujo específico de custom antes de entregar');
  assert(n.poses?.length>=2,'Cada objeto necesita poses explícitas');
  const intro=beats.find(b=>b.newElementId===n.id)?.start;
  if(intro!==undefined){assert(n.poses[0].time===intro,'La primera pose debe coincidir con el beat que introduce el objeto');assert(intro===0||n.poses[0].opacity===0,'Una entrada posterior necesita partir de opacidad cero con easing');}
  let prev=-1;
  for(const pose of n.poses){assert(['time','x','y','scale','rotation','opacity','value'].every(k=>Number.isFinite(pose[k])),'Pose inválida');assert(pose.time>prev&&pose.time<=p.durationSeconds,'Poses en orden y dentro del video');prev=pose.time;}
 }
 assert(beats.every(b=>nodeIds.has(b.newElementId)),'Un beat refiere un elemento no dibujado');
 let lastEnd=0;let words=0;const cueIds=new Set();
 assert(p.captions?.length,'Faltan subtítulos con tiempos medidos por palabra');
 for(const cue of p.captions){
  assert(cue.id&&!cueIds.has(cue.id),'IDs de subtítulo únicos');cueIds.add(cue.id);
  assert(cue.startMs>=lastEnd&&cue.endMs>cue.startMs&&cue.endMs<=p.durationSeconds*1000,'Subtítulos fuera de orden/rango');lastEnd=cue.endMs;
  assert(cue.words.length>=c.captions.minWords&&cue.words.length<=c.captions.maxWords,'Cada bloque requiere 2–5 palabras');
  let end=cue.startMs;for(const w of cue.words){
   assert(typeof w.text==='string'&&w.text.trim()&&!/\s/.test(w.text.trim()),'Cada timing contiene exactamente una palabra');
   assert(w.startMs>=end&&w.endMs>w.startMs&&w.endMs<=cue.endMs,'Tiempos de palabra inválidos');end=w.endMs;words++;
   assert(w.timestampMs===null||Number.isFinite(w.timestampMs),'timestampMs inválido');
   assert(w.confidence===null||(w.confidence>=0&&w.confidence<=1),'confidence inválida');
  }
  if(cue.lines){assert(cue.lines.length>=1&&cue.lines.length<=c.captions.maxLines,'Máximo dos líneas');const indices=cue.lines.flat();assert(indices.length===cue.words.length&&indices.every((x,i)=>x===i),'Las líneas deben contener todas las palabras en orden');}
 }
 const text=p.captions.flatMap(x=>x.words.map(w=>w.text.trim())).join(' ');
 const normalize=t=>t.toLowerCase().replace(/[^\p{L}\p{N}]+/gu,' ').trim();
 assert(normalize(text)===normalize(beats.map(b=>b.narration).join(' ')),'Narración de beats y subtítulos deben contener las mismas palabras');
 return {words,averageWordsPerSecond:words/p.durationSeconds,voiceTarget:c.voice.wordsPerSecond,cuts:beats.filter(b=>['cut','match-cut'].includes(b.transition)).length};
}
export function probe(file){const r=spawnSync('ffprobe',['-v','error','-show_streams','-show_format','-of','json',file],{encoding:'utf8'});if(r.status!==0)throw new Error(r.stderr||'FFprobe falló');return JSON.parse(r.stdout);}
export function validateAssets(p,c){
 const audio=publicPath(p.audio.src);assert(fs.existsSync(audio),'No existe la narración en public/');
 assert(crypto.createHash('sha256').update(fs.readFileSync(audio)).digest('hex')===p.audio.sha256,'Hash del audio cambió: volver a alinear y revisar palabras');
 const info=probe(audio),stream=info.streams.filter(s=>s.codec_type==='audio');assert(stream.length===1,'Narración debe tener una sola pista de audio');
 const duration=Number(info.format.duration);assert(duration>0&&duration<=p.durationSeconds+.05,'Audio vacío o excede el video; ajustar guion, sin recorte automático');
 const lastWord=Math.max(...p.captions.flatMap(x=>x.words.map(w=>w.endMs)))/1000;assert(lastWord<=duration+.05,'Palabras fuera de la duración real de la narración');
 assert(fs.existsSync(publicPath(c.captions.fontFile)),'Falta fuente local indicada en guía');
 assert(p.hyperframesClips?.length,'Falta segmento HyperFrames integrado para usar ambas herramientas');
 for(const clip of p.hyperframesClips||[]){assert(clip.start>=0&&clip.duration>0&&clip.start+clip.duration<=p.durationSeconds,'Clip HyperFrames fuera de rango');const v=probe(publicPath(clip.src)).streams.find(s=>s.codec_type==='video');assert(v&&v.r_frame_rate===`${c.fps}/1`,'FPS observado del clip HyperFrames no coincide con guía');assert(Number(probe(publicPath(clip.src)).format.duration)>=clip.duration,'Clip HyperFrames más corto que el tramo utilizado');}
 return {audioDuration:duration};
}
export function loadProject(file=path.join(root,'src/formato-v4/project.json')){return JSON.parse(fs.readFileSync(path.resolve(file),'utf8'));}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURL(import.meta.url)){
 const p=loadProject(process.argv[2]);const {config:c}=readFormat();const result=validatePlan(p,c,{delivery:!process.argv.includes('--preview')});if(!process.argv.includes('--preview'))validateAssets(p,c);console.log(JSON.stringify({status:'passed',...result}));
}
function fileURL(url){return new URL(url).pathname;}
