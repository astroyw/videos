import fs from 'node:fs';
const stamp=ms=>{ms=Math.round(ms);return `${String(Math.floor(ms/3600000)).padStart(2,'0')}:${String(Math.floor(ms/60000)%60).padStart(2,'0')}:${String(Math.floor(ms/1000)%60).padStart(2,'0')},${String(ms%1000).padStart(3,'0')}`;};
export function writeSubtitles(project,path){fs.writeFileSync(path,project.captions.map((b,i)=>`${i+1}\n${stamp(b.startMs)} --> ${stamp(b.endMs)}\n${(b.lines||[b.words.map((_,i)=>i)]).map(ids=>ids.map(i=>b.words[i].text.trim()).join(' ')).join('\n')}\n`).join('\n'));}
