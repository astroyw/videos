import fs from 'node:fs';
import path from 'node:path';
import {root,readFormat} from './config.mjs';
import {probe,assert,loadProject,validatePlan,validateAssets} from './validate.mjs';
import {run} from './cli.mjs';
import {measureAudio,assertLevels} from './audio.mjs';
export function verify(file,project,c){
 const data=probe(file),v=data.streams.find(s=>s.codec_type==='video'),audio=data.streams.filter(s=>s.codec_type==='audio');
 assert(v&&v.width===c.width&&v.height===c.height&&v.codec_name==='h264'&&v.pix_fmt==='yuv420p','Video debe ser 1080×1920 H.264 yuv420p');
 assert(v.r_frame_rate===`${c.fps}/1`&&v.avg_frame_rate===`${c.fps}/1`,'Video debe tener 60 FPS constantes');
 assert(audio.length===1&&audio[0].codec_name==='aac','Entrega requiere una pista AAC');
 const frames=JSON.parse(run('ffprobe',['-v','error','-select_streams','v:0','-count_frames','-show_entries','stream=nb_read_frames','-of','json',file]).stdout).streams[0].nb_read_frames;
 assert(Number(frames)===Math.round(project.durationSeconds*c.fps),'Número de cuadros incorrecto');
 assert(Math.abs(Number(data.format.duration)-project.durationSeconds)<.05,'Duración del MP4 incorrecta');
 run('ffmpeg',['-v','error','-xerror','-i',file,'-f','null','-']);
 const levels=measureAudio(file,c);assertLevels(levels,c);
 return {fullDecode:'passed',video:data.streams,audio:{integratedLufs:levels.integratedLufs,samplePeakDbfs:levels.samplePeakDbfs,truePeakDbtp:levels.truePeakDbtp},frames:Number(frames),duration:Number(data.format.duration),visualReview:'Pendiente: verificar karaoke, continuidad, cortes, legibilidad y exactitud científica.',listening:'No se acredita escucha humana mediante métricas.'};
}
if(process.argv[1]&&path.resolve(process.argv[1])===new URL(import.meta.url).pathname){const p=loadProject(process.argv[2]),{config:c}=readFormat();validatePlan(p,c);validateAssets(p,c);const file=path.resolve(process.argv[3]||path.join(root,'out/formato-v4/video-final.mp4'));const report=verify(file,p,c);fs.writeFileSync(path.join(path.dirname(file),'verificacion.json'),JSON.stringify(report,null,2)+'\n');console.log('PASS: archivo, AAC, niveles y decodificación; revisión visual/escucha se registran aparte.');}
