import './sync-guide.mjs';
import {remotion} from './cli.mjs';
remotion(['studio','src/formato-v4/index.tsx']);
