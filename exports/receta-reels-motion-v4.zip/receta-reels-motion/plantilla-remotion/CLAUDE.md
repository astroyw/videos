# Claude Code — plantilla V4

Seguir `AGENTS.md`, `README.md` y [guia-formato.md](../guia-formato.md), fuente única del formato. Para nuevos videos usar `src/formato-v4/`; la ruta legacy es histórica. No repetir ni reinterpretar parámetros en otros archivos: generar configuración con `npm run sync:format`.

Los subtítulos se centran respecto al lienzo y cada línea tiene alineación centrada. No desplazar el bloque para compensar elementos de plataformas. Comprobar el componente real con `npm run check:layout` y una imagen diagnóstica cuando corresponda. No confundir el preview con una entrega ni los tiempos ficticios de prueba con alineación de audio real.
