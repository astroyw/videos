> ARCHIVO HISTÓRICO: no usar como instrucciones de nuevos videos. El formato vigente está únicamente en [guia-formato.md](../guia-formato.md). Se conserva el contenido anterior como registro.

> **Aviso v3 — plantilla histórica pendiente de adaptación.** El código conserva 14 `Shot` separados y un `h1` superior con título/acento durante cada parte. No cumple las 2–4 escenas fluidas ni la pregunta solo inicial. Antes de usarla para una entrega nueva, adaptar el montaje, retirar esos encabezados y crear el hook como primer subtítulo de 2–4 s. Leer `../07-CONTINUIDAD-Y-ANIMACION.md`; no exigir un único escenario. Esta actualización modifica documentación: no reescribe el código ni genera un nuevo render.

# Demo ejecutable: cómo se gasifican las bebidas

Este proyecto acompaña la receta del kit. Es una demostración editable de motion graphics: **40 segundos, 14 partes, 1080 × 1920, 30 FPS, MP4 H.264 y sin audio**. El cierre tiene una sola llamada a la acción: «Compartilo con un amigo curioso». No muestra números de parte.

La animación principal usa React/SVG y Remotion. La escena de moléculas incorpora un clip hecho con HyperFrames; se incluyen tanto el clip como su fuente HTML. Los diagramas son esquemas explicativos, no simulaciones físicas cuantitativas.

## Abrir y renderizar

Requisitos: Node.js 22 o posterior, npm, FFmpeg y FFprobe disponibles en el PATH. Remotion usa Chrome Headless Shell o un Chrome/Chromium compatible.

Desde esta carpeta:

```bash
npm ci
npm run check
npm run studio
```

El último comando abre la vista previa. En otra terminal, desde la misma carpeta:

```bash
npm run render
```

El render produce `out/reel.mp4`, `out/subtitulos.srt` y `out/verificacion.json`. El script verifica el número real de cuadros, formato, dimensiones, duración, ausencia de audio y decodificación completa. El máster intermedio queda en `out/master.mp4`.

Si Remotion no puede descargar su navegador o querés usar uno ya instalado, definí `REMOTION_BROWSER_EXECUTABLE` con la ruta real. Ejemplos:

```bash
# Linux, si esta ruta existe en tu equipo:
REMOTION_BROWSER_EXECUTABLE=/usr/bin/chromium npm run render
```

```powershell
# Windows PowerShell: comprobá la ubicación de tu Chrome.
$env:REMOTION_BROWSER_EXECUTABLE = 'C:\Program Files\Google\Chrome\Application\chrome.exe'
npm run render
```

En macOS se puede usar `/Applications/Google Chrome.app/Contents/MacOS/Google Chrome` si existe. Ningún script depende de rutas del entorno donde se preparó este kit. En una nube con proxy, conservá las credenciales y certificados administrados; no desactives TLS.

## Qué editar

- `src/storyboard.json`: textos, palabra o frase amarilla (`highlight`) y duración en cuadros. `highlight` debe coincidir exactamente con un fragmento del subtítulo; si no coincide, se muestra todo en blanco. Los 14 intervalos suman 1200 cuadros. La última parte dura 90 cuadros para mostrar el CTA durante 3 segundos.
- `src/Reel.tsx`: dibujo y movimiento de cada parte. El índice de cada elemento del JSON selecciona su diagrama.
- `src/visuals.tsx`: colores, botella, molécula y otros elementos compartidos.
- `src/index.tsx`: tamaño, FPS y composición `Reel`.
- `public/gasificacion/`: fuente tipográfica local y clip molecular.

**Cambiar los textos no cambia el tema de los dibujos.** Para un Reel de aire acondicionado, tránsito o gravedad, el agente debe escribir los diagramas correspondientes y adaptar `Visual` en `src/Reel.tsx`. Este ejemplo es una base de producción, no un generador automático para cualquier tema.

Si cambiás la cantidad de partes, adaptá también el enrutamiento de diagramas y `scripts/check-storyboard.mjs`. Si cambiás la duración total, actualizá esa validación de forma explícita. Los fotogramas son unidades de 1/30 s.

Los subtítulos son frases por parte; no están sincronizados con una voz inexistente. Cuando agregues tu narración, ajustá sus intervalos al audio y regenerá el SRT con `npm run subtitles`. El script de render de esta demo fuerza silencio; para una versión narrada hay que incorporar el audio y adaptar render/verify de forma explícita.

## Regenerar la escena de HyperFrames

Esto es opcional: el clip incluido permite renderizar la demo sin instalar HyperFrames.

```bash
cd hyperframes
npm ci
npm run check
npm run preview
```

Revisá la escena y luego, desde otra terminal en `hyperframes`:

```bash
npm run render
```

Ese comando actualiza `../public/gasificacion/molecular.mp4`. Duración del clip: 6 segundos. La demo utiliza 3 segundos. Conservá el clip existente si solo querés editar textos.

Si HyperFrames necesita un navegador instalado, usá su variable `HYPERFRAMES_BROWSER_PATH` con una ruta válida. Si el home es de solo lectura, configurá `XDG_STATE_HOME` y `HYPERFRAMES_FONT_CACHE_DIR` a carpetas escribibles. No se necesita una cuenta de HeyGen para este render local. GSAP se copia desde el paquete instalado a `hyperframes/assets/gsap.min.js`; no se usa CDN durante el render.

## Assets y licencias

La fuente Manrope se incluye con su licencia SIL Open Font License en `public/gasificacion/Manrope-OFL.txt`. La animación de gasificación y los diagramas fueron elaborados para este proyecto. No se incluyen voces, música, logos de terceros ni videos de referencia dentro de esta plantilla. Remotion, React, HyperFrames y GSAP conservan sus propias licencias, consultables en sus paquetes; no quedan relicenciados por este kit.

## Qué se verificó

La evidencia de las comprobaciones realizadas al preparar el kit está en `PRUEBAS.md`. `npm run review` genera una hoja de contacto de las 14 partes. `npm run verify:motion` compara dos muestras de la región del diagrama de cada parte; detecta cambios, pero no certifica fluidez ni exactitud científica. Al modificar un video, repetí `npm run check`, `npm run render` y la revisión visual; la verificación técnica no evalúa la precisión de un guion nuevo ni la calidad de sus diagramas.
