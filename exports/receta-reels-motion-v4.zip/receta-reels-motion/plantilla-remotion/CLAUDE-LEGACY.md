> ARCHIVO HISTÓRICO: no usar como instrucciones de nuevos videos. El formato vigente está únicamente en [guia-formato.md](../guia-formato.md). Se conserva el contenido anterior como registro.

> **Aviso v3 — plantilla histórica pendiente de adaptación.** El código conserva 14 `Shot` separados y un `h1` superior con título/acento durante cada parte. No cumple las 2–4 escenas fluidas ni la pregunta solo inicial. Antes de usarla para una entrega nueva, adaptar el montaje, retirar esos encabezados y crear el hook como primer subtítulo de 2–4 s. Leer `../07-CONTINUIDAD-Y-ANIMACION.md`; no exigir un único escenario. Esta actualización modifica documentación: no reescribe el código ni genera un nuevo render.

# Claude Code

Leé y seguí `AGENTS.md` y `README.md` de esta carpeta, además de la receta principal del kit. Esta demo usa Remotion para el montaje y un clip de HyperFrames para las moléculas. La especificación vigente del usuario tiene prioridad sobre los valores del ejemplo.
