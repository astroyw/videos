import React from 'react';
import {AbsoluteFill,Audio,OffthreadVideo,Sequence,staticFile,useCurrentFrame,useVideoConfig,interpolate,Easing,getRemotionEnvironment} from 'remotion';
import generated from './formato.generated.json';
import type {Project,CaptionBlock,Pose,VisualNode} from './types';
const format=generated.config;
const ease=Easing.bezier(.16,1,.3,1);
export const captionStyle:React.CSSProperties={position:'absolute',left:'50%',transform:'translateX(-50%)',top:`${format.captions.topRatio*100}%`,width:880,maxWidth:'84%',textAlign:'center',fontFamily:format.captions.fontFamily,fontSize:format.captions.fontSize,lineHeight:1.17,fontWeight:600,letterSpacing:-.6,zIndex:20};
export const Karaoke=({cue,timeMs}:{cue:CaptionBlock;timeMs:number})=>{
 const lines=cue.lines||[cue.words.map((_,i)=>i)];
 return <div data-caption="true" style={captionStyle}>{lines.map((indices,line)=><div key={line} data-caption-line="true" style={{textAlign:'center',whiteSpace:'nowrap'}}>{indices.map((i,j)=>{
 const w=cue.words[i],active=timeMs>=w.startMs&&timeMs<w.endMs;
 return <React.Fragment key={i}>{j>0?' ':null}<span data-word={i} data-active={active?'true':'false'} style={{display:'inline-block',color:active?'#FFFFFF':'rgba(210,216,220,0.48)',fontWeight:800,background:w.key?format.palette.cyan:'transparent',borderRadius:14,padding:w.key?'0 8px':undefined}}>{w.text.trim()}</span></React.Fragment>;
 })}</div>)}</div>;
};
const poseAt=(poses:Pose[],time:number):Pose=>{
 if(time<=poses[0].time)return poses[0];const b=poses.findIndex(p=>p.time>time);if(b<0)return poses[poses.length-1];const a=poses[b-1],z=poses[b];
 return Object.fromEntries(Object.keys(a).map(k=>[k,k==='time'?time:interpolate(time,[a.time,z.time],[a[k as keyof Pose],z[k as keyof Pose]],{easing:ease,extrapolateLeft:'clamp',extrapolateRight:'clamp'})])) as Pose;
};
const Graphic=({node,time}:{node:VisualNode;time:number})=>{
 if(time<node.poses[0].time)return null;
 const p=poseAt(node.poses,time),color=format.palette[node.color||'cyan'];
 return <g data-node-id={node.id} transform={`translate(${p.x} ${p.y}) rotate(${p.rotation}) scale(${p.scale})`} opacity={p.opacity}>
 {node.kind==='circle'&&<circle r={105} fill={color}/>}
 {node.kind==='box'&&<><rect x={-130} y={-90} width={260} height={180} rx={35} fill="#000" opacity={.18} transform="translate(0 12)"/><rect x={-130} y={-90} width={260} height={180} rx={35} fill={color}/></>}
 {node.kind==='bar'&&<><rect x={-200} y={-45} width={400} height={90} rx={24} fill="#203441"/><rect x={-200} y={-45} width={Math.max(0,Math.min(1,p.value))*400} height={90} rx={24} fill={color}/></>}
 {node.kind==='counter'&&<text textAnchor="middle" fontSize={105} fontWeight={800} fill={format.palette.cyan}>{Math.round(p.value)}{node.unit||''}</text>}
 {node.kind==='pill'&&<><rect x={-200} y={-42} width={400} height={84} rx={42} fill="#000" opacity={.25} transform="translate(0 7)"/><rect x={-200} y={-42} width={400} height={84} rx={42} fill="#FFFFFF"/><text y={14} textAnchor="middle" fill={format.palette.background} fontWeight={800} fontSize={35}>{node.text}</text></>}
 {node.kind==='tag'&&<><path d="M0 20V75L70 100" fill="none" stroke={format.palette.cream} strokeWidth={2}/><text textAnchor="middle" fontSize={29} letterSpacing={3} fontWeight={700} fill={format.palette.cream}>{node.text?.toUpperCase()}</text></>}
 {node.kind==='grid'&&Array.from({length:Math.max(0,Math.min(100,Math.round(p.value)))},(_,i)=><rect key={i} x={(i%10)*44-220} y={Math.floor(i/10)*44-220} width={34} height={34} rx={8} fill={color}/>)}
 {node.kind==='character'&&<><circle cy={-80} r={46} fill={format.palette.cream}/><rect x={-65} y={-28} width={130} height={150} rx={55} fill={color}/><path d="M-38 103v90M38 103v90" stroke={format.palette.cream} strokeWidth={28} strokeLinecap="round"/></>}
 </g>;
};
export const ReelFormatoV4=({project}:{project:Project})=>{
 const frame=useCurrentFrame(),{fps}=useVideoConfig(),t=frame/fps;
 const preview=project.mode!=='delivery';
 if(preview&&getRemotionEnvironment().isRendering&&!project.diagnosticStill)throw new Error('NO ENTREGA: preview sin narración/alineación real. Usar solo still:format para comprobar layout.');
 const cues=project.captions.length?project.captions:[{id:'diagnostico',startMs:0,endMs:4000,words:[{text:'Subtítulos',startMs:0,endMs:1500,timestampMs:null,confidence:null},{text:'centrados',startMs:1500,endMs:3000,timestampMs:null,confidence:null}],lines:[[0,1]]}];
 const cue=cues.find(c=>t*1000>=c.startMs&&t*1000<c.endMs);
 const beats=project.beats;const current=Math.max(0,beats.findIndex(b=>t>=b.start&&t<b.end));const beat=beats[current],previous=beats[Math.max(0,current-1)];
 const camera=beat?Object.fromEntries(Object.keys(beat.camera).map(k=>[k,interpolate(t,[beat.start,beat.start+.6],[previous.camera[k as keyof typeof previous.camera],beat.camera[k as keyof typeof beat.camera]],{easing:ease,extrapolateLeft:'clamp',extrapolateRight:'clamp'})])):{x:0,y:0,scale:1,rotation:0};
 return <AbsoluteFill style={{background:format.palette.background,fontFamily:format.captions.fontFamily,overflow:'hidden'}}>
 <style>{`@font-face{font-family:'${format.captions.fontFamily}';src:url('${staticFile(format.captions.fontFile)}');font-weight:100 900;font-style:normal;}`}</style>
 {project.variant==='B'&&<svg width={1080} height={1920} style={{position:'absolute',inset:0}}><defs><linearGradient id="mist"><stop stopColor={format.palette.cyan} stopOpacity="0"/><stop offset="1" stopColor={format.palette.cyan} stopOpacity=".07"/></linearGradient></defs><path d="M0 1350L540 1000L1080 1350V1920H0Z" fill="#152B39"/>{Array.from({length:8},(_,i)=><g key={i}><rect x={i*155-25} y={820+(i%3)*70} width={115} height={480-(i%3)*70} rx={10} fill="#172D3B"/><rect x={i*155+4} y={865+(i%3)*70} width={20} height={28} rx={4} fill={format.palette.amber} opacity={.5}/></g>)}<ellipse cx={540} cy={1240} rx={800} ry={230} fill="url(#mist)"/></svg>}
 {(project.hyperframesClips||[]).map((clip,i)=><Sequence key={i} from={Math.round(clip.start*fps)} durationInFrames={Math.round(clip.duration*fps)}><OffthreadVideo muted src={staticFile(clip.src)} style={{width:1080,height:1920,position:'absolute',inset:0}}/></Sequence>)}
 <svg width={1080} height={1920} style={{position:'absolute',inset:0}}><g transform={`translate(540 1000) scale(${camera.scale}) rotate(${camera.rotation}) translate(${-540+camera.x} ${-1000+camera.y})`}>{project.nodes.map(n=><Graphic key={n.id} node={n} time={t}/>)}</g></svg>
 {preview&&<><div style={{position:'absolute',top:700,left:90,right:90,textAlign:'center',color:format.palette.cyan,fontSize:46}}>Área de animación del tema</div><div style={{position:'absolute',left:100,right:100,top:1400,textAlign:'center',fontSize:25,color:format.palette.amber}}>NO ENTREGA · PREVIEW DE PLANTILLA<br/>Tiempos de prueba; falta narración real.</div></>}
 {cue&&<Karaoke cue={cue} timeMs={t*1000}/>}
 {project.closing.type==='title'&&t>=project.closing.start&&<div style={{position:'absolute',left:90,right:90,top:900,fontSize:70,textAlign:'center',color:format.palette.cream,fontWeight:800}}>{project.closing.text}</div>}
 {project.audio.src&&<Audio src={staticFile(project.audio.src)}/>}
 </AbsoluteFill>;
};
