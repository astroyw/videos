// Same JSON fields as Remotion Caption; timings must come from real audio in delivery mode.
export type Word={text:string;startMs:number;endMs:number;timestampMs:number|null;confidence:number|null;pageBreakAfter?:boolean;key?:boolean};
export type CaptionBlock={id:string;startMs:number;endMs:number;words:Word[];lines?:number[][]};
export type Pose={time:number;x:number;y:number;scale:number;rotation:number;opacity:number;value:number};
export type VisualNode={id:string;kind:'circle'|'box'|'bar'|'counter'|'pill'|'tag'|'grid'|'character'|'custom';text?:string;color?:'cyan'|'amber'|'cream';unit?:string;poses:Pose[]};
export type Beat={id:string;start:number;end:number;newElementId:string;newElementDescription:string;narration:string;comparisonOrFigure:string;camera:{x:number;y:number;scale:number;rotation:number};transition:'continuous'|'match-cut'|'morph'|'cut';scaleJump?:boolean};
export type Project={version:4;mode:'preview'|'delivery';diagnosticStill?:boolean;durationSeconds:number;edition:'short'|'deep';deepReason:string;variant:'A'|'B';metaphor:string;artReviewed:boolean;audio:{src:string;sha256:string;alignmentMethod:string;alignmentReviewed:boolean};captions:CaptionBlock[];beats:Beat[];nodes:VisualNode[];hyperframesClips?:{src:string;start:number;duration:number}[];closing:{type:'cta'|'title';start:number;text:string};};
