import React from 'react';
import {Composition,registerRoot} from 'remotion';
import {ReelFormatoV4} from './ReelFormatoV4';
import generated from './formato.generated.json';
import draft from './project.json';
import type {Project} from './types';
const c=generated.config;
const Root=()=> <Composition id="ReelFormatoV4" component={ReelFormatoV4}
 width={c.width} height={c.height} fps={c.fps} durationInFrames={Math.round(c.duration.defaultSeconds*c.fps)}
 defaultProps={{project:draft as Project}}
 calculateMetadata={({props})=>({durationInFrames:Math.round(props.project.durationSeconds*c.fps),fps:c.fps,width:c.width,height:c.height})}/>;
registerRoot(Root);
