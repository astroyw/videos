# Pruebas de la plantilla V4

Formato normativo: [guia-formato.md](../guia-formato.md). Evidencia detallada: `PRUEBAS-V4.json`.

## Ejecutado en esta actualización

- `npm run check`: configuración generada igual a guía, TypeScript sin errores y 12 pruebas de contratos/errores. Incluyen falta de audio, tiempos por palabra ausentes o superpuestos, discordancia narración/subtítulos, duración inválida, cortes excesivos y falta de salto de escala declarado y aparición de objetos antes de su beat.
- `npm run check:layout`: DOM del componente Karaoke real con fuente Figtree cargada; una y dos líneas centradas. Centro del contenedor x=540, centro del texto ≈539,992, borde superior y≈230,391. Palabra activa blanca; restantes gris semitransparente. No es una prueba de subtítulos de un tema real.
- `npm run still:format`: una imagen PNG de diagnóstico en 1080×1920, revisada visualmente. Marca NO ENTREGA. No es un video; sus tiempos de palabra son sintéticos para probar diseño, no alineación de voz.
- `npm run check:audio`: prueba real de dos pasadas con tono sintético de seis segundos, sin voz ni video. Codificación AAC y medición posterior: −13,99 LUFS integrados; −7,686138 dBFS de pico de muestras; −7,68 dBTP adicional. El resultado verifica el procedimiento sobre esa señal, no una narración futura.
- `npm run hyperframes:check`: nuevo HTML, lint/runtime/layout sin errores ni advertencias; navegador ejecutado, 48 muestras craft. Movimiento desactivado y cero textos de contraste; no se anuncian esas auditorías como pruebas superadas. Advertencia externa: historial no guardable en home de solo lectura.
- `npm run render` con borrador: fallo esperado NO ENTREGA antes de invocar renderer, por modo preview sin narración/alineación. Confirma que no entrega un MP4 silencioso por omisión.
- Comparación binaria con ZIP v3: fuentes antiguas de Remotion/HyperFrames, scripts originales, fuente/licencia y clip molecular preservados. Package scripts ahora apuntan a V4; comandos anteriores conservados en legacy:* y package-legacy.json.

## No ejecutado / pendientes

No se creó ningún video ni voz nuevos. No se renderizó el segmento nuevo de HyperFrames. Falta producir un tema real, audio alineado, ilustración específica y sus revisiones. Normalización final, sincronía perceptual, fluidez y estilo deben volver a verificarse sobre ese futuro MP4; no se infieren de TypeScript, flags ni checks parciales. Windows/macOS no fueron probados.

## Registro histórico conservado

Las siguientes comprobaciones corresponden exclusivamente a la demo antigua y no validan el formato vigente.

---

> **Resultados históricos de la demo original, no ejecutados en v3.** No validan la nueva dirección. El código conserva montaje fragmentado y encabezados durante las partes, pendientes de adaptación. El ZIP v3 no incluye el render final antiguo.

# Comprobaciones de la plantilla

Fecha: 29 de octubre de 2026. Plataforma comprobada: Linux; Node.js 24.19.0, npm 11.9.0, Chromium del sistema y FFmpeg/FFprobe 7.1.5.

## Pruebas ejecutadas

- `npm ci`: instalación desde el lockfile del proyecto Remotion, exit 0.
- `npm run check`: TypeScript sin errores; 14 partes, identificadores únicos, textos presentes y suma de 1200 cuadros.
- Verificación de los 14 campos `highlight`: cada uno coincide con un fragmento de su subtítulo.
- `REMOTION_BROWSER_EXECUTABLE=/usr/bin/chromium npm run render`: render completo de la demo, exportación final y validación, exit 0.
- FFprobe y decodificación completa con FFmpeg: 1080 × 1920, H.264, yuv420p, 30 FPS, 1200 cuadros, 40.000 segundos y ninguna pista de audio.
- En `hyperframes/`, `npm ci`: instalación desde lockfile y copia de GSAP a assets locales, exit 0.
- En `hyperframes/`, `npm run check`: lint, runtime y layout sin errores ni advertencias; navegador ejecutado. El chequeo del clip no evalúa subtítulos porque el clip no tiene texto. El chequeo de movimiento de HyperFrames figura desactivado; no se presenta como una prueba de movimiento superada.

- `npm run review`: generada y revisada visualmente la hoja `out/revision.jpg`, un cuadro de cada parte; sin números de slide y con palabras clave amarillas.
- `npm run verify:motion`: las 14 partes muestran cambios entre dos muestras de la región central del diagrama. Resultado en `out/movimiento.json`. Esta prueba detecta cambio entre muestras, no continuidad ni fluidez.

## Entrega comprobada

- Video: `out/reel.mp4`.
- Tamaño: 2,360,543 bytes.
- SHA-256: `66ad7205b9f10380cbe071dcb56c6826af4ffe2c50c95b067774c51fbeaf17a9`.
- Evidencia técnica: `out/verificacion.json`.
- El cierre ocupa 37–40 s y muestra «Compartilo con un amigo curioso».

## Alcance

Los scripts usan rutas portátiles y una variable opcional para el navegador. Se ejecutaron en Linux; Windows y macOS no se probaron en esta sesión. El clip de HyperFrames incluido proviene del proyecto anterior; en este kit se comprobó el HTML y se renderizó su integración en Remotion, sin volver a renderizar ese clip por separado. HyperFrames avisó que no pudo guardar el historial en el home de solo lectura; el chequeo sí terminó correctamente.

El video es una demo sobre gasificación. Para un tema distinto hace falta adaptar el guion y los diagramas; reemplazar textos no produce automáticamente una explicación nueva.
