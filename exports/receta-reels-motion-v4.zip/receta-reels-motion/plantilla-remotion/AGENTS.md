# Trabajo con la plantilla V4

Leer [guia-formato.md](../guia-formato.md), fuente única de reglas, y `README.md` de esta carpeta. Las instrucciones explícitas del usuario prevalecen.

Usar la ruta `src/formato-v4/` y comandos normales para nuevos proyectos. No copiar reglas de `*-LEGACY.md`, código anterior o pruebas históricas: se conservan solo como archivo. Mantener configuración generada sincronizada con la guía; no editarla manualmente.

Preservar archivos y salidas. Leer skills locales de Remotion/captions/HyperFrames para tareas pertinentes. Separar narración, palabras alineadas, beats y estado visual; el cambio de subtítulo no reinicia objetos. Los subtítulos deben conservar el centrado horizontal de la guía, tanto el bloque como cada línea.

El borrador es NO ENTREGA. No inventar voz, alineación ni revisión; el preflight debe fallar si faltan. Para cambios de receta, no generar un video. Para producciones posteriores autorizadas, comprobar formato real, niveles del audio final, transiciones y legibilidad y declarar límites de escucha/revisión. No publicar ni borrar sin autorización. Guardar licencias y no empaquetar dependencias o cachés.
