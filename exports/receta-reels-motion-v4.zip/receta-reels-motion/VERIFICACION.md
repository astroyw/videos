# Verificación v4 — resultados y límites

Actualización de receta, agentes, ejemplos y código de base. No se creó un Reel ni narración nuevos. El registro anterior se conserva en `historico/VERIFICACION-V3.md`.

## Pasó

- Prompt Markdown/TXT idénticos; checklist único de exactamente 15 puntos; enlaces relativos de documentación comprobados.
- Plantilla Guionista con seis columnas exactas. Ejemplos nuevos con 20 beats contiguos y 60 s editoriales, cada beat dentro del rango de la guía. Bloques de 2–4 palabras coincidentes con la narración propuesta. Estos datos no equivalen a audio alineado.
- Configuración generada desde la guía, TypeScript y 12 pruebas de validación: duraciones, beats, texto/alineación, falta de audio, límites de sonoridad, objetos recurrentes y aparición de objetos.
- Componente real de subtítulos en Chromium: una y dos líneas. Bloque centrado en x=540; líneas en x≈539,992; borde superior en y≈230,391; texto centrado, Figtree cargada y estados blanco/gris comprobados. Captura PNG inspeccionada. Evidencia en `verificacion/`.
- Prueba aislada de audio: tono sintético de laboratorio, sin voz ni video. Normalización en dos pasadas y AAC final medido: −13,99 LUFS, pico de muestras −7,686138 dBFS, true peak −7,68 dBTP. El test distingue las unidades; no demuestra la calidad de una voz futura.
- HyperFrames: check de la nueva fuente con lint/runtime/layout aprobados. 48 muestras craft; auditoría de movimiento desactivada y cero textos de contraste: esos dos controles no se presentan como aprobaciones.
- El comando de render con el proyecto preview falló de forma esperada antes del renderer: no se puede entregar la muestra sin narración y alineación reales.
- Comparación con v3: todos los paths anteriores preservados; fuentes, assets y scripts originales de la demo conservados. Dependencias existentes sin actualización de versiones.

## Empaquetado y portabilidad

Pasaron CRC del ZIP, extracción independiente, validación SHA-256 de los 98 archivos de contenido y preservación de los 49 paths de v3. El paquete contiene 99 entradas incluyendo manifiesto. No incluye node_modules, cachés, renders nuevos ni audio de laboratorio.

Desde la carpeta extraída fuera del repositorio: `npm ci --no-audit --no-fund` instaló 261 paquetes y `npm run check` pasó configuración sincronizada, TypeScript y las 12 pruebas. Esta comprobación no renderizó un video. Tras incorporar este informe se regeneró el paquete y se volvió a comprobar su integridad.

## No ejecutado / pendiente para una producción real

No hubo render MP4 nuevo, voz de un tema, escucha humana de narración ni revisión temporal de un Reel completo. Los ejemplos editoriales requieren verificar fuentes factuales, ajustar voz y tiempos, diseñar su mecanismo y repetir revisión visual/audio. La fuente HyperFrames nueva es un estudio de movimiento, no una simulación científica aprobada. Sus FPS declarados no prueban por sí solos la procedencia temporal de cualquier clip incorporado después.

La ruta de producción incluye normalización y verificaciones pero no se probó de extremo a extremo con una película completa en esta actualización. Windows y macOS no se ejecutaron. La voz/alineación dependen de recursos autorizados disponibles en la futura producción; el ZIP no instala un servicio de voz. No se reanalizaron cinco videos de referencia.

Detalles técnicos: `plantilla-remotion/PRUEBAS.md` y `PRUEBAS-V4.json`. Resultado de cada archivo: `RESULTADO-POR-ARCHIVO.md`.
