# Evidencia parcial de la receta v4

- `subtitulos-centrados.png`: captura técnica, no video. Su texto y tiempos son un caso de prueba marcado NO ENTREGA.
- `centrado-dom.json`: medidas del componente real, una y dos líneas, sobre el lienzo completo. No acredita sincronización con una narración.
- `audio-laboratorio.json`: mediciones de un tono sintético codificado AAC para probar normalización; no es voz. El audio de prueba no se redistribuye.
- `documentos.json`: comprobaciones estructurales de documentación y ejemplos.

Ver `../VERIFICACION.md` y `../plantilla-remotion/PRUEBAS-V4.json`. No se generó un Reel nuevo.
