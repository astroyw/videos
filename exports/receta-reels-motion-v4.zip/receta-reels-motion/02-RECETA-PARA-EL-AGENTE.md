# Procedimiento de producción

Autoridad: [guia-formato.md](guia-formato.md). Flujo y roles: `README.md`. Este documento describe cómo aplicar el formato, no fija otros valores.

1. **Inspeccionar:** leer instrucciones del repositorio y brief; preservar app y archivos. Identificar herramientas, assets, permisos y disponibilidad real de voz/alineación.
2. **Investigar:** ejecutar Guionista, documentar fuentes, condiciones y simplificaciones. Referencias visuales no son autoridad factual sobre ciencia o leyes.
3. **Escribir:** usar `plantillas/salida-guionista.md`. Separar beats, subtítulos, contextos y cortes; elegir un cierre admitido por G6. Señalar tiempos como provisionales.
4. **Diseñar:** Director completa `plantillas/plan-visual.md`. Planear estados, cámara, metáfora, gráfico y salto de escala. Revisar el espacio reservado a G4 sin desplazar los subtítulos a un costado.
5. **Producir audio:** crear o recibir narración autorizada, revisar pronunciación y ritmo, corregir guion cuando corresponda. Obtener y corregir tiempos por palabra sobre esa versión del audio. No confundir transcribir con alinear bien.
6. **Animar:** implementar estados deterministas por tiempo con Remotion/HyperFrames; conservar fuente HTML y assets. Alinear acciones, bloques y karaoke a las palabras reales. No usar clocks de tiempo real, red durante el render ni aleatoriedad sin semilla.
7. **Revisar borradores:** Revisor aplica su checklist con evidencia disponible. Corregir legibilidad, coherencia factual, saltos y números antes de la exportación final.
8. **Exportar cuando se solicitó video:** aplicar G1, normalizar mezcla y medir el archivo final codificado; conservar voz, derechos y metadatos de producción. El pipeline no debe aceptar silencio o alineación inventada como entrega conforme.
9. **Comprobar y entregar:** usar el checklist único sobre el MP4 final, verificar decodificación y completar reporte. Entregar enlaces reales y fuentes editables; no publicar en redes ni hacer push sin autorización.

Si la tarea actual es actualizar la receta, ejecutar solo esa actualización y sus pruebas. No producir un video para completar casillas audiovisuales: registrarlas como no ejecutadas. Los pasos de una futura producción no son pruebas realizadas en este paquete.
