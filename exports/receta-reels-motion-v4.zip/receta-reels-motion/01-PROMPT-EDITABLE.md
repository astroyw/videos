# Prompt editable — producción con la receta v4

Actuá como el equipo definido en esta carpeta y producí un video educativo de motion graphics. Leé primero `guia-formato.md`, la única fuente de verdad del formato, y `README.md`. Aplicá el flujo **Guionista → Director de arte/animación → Revisor**, usando los archivos de `agentes/`. No copies parámetros de las demos históricas. Si la guía no está accesible, solicitá la carpeta en vez de inventar sus reglas.

## Brief — completar

TEMA: [Cómo funciona el Bluetooth]
IDEA_QUE_DEBE_ENTENDERSE: [Los dispositivos intercambian datos por radio de forma coordinada y pueden convertirlos en sonido.]
PUBLICO: [Personas curiosas sin conocimientos técnicos previos]
VERSION: [CORTA; PROFUNDA solo si el tema necesita más pasos, justificar]
DURACION_OBJETIVO: [Usar la base de G1; ajustar dentro del rango de la versión]
VARIANTE_VISUAL: [AUTO: elegir A o B según G2 y explicar la elección]
METAFORA_CENTRAL: [AUTO; máximo permitido por G2, usar un diagrama literal si explica mejor]
GANCHO: [AUTO: elegir pregunta o demostración inmediata conforme a G6]
DATO_O_COMPARACION_CLAVE: [Investigar; no inventar cifras]
CIERRE: [ENVIASELO; alternativa TITULO_REVELADOR según G6]
REMATE: [AUTO: ligado al tema, ingenioso y breve]
LOOP: [NO; SI si tiene sentido narrativo]
VOZ_PREFERIDA: [Natural, cálida y acogedora; timbre configurable dentro de G6]
AUDIO_APORTADO: [NINGUNO; producir una voz autorizada si hay herramienta disponible]
MUSICA_Y_EFECTOS: [Opcionales y discretos; no competir con la narración]
FUENTES_O_RESTRICCIONES: [Investigar fuentes fiables y registrar límites del modelo]
REFERENCIAS_ADICIONALES: [Las adjuntas si existen; inspeccionar su contenido real]
ENTREGA: [MP4 final verificado, fuentes editables, guion, subtítulos y reporte]

Los corchetes son campos editables, nunca texto para renderizar. Consultá la guía para todos los valores de formato; esta plantilla no los redefine. Las instrucciones explícitas posteriores del usuario tienen prioridad y cualquier excepción debe registrarse.

## Ejecución

1. Guionista: investigar, elegir una explicación y entregar la tabla exacta de `plantillas/salida-guionista.md`. Anotar fuentes y tiempos editoriales provisionales.
2. Director: preparar el plan visual, producir/recibir la voz y obtener tiempos por palabra del audio final. Adaptar los tiempos y programar el mecanismo con Remotion y HyperFrames. **Verificar especialmente G4: los subtítulos tienen que estar CENTRADOS.** No inventar alineación ni presentar la vista técnica de muestra como entrega.
3. Revisor: ejecutar el checklist único de `agentes/revisor-formato.md` con evidencia. Corregir fallos y completar el render solicitado. No marcar como comprobado lo que no se pudo revisar o escuchar.

Preservá la aplicación, dependencias, archivos y versiones anteriores. Leé las skills locales pertinentes. Si falta una capacidad necesaria de voz o alineación, explicá el límite real y dejá esa condición pendiente; no sustituir el formato por un video silencioso.

Entregá el archivo mediante un enlace o adjunto real, sin inventar paneles de descarga. Incluí `GUION.md`, `FUENTES.md`, SRT, tiempos por palabra, código, assets/licencias y `VERIFICACION.md`. Este pedido autoriza producir el video, no publicar en redes ni hacer push sin autorización. Si el pedido actual es solo actualizar la receta, no ejecutes este prompt de producción ni generes otro video.
