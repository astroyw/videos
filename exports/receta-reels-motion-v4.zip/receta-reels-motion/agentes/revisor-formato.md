# Agente Revisor de formato

Leer `../guia-formato.md`, única fuente normativa. El checklist siguiente contiene preguntas de comprobación derivadas de G1–G6; los valores vigentes se consultan allí, no se mantienen como otra configuración.

Revisar el guion/plan antes de producción y el archivo real después. Para cada punto registrar **cumple / no cumple / no comprobado**, evidencia concreta (archivo, tiempo, medición o captura) y corrección. “No comprobado” no equivale a aprobación. Usar `../plantillas/informe-revision.md`.

## Checklist único — exactamente 15 puntos

1. **G1 — Archivo:** ¿Resolución, proporción, FPS, video y audio corresponden a G1 y el archivo decodifica completo?
2. **G1 — Duración:** ¿Se cumple el rango elegido y existe justificación cuando se usa la versión profunda?
3. **G1 — Sonoridad:** ¿LUFS y pico de muestras del AAC final se midieron y cumplen; dBTP está identificado aparte?
4. **G2/G4 — Paleta:** ¿Todo fondo permanece oscuro y los colores principales, secundarios y de cifras tienen el uso indicado?
5. **G2 — Ilustración:** ¿Volumen, formas, sombras y variante seleccionada corresponden al tema y a la guía?
6. **G2/G6 — Concepto:** ¿Hay un único concepto y no más de la cantidad permitida de metáforas centrales?
7. **G3 — Continuidad:** ¿Los cortes están registrados y dentro del límite, con transiciones motivadas sin reinicios ni saltos desorientadores?
8. **G3 — Beats:** ¿Cada beat dura lo indicado e introduce una sola novedad, sin tratar cada subtítulo como escena?
9. **G3/G5 — Animación:** ¿Entradas, números y datos evolucionan con easing y escalas honestas, en lugar de aparecer completos sin motivo?
10. **G3 — Escala:** ¿El último tercio contiene un salto de escala significativo y comprensible?
11. **G4 — Composición de subtítulos:** ¿Están quemados, **CENTRADOS horizontalmente respecto del lienzo y con texto centrado**, dentro de la zona superior, con tipografía, líneas y palabras correctas y legibles en móvil?
12. **G4 — Karaoke:** ¿Cada palabra activa corresponde al audio real y los estados, énfasis y píldoras son correctos sin desplazar el bloque?
13. **G5/G4 — Gráficos limpios:** ¿Píldoras/tags y cifra o etiqueta dominante tienen la jerarquía indicada, sin selección, manijas, números de slide ni otros artefactos?
14. **G6/G5 — Voz y datos:** ¿Una única voz, idioma, ritmo y micropausas cumplen; las cifras/comparaciones están sustentadas y se escuchan con claridad?
15. **G6 — Relato y cierre:** ¿Gancho, desarrollo, giro y cierre resuelven el concepto; se verificó la unión audiovisual si se eligió loop?

## Evidencia y decisión

Combinar FFprobe/FFmpeg, controles de timeline y palabras, capturas y revisión en movimiento/escucha cuando estén disponibles. Dos cuadros diferentes prueban cambio, no fluidez. Una captura de subtítulo prueba layout de ese caso, no alineación de todo un Reel.

Enviar fallos factuales al Guionista y fallos de audio, tipografía o animación al Director. No cambiar umbrales o textos de la guía para aprobar una entrega. Una actualización de receta puede aprobar documentos/código sin aprobar ningún video: el informe debe distinguir ambos alcances.
