# Escritura aplicada: gancho, magnitud y cierre

Consultar [guia-formato.md](guia-formato.md), G3, G5 y G6. El Guionista decide una explicación y su evidencia antes de elegir una fórmula llamativa.

## Esqueleto editable

**Gancho:** ¿Cuántas [unidades] hacen falta para [efecto]? / ¿Y si [cambio concreto]? / demostración inmediata del fenómeno.

**Desarrollo:** [condición] provoca [mecanismo]; frente a [comparación sustentada], aparece [resultado]. Cada beat agrega una novedad que usa el resultado anterior.

**Giro de escala:** lo que viste en [unidad] se comprende mejor al revelar [conjunto, magnitud o interior]. Vincular el cambio visual a la misma explicación.

**Cierre:** “Enviáselo a ese amigo que [conducta relacionada con el tema]”, con remate específico, o título final que revela el concepto explicado. Elegir el cierre de G6 y planear su tiempo de lectura/voz.

## Criterio editorial

No exigir cifras donde una comparación concreta explica mejor, ni inventar porcentajes para aumentar impacto. Las preguntas deben resolverse. Evitar “esperá al final” vacío y “nadie te lo cuenta” sin fundamento.

Una pregunta larga puede ocupar varios bloques según G4; no se convierte por eso en título fijo. El remate no introduce un tema nuevo. Un loop es opcional y tiene que funcionar en imagen y sonido; no cortar la última palabra para conectar dos cuadros.
