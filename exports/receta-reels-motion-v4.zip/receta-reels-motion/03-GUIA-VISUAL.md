# Aplicación de la dirección de arte

La normativa vive en [guia-formato.md](guia-formato.md), G2, G4 y G5. Leer esos apartados para colores, tipografía, variantes y posición. No tomar la demo antigua como plantilla de estilo.

## Componer desde la lectura

Reservar primero el bloque de subtítulos conforme a G4: **su eje es el del lienzo completo y su texto está centrado**. Un objeto grande o los botones de una plataforma no justifican empujarlo a la izquierda. Distribuir objetos y etiquetas alrededor, cuidando contraste y lectura en móvil.

Usar un sujeto reconocible y jerarquizar un dato por beat. La etiqueta acompaña el objeto; el subtítulo cuenta qué significa su transformación. Mantener el ancho del bloque al activar palabras para que el karaoke no salte. Revisar bloques de una y dos líneas y las palabras más largas del guion.

## Elegir variante

A sirve para explicar una relación mediante un objeto o esquema claro. B sirve cuando perspectiva y contexto espacial ayudan: profundidad por capas, iluminación nocturna y niebla sutil. Elegir una variante no implica añadir recursos decorativos sin motivo. Diseñar personajes estilizados solo si cumplen una función narrativa.

## Biblioteca gráfica

Píldoras, tags, barras, contadores y tarjetas deben compartir proporciones y trazos. Su aparición sigue la causalidad del beat. No mostrar una batería, una tabla o una fórmula solo para que el plano “tenga más cosas”. Dibujar unidades, escalas y comparaciones comprensibles; cualquier simplificación relevante debe declararse.

## Revisión visual

Inspeccionar inicio, estados intermedios, uniones, salto de escala y cierre. Examinar por separado el centrado de los subtítulos y su coincidencia con el audio. Una captura comprueba composición de ese instante; revisar secuencias para movimiento. Usar el checklist del Revisor, sin crear una segunda lista normativa.
