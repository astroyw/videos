# Edición de este Reel

Leer README.md, SPEC.md y src/storyboard.json. Preservar los archivos y variantes existentes. El video aprobado para esta entrega tiene 40 s, 1080×1920, 30 FPS, 14 partes, sin audio ni números visibles, con CTA final de 3 s.

Usar las skills locales de Remotion y HyperFrames del repositorio cuando estén disponibles. La animación de ensamble y control de escuadra está en hyperframes; el resto se monta en React/SVG. Los diagramas representan una ventana de aluminio abatible; no son planos de fabricación.

Después de editar: npm run check, render, revisión visual, verify:motion y verificación del MP4. No confundir cambios de píxeles con validación científica. No publicar ni borrar archivos sin autorización del usuario.
