# Cómo se fabrica una ventana

Reel de motion graphics sobre una ventana de aluminio abatible. 40 segundos, 14 microescenas, 1080×1920, 30 FPS. Subtítulos incrustados, sin voz, música ni pista de audio. Cierre con una única llamada a compartir. Sin números de slide.

## Reproducir el proyecto

Requisitos: Node.js 22+, npm, FFmpeg y FFprobe en PATH; Chrome/Chromium compatible con Remotion.

```bash
npm ci
npm run check
npm run studio
npm run render
```

El render genera `out/reel.mp4`, `out/subtitulos.srt` y `out/verificacion.json`. Hace una exportación H.264 yuv420p con color BT.709, rango limitado, faststart y sin audio; después verifica 1200 cuadros/40 segundos y decodifica todo el video.

Si se necesita un navegador instalado, configurar `REMOTION_BROWSER_EXECUTABLE` con su ruta real. En Linux se usó `/usr/bin/chromium`. En PowerShell se puede definir `$env:REMOTION_BROWSER_EXECUTABLE` con la ruta de Chrome. No hay rutas `/workspace` obligatorias en el código de render.

## Editar

- `src/storyboard.json`: textos, palabras destacadas y duración de las 14 partes.
- `src/Reel.tsx`: diagramas, movimientos, colores y composición. Los gráficos corresponden al tema de la ventana; cambiar solo textos no adapta los dibujos a otro tema.
- `src/index.tsx`: composición `Reel`, resolución, FPS y duración total.
- `public/ventana/`: fuente Manrope, su licencia y el segmento HyperFrames.
- `hyperframes/`: fuente editable del ensamble y control de escuadra, con instrucciones y pruebas propias.

La animación HyperFrames dura 6 segundos y se integra entre los segundos 14 y 20. Se creó específicamente para este video. El clip viene incluido para poder renderizar Remotion sin regenerarlo; para editarlo, seguir el README de `hyperframes/`.

## Verificar cambios

```bash
npm run check
npm run render
npm run review
npm run verify:motion
```

`npm run review` extrae una muestra de cada parte del MP4 final. Revisar también las transiciones. `verify:motion` compara dos muestras del área del diagrama, sin encabezados ni subtítulos; detectar cambios no certifica fluidez ni exactitud técnica.

## Alcance

Es una explicación esquemática de un tipo de ventana, no un manual de taller. Los perfiles, mecanizados, cortes, calzos y sellos dependen del sistema del fabricante. No se indican medidas ni tolerancias universales. La comprobación animada de apertura y cierre no representa una certificación de estanqueidad.

Guion, referencias y evidencia de entrega están en la carpeta `documentacion/` cuando se distribuye el ZIP de fuentes. El acceso a fuentes externas estuvo restringido; no se afirma una validación contra un manual de fabricante.

La fuente Manrope se incluye con su licencia SIL OFL. Diagramas y animaciones se produjeron para este video. Remotion, React, HyperFrames y GSAP conservan sus propias licencias. No se utilizaron imágenes, logos, música ni voces de los videos de referencia.
