import {mkdirSync,writeFileSync} from 'node:fs';
import path from 'node:path';
import {root,probe,run,finalFile,totalFrames,fps} from './common.mjs';
const result=probe(finalFile);
const video=result.streams.find(s=>s.codec_type==='video');
if(!video||video.width!==1080||video.height!==1920||video.codec_name!=='h264'||video.pix_fmt!=='yuv420p'||video.r_frame_rate!=='30/1'||Number(video.nb_read_frames)!==totalFrames||Math.abs(Number(result.format.duration)-totalFrames/fps)>0.001||result.streams.some(s=>s.codec_type==='audio')) {
  throw new Error('El MP4 no coincide con la especificación: H.264, 1080×1920, 30 FPS, frames esperados y sin audio.');
}
run('ffmpeg',['-v','error','-xerror','-i',finalFile,'-f','null','-']);
mkdirSync(path.join(root,'out'),{recursive:true});
writeFileSync(path.join(root,'out/verificacion.json'),JSON.stringify({checkedAt:new Date().toISOString(),fullDecode:'passed',...result},null,2)+'\n');
console.log(`PASS: ${totalFrames/fps} s, ${totalFrames} frames, 1080×1920, H.264 yuv420p, 30 FPS, cero pistas de audio y decodificación completa.`);
