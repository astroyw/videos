import {spawnSync} from 'node:child_process';
import {writeFileSync} from 'node:fs';
import path from 'node:path';
import {root,parts,fps,finalFile} from './common.mjs';

function sample(seconds) {
  const result=spawnSync('ffmpeg',['-v','error','-ss',String(seconds),'-i',finalFile,'-frames:v','1','-vf','crop=780:570:100:480,scale=156:114','-pix_fmt','gray','-f','rawvideo','-'],{maxBuffer:4*1024*1024});
  if(result.error||result.status!==0) throw result.error||new Error(result.stderr.toString());
  if(result.stdout.length!==156*114) throw new Error('Muestra de imagen incompleta.');
  return result.stdout;
}
let from=0;
const measurements=parts.map(part=>{
  const start=from/fps;
  const a=sample(start+0.15),b=sample(start+part.frames/fps-0.4);
  const difference=a.reduce((sum,pixel,i)=>sum+Math.abs(pixel-b[i]),0)/a.length;
  from+=part.frames;
  return {id:part.id,meanAbsoluteDifference:difference,passed:difference>0.08};
});
writeFileSync(path.join(root,'out/movimiento.json'),JSON.stringify({method:'Dos muestras de la región del diagrama por parte, sin títulos, subtítulos ni barra de progreso.',limitation:'Detecta cambios visuales entre muestras. No verifica continuidad, fluidez ni precisión científica.',measurements},null,2)+'\n');
if(measurements.some(part=>!part.passed)) throw new Error('Una parte no mostró cambios en las dos muestras. Revisá out/movimiento.json.');
console.log(`PASS: cambios visuales en los diagramas de las ${parts.length} partes (muestreo, no evaluación de fluidez).`);
