import {mkdirSync} from 'node:fs';
import path from 'node:path';
import {root,run,parts,fps,finalFile} from './common.mjs';
const dir=path.join(root,'out/review');
mkdirSync(dir,{recursive:true});
let from=0;
for(const [i,part] of parts.entries()) {
  const time=(from+Math.floor(part.frames/2))/fps;
  run('ffmpeg',['-y','-v','error','-ss',String(time),'-i',finalFile,'-frames:v','1','-vf','scale=270:480',path.join(dir,`${String(i).padStart(2,'0')}.jpg`)]);
  from+=part.frames;
}
run('ffmpeg',['-y','-v','error','-framerate','1','-i',path.join(dir,'%02d.jpg'),'-vf','tile=7x2','-frames:v','1',path.join(root,'out/revision.jpg')]);
console.log('Creado out/revision.jpg con un cuadro de cada parte. Revisá también el video en movimiento.');
