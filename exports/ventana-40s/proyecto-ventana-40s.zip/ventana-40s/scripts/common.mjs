import {spawnSync} from 'node:child_process';
import {readFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {createRequire} from 'node:module';
import path from 'node:path';

export const root=fileURLToPath(new URL('../',import.meta.url));
export const require=createRequire(import.meta.url);
export const parts=JSON.parse(readFileSync(path.join(root,'src/storyboard.json'),'utf8'));
export const totalFrames=parts.reduce((sum,part)=>sum+part.frames,0);
export const fps=30;
export const finalFile=path.join(root,'out/reel.mp4');
export function run(bin,args,options={}) {
  const r=spawnSync(bin,args,{cwd:root,encoding:'utf8',maxBuffer:16*1024*1024,...options});
  if(r.error) throw r.error;
  if(r.status!==0) throw new Error(r.stderr||`${bin} salió con código ${r.status}`);
  return r.stdout;
}
export function remotion(args) {
  const pkg=require.resolve('@remotion/cli/package.json');
  const cli=path.join(path.dirname(pkg),'remotion-cli.js');
  const browser=process.env.REMOTION_BROWSER_EXECUTABLE;
  return run(process.execPath,[cli,...args,...(browser?['--browser-executable',browser]:[])],{stdio:'inherit'});
}
export function probe(file) {
  return JSON.parse(run('ffprobe',['-v','error','-count_frames','-show_streams','-show_format','-of','json',file]));
}
