import {parts,totalFrames} from './common.mjs';
if(parts.length!==14||totalFrames!==1200)throw new Error('Se requieren 14 partes y 1200 cuadros.');
const ids=new Set();
for(const p of parts){
 if(ids.has(p.id)||!Number.isInteger(p.frames)||p.frames<30)throw new Error('ID o duración inválida');
 ids.add(p.id);
 if(!p.caption||!p.title||!p.caption.includes(p.highlight))throw new Error('Texto o highlight inválido: '+p.id);
}
if(parts.at(-1).frames!==90)throw new Error('La CTA necesita 3 segundos.');
console.log('PASS: 14 partes, 1200 cuadros y CTA de 3 s.');
