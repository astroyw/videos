import {remotion} from './common.mjs';
remotion([process.argv[2]||'studio','src/index.tsx',...process.argv.slice(3)]);
