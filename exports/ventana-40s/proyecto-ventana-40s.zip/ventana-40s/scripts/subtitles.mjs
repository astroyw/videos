import {mkdirSync,writeFileSync} from 'node:fs';
import path from 'node:path';
import {root,parts,fps} from './common.mjs';

const stamp=(frames)=>{
  const ms=Math.round(frames/fps*1000);
  return `${String(Math.floor(ms/3600000)).padStart(2,'0')}:${String(Math.floor(ms/60000)%60).padStart(2,'0')}:${String(Math.floor(ms/1000)%60).padStart(2,'0')},${String(ms%1000).padStart(3,'0')}`;
};
let start=0;
const srt=parts.map((part,i)=>{
  const line=`${i+1}\n${stamp(start)} --> ${stamp(start+part.frames)}\n${part.caption}\n`;
  start+=part.frames;
  return line;
}).join('\n');
mkdirSync(path.join(root,'out'),{recursive:true});
writeFileSync(path.join(root,'out/subtitulos.srt'),srt,'utf8');
console.log('Creado out/subtitulos.srt. Los índices SRT no se muestran en la imagen.');
