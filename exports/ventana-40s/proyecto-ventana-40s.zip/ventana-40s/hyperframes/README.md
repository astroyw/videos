# Ensamble y control de escuadra

Segmento HyperFrames de 6 s, 1080×1920, 30 FPS, sin audio. Se integra en el Reel entre 14 y 20 s. Esquema de una ventana abatible con perfiles de aluminio y conectores de esquina; la geometría concreta depende del sistema comercial.

De 0–3 s convergen cuatro perfiles cortados a inglete y entran escuadras. De 3–6 s se corrige un marco de lados opuestos pareados: un paralelogramo sesgado pasa a rectángulo mientras se comparan diagonales. No se usa un trapecio isósceles, cuyas diagonales pueden ser iguales sin tener ángulos rectos.

```bash
npm ci
npm run check
npm run preview
npm run render
```

Si Chromium ya existe, configurar `HYPERFRAMES_BROWSER_PATH` con su ruta real. En entornos con home no escribible, `XDG_STATE_HOME` y `HYPERFRAMES_FONT_CACHE_DIR` deben apuntar a directorios escribibles. El render sale en `../public/ventana/ensamble.mp4`. GSAP es local y `npm ci` lo copia a assets. Tipografía Manrope con su licencia SIL OFL en `assets/fonts/`.

Dibujo y animación creados para este proyecto. No se incluyen marcas, material de terceros ni audio de referencia. GSAP y HyperFrames conservan sus licencias.
