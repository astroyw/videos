# Revisión del segmento HyperFrames

29 de octubre de 2026. Linux, Chromium del sistema, HyperFrames 0.8.185. Clip nuevo creado y renderizado para este Reel; no se reutilizó el clip molecular anterior.

- Registro local consultado con `catalog --query 'assembly diagram' --json`: sin resultados adecuados; diagrama específico dibujado en SVG.
- `check --json`: sin errores ni advertencias en lint/runtime/layout/craft; navegador ejecutado.
- Motion sidecar activo, 121 muestras: `staysInFrame` y `keepsMoving` aprobados.
- Contraste: 7 muestras de texto comprobadas y aprobadas.
- Preview iniciado y URL local respondió HTTP 200. No se presenta ese localhost como enlace público de descarga.
- Capturas a 0,3 / 1,8 / 3,4 / 5,6 s revisadas. Perfiles convergen; escuadras entran; se compara un paralelogramo sesgado y se corrige a rectángulo.
- Render completo: 6,000 s, 180 cuadros, 1080×1920, 30 FPS, H.264; ninguna pista de audio. FFprobe en `verification.json` y decodificación completa con FFmpeg sin errores.
- Fotograma decodificado del MP4 a 5,6 s revisado y coincide con el resultado esperado.

Limitación del dibujo: esquema de un sistema con ingletes y escuadras; las geometrías y fijaciones reales dependen del fabricante. El paralelogramo tiene pares de lados opuestos iguales; la igualdad de diagonales comprueba el ángulo recto en esa condición, no en cualquier cuadrilátero.

Las herramientas avisaron que no pudieron guardar historial y algunas cachés de fuentes en el home de solo lectura. Las capturas, fuente local, auditoría y render se completaron. Render por screenshot/software GPU (llvmpipe), sin una simulación física.

Para seguir editando, el CLI ofreció la aplicación de escritorio HyperFrames: https://hyperframes.dev/studio/download?os=linux. La fuente HTML sigue editable localmente; no se publicó nada desde este segmento.
