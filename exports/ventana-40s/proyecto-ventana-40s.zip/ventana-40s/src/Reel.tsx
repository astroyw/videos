import React from 'react';
import {AbsoluteFill, Sequence, OffthreadVideo, staticFile, useCurrentFrame, interpolate, Easing} from 'remotion';
import parts from './storyboard.json';

const C={bg:'#202123',white:'#F5F3EB',yellow:'#F6C945',blue:'#70BCE2',muted:'#A7ABB0',green:'#60C992',red:'#F05B59'};
const q=(f:number,a=0,b=60)=>interpolate(f,[a,b],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp',easing:Easing.bezier(.22,.75,.18,1)});
const Defs=()=> <defs>
 <linearGradient id="metal" x1="0" y1="0" x2="1" y2=".6"><stop stopColor="#ecf1f2"/><stop offset=".35" stopColor="#b3c0c6"/><stop offset=".65" stopColor="#6f7d85"/><stop offset="1" stopColor="#c7d1d5"/></linearGradient>
 <linearGradient id="glass" x1="0" y1="1" x2="1" y2="0"><stop stopColor="#27414c" stopOpacity=".7"/><stop offset=".6" stopColor="#5895ae" stopOpacity=".35"/><stop offset="1" stopColor="#91d8ed" stopOpacity=".65"/></linearGradient>
 <linearGradient id="shine"><stop stopColor="white" stopOpacity="0"/><stop offset=".5" stopColor="white" stopOpacity=".2"/><stop offset="1" stopColor="white" stopOpacity="0"/></linearGradient>
 <filter id="shadow" x="-30%" y="-30%" width="160%" height="170%"><feDropShadow dx="0" dy="14" stdDeviation="12" floodColor="#000" floodOpacity=".25"/></filter>
 <marker id="arrow" markerWidth="10" markerHeight="10" refX="8" refY="5" orient="auto-start-reverse"><path d="M1 1 8 5 1 9" fill="none" stroke={C.yellow} strokeWidth="1.5"/></marker>
 </defs>;
const Stage=({children}:{children:React.ReactNode})=><svg viewBox="0 0 900 700" width="900" height="700" style={{position:'absolute',left:70,top:450,overflow:'visible',fontFamily:'Manrope'}}><Defs/>{children}</svg>;
const Label=({x,y,children,color=C.muted,size=36,anchor='middle'}:{x:number;y:number;children:React.ReactNode;color?:string;size?:number;anchor?:'middle'|'start'|'end'})=><text x={x} y={y} fill={color} fontSize={size} fontWeight="700" textAnchor={anchor}>{children}</text>;
const Ring=({x,y,w,h,t=28}:{x:number;y:number;w:number;h:number;t?:number})=><g>
 <path d={`M${x} ${y}h${w}v${h}h-${w}z M${x+t} ${y+t}v${h-2*t}h${w-2*t}v-${h-2*t}z`} fill="url(#metal)" fillRule="evenodd" stroke="#d2dde1" strokeWidth="1.5"/>
 <path d={`M${x} ${y}l${t} ${t}M${x+w} ${y}l-${t} ${t}M${x} ${y+h}l${t}-${t}M${x+w} ${y+h}l-${t}-${t}`} stroke="#59666d" strokeWidth="1.5"/>
 <rect x={x+t} y={y+t} width={w-2*t} height={h-2*t} fill="none" stroke="#11191c" strokeWidth="6"/>
 </g>;
const Pane=({x,y,w,h,f=0}:{x:number;y:number;w:number;h:number;f?:number})=><g>
 <rect x={x} y={y} width={w} height={h} rx="1" fill="url(#glass)" stroke="#8cb8ca" strokeWidth="2"/>
 <path d={`M${x+35} ${y+h*.55}l${w*.45}-${h*.4}M${x+40} ${y+h*.7}l${w*.65}-${h*.58}`} stroke="#ceeff6" strokeWidth="7" opacity=".14"/>
 <path d={`M${x+5} ${y+5}H${x+w-5}`} stroke="#b4e2ec" strokeWidth="2" opacity={.5+.2*Math.sin(f/20)}/>
 </g>;
const Handle=({x,y,f=0,turn=0}:{x:number;y:number;f?:number;turn?:number})=><g transform={`translate(${x} ${y})`}>
 <rect x="-9" y="-28" width="18" height="56" rx="8" fill="#333e44" stroke="#e0e8e9"/>
 <g transform={`rotate(${-90*turn})`}><path d="M0 0v48q0 8-9 8h-13" fill="none" stroke="#dce5e6" strokeWidth="10" strokeLinecap="round"/></g>
 <circle r="4" fill="#687a85"/>
 </g>;
const Leaf=({f=0,glass=true,opening=0,handle=true,hardwareProgress=1,handleTurn}:{f?:number;glass?:boolean;opening?:number;handle?:boolean;hardwareProgress?:number;handleTurn?:number})=><g transform={`translate(168 48) matrix(${1-.32*opening} ${-.14*opening} 0 1 0 ${opening*20})`}>
 {glass&&<Pane x={28} y={28} w={484} h={514} f={f}/>}
 <Ring x={0} y={0} w={540} h={570} t={27}/>
 {handle&&<g transform={`translate(${50*(1-hardwareProgress)} 0)`} opacity={hardwareProgress}><Handle x={523} y={260} turn={handleTurn??q(f,0,24)}/></g>}
 </g>;
const Window=({f=0,glass=true,opening=0,handle=true,hardwareProgress=1,handleTurn}:{f?:number;glass?:boolean;opening?:number;handle?:boolean;hardwareProgress?:number;handleTurn?:number})=><g filter="url(#shadow)">
 <Ring x={135} y={15} w={606} h={636} t={25}/>
 <Leaf f={f} glass={glass} opening={opening} handle={handle} hardwareProgress={hardwareProgress} handleTurn={handleTurn}/>
 {[160,490].map(y=><g key={y} transform={`translate(${-70*(1-hardwareProgress)} 0)`} opacity={hardwareProgress}><rect x="153" y={y} width="27" height="62" rx="6" fill="url(#metal)" stroke="#344047"/><path d={`M167 ${y+6}v50`} stroke="#d8e1e4" strokeWidth="2"/></g>)}
 </g>;
const Check=({x,y,f}:{x:number;y:number;f:number})=><g transform={`translate(${x} ${y})`} opacity={q(f,15,30)}><circle r="33" fill={C.green}/><path d="m-15 0 10 10 21-23" stroke="#122c21" strokeWidth="6" fill="none" strokeLinecap="round" strokeLinejoin="round"/></g>;

const Hook=({f}:{f:number})=>{
 const a=q(f,14,82);
 return <Stage><g transform={`translate(${20*a} ${22*a}) scale(${1-.1*a})`}>
 <Ring x={135-65*a} y={15-5*a} w={606} h={636}/>
 <g transform={`translate(${-25*a} ${-28*a})`}><Leaf glass={false} handle f={f}/></g>
 <Pane x={196+115*a} y={76-32*a} w={484} h={514} f={f}/>
 </g><Label x={425} y={693} color={C.yellow} size={34}>MARCO · HOJA · VIDRIO</Label></Stage>;
};
const Profiles=({f}:{f:number})=><Stage>
 {[0,1,2].map((i)=>{const dx=100*(1-q(f,i*6,40+i*6));const y=125+i*155;return <g key={i} transform={`translate(${dx} 0)`} filter="url(#shadow)">
 <path d={`M180 ${y}h480l95-64H275Z`} fill="#a5b3b9" stroke="#dce6e9" strokeWidth="2"/>
 <path d={`M180 ${y}h480v70H180Z`} fill="url(#metal)"/>
 <path d={`M660 ${y}l95-64v70l-95 64Z`} fill="#586a74" stroke="#c8d4d9"/>
 <path d={`M204 ${y+17}h432v37H204Z`} fill="#24323b"/>
 <path d={`M225 ${y+15}v42M615 ${y+15}v42`} stroke="#a3b5be" strokeWidth="7"/>
 </g>})}
 <Label x={440} y={660} color={C.yellow}>Perfiles extruidos</Label>
 </Stage>;
const Measure=({f}:{f:number})=>{
 const p=q(f,0,70);return <Stage><g opacity=".25"><Window handle={false}/></g>
 <path d="M135 30V-20M741 30V-20M135-4H741" stroke={C.yellow} strokeWidth="3" fill="none" strokeDasharray={`${606*p} 1000`}/>
 <path d="M760 15H820M760 651H820M799 15V651" stroke={C.yellow} strokeWidth="3" fill="none" strokeDasharray={`${636*p} 1300`}/>
 <g transform={`translate(${135+606*p} -4)`}><path d="m-7-10 7 10-7 10" fill="none" stroke={C.yellow} strokeWidth="3"/></g>
 <Label x={440} y={-35} color={C.yellow}>ANCHO</Label><g transform="translate(825 330) rotate(90)"><Label x={0} y={0} color={C.yellow}>ALTO</Label></g>
 <rect x="150" y="672" width="590" height="18" rx="3" fill="#d0b78b"/>{Array.from({length:30},(_,i)=><path key={i} d={`M${160+i*19} 672v${i%5?6:12}`} stroke="#413b30" strokeWidth="2"/>)}
 </Stage>;
};
const Cut=({f}:{f:number})=>{
 const down=q(f,0,34)-q(f,50,80);const cut=q(f,35,65);return <Stage>
 <rect x="120" y="460" width="660" height="38" rx="8" fill="#3e474e"/>
 <g><path d="M135 370H466l-60 70H135Z" fill="url(#metal)" stroke="#dce6e8" strokeWidth="2"/><g transform={`translate(${85*cut} ${10*cut})`}><path d="M466 370H720v70H406Z" fill="url(#metal)" stroke="#dce6e8" strokeWidth="2"/><path d="M480 385H705v40H450Z" fill="#3e4c55" opacity=".6"/></g></g>
 <g transform={`translate(430 ${200+130*down})`}><g transform={`rotate(${f*13})`}><path d={Array.from({length:48},(_,j)=>{const a=j*Math.PI/24;const r=j%2?118:132;return `${j?'L':'M'}${Math.cos(a)*r} ${Math.sin(a)*r}`}).join(' ')+'Z'} fill="#bcc5c9" stroke="#e9eded" strokeWidth="2"/><circle r="99" fill="#829097"/><path d="M-80 0H80M0-80V80" stroke="#b0bcc1" strokeWidth="3"/></g><circle r="19" fill={C.yellow}/><path d="M-138-8A138 138 0 0 1 138-8" fill="none" stroke="#485760" strokeWidth="30"/></g>
 {f>30&&f<65&&Array.from({length:9},(_,i)=><circle key={i} cx={450+i*15} cy={430+((f+i*7)%25)*3} r={2+i%2} fill="#c2d1d8" opacity=".7"/>)}
 <path d="M425 480 388 540" stroke={C.yellow} strokeWidth="2"/><Label x={375} y={590} color={C.yellow}>Corte según el sistema</Label>
 </Stage>;
};
const Machining=({f}:{f:number})=>{
 const x=270+300*q(f,0,65);return <Stage>
 <g filter="url(#shadow)"><path d="M105 320H760l45-45H150Z" fill="#c0ccd1"/><rect x="105" y="320" width="655" height="135" fill="url(#metal)"/><path d="M120 357H744M120 425H744" stroke="#4c5d66" strokeWidth="7"/></g>
 {[285,550].map((v,i)=><rect key={v} x={v} y="377" width={78*q(f,i*30,30+i*30)} height="21" rx="10" fill="#17232b" stroke="#657f8e" strokeWidth="2"/>)}
 <g transform={`translate(${x} ${225+12*Math.sin(f/12)})`}><rect x="-34" y="-100" width="68" height="120" rx="10" fill="#535f68" stroke="#9bafb8" strokeWidth="2"/><rect x="-13" y="20" width="26" height="130" rx="4" fill="url(#metal)"/><path d="M-12 45 12 33M-12 65 12 53M-12 85 12 73M-12 105 12 93" stroke="#41505a" strokeWidth="5"/></g>
 <path d="M325 465V535" stroke={C.yellow} strokeWidth="2"/><Label x={425} y={590} color={C.yellow}>Drenaje previsto en el perfil</Label>
 </Stage>;
};
const LeafAssembly=({f}:{f:number})=><Stage><Ring x={135} y={15} w={606} h={636}/><g transform={`translate(${85*(1-q(f,0,70))} ${-42*(1-q(f,0,70))})`} opacity={.3+.7*q(f,0,45)}><Leaf glass={false} handle={false}/></g><Label x={440} y={699} color={C.yellow}>Marco fijo + hoja móvil</Label></Stage>;
const Hardware=({f}:{f:number})=><Stage><Window f={f} glass={false} opening={.8*q(f,22,78)} hardwareProgress={q(f,0,22)}/><g opacity={1-q(f,40,65)}><path d="M78 200 160 200M78 530 160 530" stroke={C.yellow} strokeWidth="3" markerEnd="url(#arrow)"/></g></Stage>;
const Glass=({f}:{f:number})=><Stage><g transform={`translate(0 ${35*(1-q(f,0,75))})`} filter="url(#shadow)"><Pane x={165} y={48} w={555} h={550} f={f}/><path d="M165 598 187 613H742V63L720 48" fill="none" stroke="#719daf" strokeWidth="5"/><path d={`M${210+2*f} 80 190 550`} stroke="#ceeff6" strokeWidth="15" opacity=".05"/></g><Label x={440} y={687} color={C.yellow}>Seguridad · aislamiento · diseño</Label></Stage>;
const Glazing=({f,seal=false}:{f:number;seal?:boolean})=>{
 const settle=seal?1:q(f,6,76);const beads=q(f,15,76);return <Stage>
 <Ring x={150} y={20} w={580} h={620} t={42}/>
 {[265,576].map(x=><g key={x}><rect x={x} y="582" width="60" height="16" rx="2" fill={C.yellow}/><path d={`M${x+5} 587h50`} stroke="#d59533" strokeWidth="3"/></g>)}
 <Pane x={202} y={66-130*(1-settle)} w={476} h={516} f={f}/>
 {seal?<>
 <rect x="196" y="60" width="488" height="528" fill="none" stroke="#101b21" strokeWidth="10" pathLength="1" strokeDasharray="1" strokeDashoffset={1-q(f,0,45)}/>
 <g transform={`translate(${45*(1-beads)} 0)`}><rect x="677" y="58" width="19" height="532" fill="url(#metal)" stroke="#d1e1e5"/></g>
 <g transform={`translate(0 ${-35*(1-beads)})`}><rect x="194" y="45" width="500" height="19" fill="url(#metal)" stroke="#d1e1e5"/></g>
 <path d="M689 410 782 450" stroke={C.yellow} strokeWidth="2"/><Label x={700} y={500} color={C.yellow} size={33}>Junquillo</Label>
 <path d="M200 250 100 290" stroke={C.blue} strokeWidth="2"/><Label x={163} y={337} color={C.blue} size={33}>Burlete</Label>
 </>:<><path d="M292 605V665M600 605V665" stroke={C.yellow} strokeWidth="2"/><Label x={440} y={699} color={C.yellow}>Calzos de apoyo</Label></>}
 </Stage>;
};
const Inspection=({f}:{f:number})=><Stage><Window f={f} opening={.8*(1-q(f,0,49))} handleTurn={1-q(f,38,59)}/><Check x={765} y={65} f={f}/></Stage>;
const Outro=({f}:{f:number})=><Stage><g transform={`translate(0 ${-5*Math.sin(f/30)})`}><Window f={f+30} opening={.25+.12*Math.sin(f/35)}/></g></Stage>;
const Visual=({i,f}:{i:number;f:number})=>{
 if(i===0)return <Hook f={f}/>;
 if(i===1)return <Profiles f={f}/>;
 if(i===2)return <Measure f={f}/>;
 if(i===3)return <Cut f={f}/>;
 if(i===4)return <Machining f={f}/>;
 if(i===5||i===6)return <OffthreadVideo muted src={staticFile('ventana/ensamble.mp4')} trimBefore={i===6?90:0} style={{position:'absolute',inset:0,width:1080,height:1920}}/>;
 if(i===7)return <LeafAssembly f={f}/>;
 if(i===8)return <Hardware f={f}/>;
 if(i===9)return <Glass f={f}/>;
 if(i===10)return <Glazing f={f}/>;
 if(i===11)return <Glazing f={f} seal/>;
 if(i===12)return <Inspection f={f}/>;
 return <Outro f={f}/>;
};
const Caption=({text,highlight}:{text:string;highlight:string})=>{const i=text.indexOf(highlight);return <>{text.slice(0,i)}<span style={{color:C.yellow}}>{highlight}</span>{text.slice(i+highlight.length)}</>};
const Shot=({i}:{i:number})=>{
 const f=useCurrentFrame();const s=parts[i];const enter=i===0||i===13?1:q(f,0,7);
 return <AbsoluteFill>
 <Visual i={i} f={f}/>
 <div style={{position:'absolute',left:100,top:240,fontSize:24,letterSpacing:5,color:C.muted,fontWeight:650}}>ASÍ SE FABRICA</div>
 <h1 style={{position:'absolute',left:100,top:292,width:800,margin:0,fontSize:i===0?70:i===13?67:57,lineHeight:1.08,whiteSpace:'pre-line',fontWeight:800,letterSpacing:-1.8,color:i===6?C.yellow:C.white}}>{s.title}</h1>
 <div style={{position:'absolute',left:100,top:1198,width:790,fontSize:51,lineHeight:1.25,fontWeight:750,textAlign:'center',textWrap:'balance',color:C.white,opacity:enter,translate:`0 ${(1-enter)*6}px`}}><Caption text={s.caption} highlight={s.highlight}/></div>
 </AbsoluteFill>;
};
export const WindowReel=()=>{
 let start=0;
 return <AbsoluteFill style={{background:C.bg,fontFamily:'Manrope,Arial,sans-serif',overflow:'hidden'}}>
 <style>{`@font-face{font-family:Manrope;src:url('${staticFile('ventana/Manrope.ttf')}');font-weight:200 800;}`}</style>
 {parts.map((p,i)=>{const from=start;start+=p.frames;return <Sequence key={p.id} name={p.id} from={from} durationInFrames={p.frames}><Shot i={i}/></Sequence>})}
 </AbsoluteFill>;
};
