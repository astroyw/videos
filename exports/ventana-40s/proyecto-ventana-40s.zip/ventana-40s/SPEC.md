# Cómo se hace una ventana

Video educativo de 40 s exactos (1200 cuadros a 30 FPS), 1080×1920. Caso ilustrativo: ventana abatible de aluminio con vidrio, sin marca ni medidas de fabricación. Español rioplatense, subtítulos y silencio total. 14 microescenas, sin números visibles.

Dirección: carbón #202123, Manrope local, subtítulos 54 px blancos con énfasis amarillo #F6C945. Aluminio gris claro, vidrio azul transparente. Diagrama central x150–850 y440–1110; textos esenciales x90–900 y240–1330. CTA 37–40 s. No dashboard, bullet slides, imágenes estáticas como sustituto del movimiento ni logo ajeno.

Hook elegido: ventana terminada que se desarma para preguntar cómo se fabrica. Alternativas consideradas: comenzar con una barra de aluminio o con una hoja que no cierra; el resultado primero comunica mejor el tema.

Secuencia: resultado/explosión 0–3; perfiles 3–5; medidas 5–8; cortes 8–11; mecanizados 11–14; ensamble con escuadras 14–17; control de escuadra 17–20; hoja 20–23; herrajes 23–26; vidrio 26–29; calzos 29–32; junquillos/burletes 32–35; funcionamiento 35–37; compartir 37–40.

Remotion compone todo. HyperFrames produce de cero el ensamble y la comparación de diagonales de 14 a 20 s. Diagramas propios, esquemáticos; geometrías de perfiles y procedimientos varían según el sistema. No cortar vidrio templado en pantalla ni presentar cotas inventadas como instrucciones de fabricación.
