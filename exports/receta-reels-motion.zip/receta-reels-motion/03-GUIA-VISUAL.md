# Dirección visual: divulgación con diagramas

## Qué tomar de las referencias

En los videos del aire acondicionado y del carril izquierdo se observa fondo carbón, dibujo central, contexto superior discreto, palabras clave amarillas y subtítulos cortos abajo. El aire se explica con aparato, control remoto y curvas; el tránsito, con autos, carriles, flechas y comparaciones. Los objetos cambian mientras avanza el razonamiento.

Tomar esa gramática, sin copiar el logo «posta.», su usuario, la locución, los textos ni los dibujos exactos. Diseñar una identidad propia. No mostrar números de escena, aunque las referencias tengan rótulos editoriales.

## Paleta sugerida

Son valores de diseño propuestos a partir de la observación, no una extracción exacta de marca.

| Función | Color | Uso |
| --- | --- | --- |
| Fondo | `#202123` | Campo principal, sin textura llamativa |
| Zona oscura | `#131518` | Interior de objetos o contraste de plano |
| Texto | `#F5F3EB` | Subtítulos y etiquetas importantes |
| Secundario | `#A7ABB0` | Contexto y líneas auxiliares; revisar contraste |
| Énfasis | `#F6C945` | Una o dos palabras, objeto protagonista |
| Error/alerta | `#F05B59` | Tachado, cruce, estado incorrecto |
| Frío/flujo | `#70BCE2` | Corrientes, curvas, comparación |
| Correcto | `#60C992` | Confirmación puntual |

Usar uno o dos acentos por plano. El significado del color debe permanecer estable. No depender solo del color para diferenciar casos: agregar etiqueta, forma o movimiento.

## Composición a 1080 × 1920

- Zona esencial conservadora: **x=90…900; y=240…1450**. La derecha queda más libre por los controles de las plataformas.
- Contexto o marca propia opcional: cerca de y=260, con baja jerarquía. Nada de encabezados largos permanentes.
- Objeto explicativo: aproximadamente y=420…1120, con libertad para ampliar el plano si hace falta.
- Subtítulos: aproximadamente y=1180…1420, ancho útil 780–810 px, centrados o con alineación consistente.
- Etiquetas imprescindibles: dentro de la zona esencial, pegadas al objeto que nombran.
- Fondo y decoraciones: pueden sangrar hasta los bordes.

No existe una zona universal garantizada para todas las interfaces, tamaños de descripción o recortes. Revisar el MP4 en la vista previa de la plataforma antes de publicarlo. Evitar información esencial en los 250 px superiores o 400 px inferiores como criterio inicial aproximado.

## Tipografía y subtítulos

Usar una sans serif local de buena lectura; Manrope está incluida en la demostración con su licencia. Peso 700–800 para subtítulos. Rangos iniciales: subtítulos 48–60 px, titulares ocasionales 64–88 px, etiquetas esenciales 36–44 px. Ajustar después de ver el resultado a tamaño de celular.

Una idea por bloque, máximo dos líneas. Preferir 4–9 palabras y 1,8–3 segundos de lectura; acortar el texto si el ritmo exige menos tiempo. Evitar partir artículos o preposiciones de la palabra a la que pertenecen. No usar párrafos ni texto en mayúsculas durante todo el video.

El resaltado amarillo puede acompañar una palabra clave por frase. En modo sin voz, no presentarlo como karaoke sincronizado: es énfasis editorial. Con voz, alinearlo a tiempos medidos.

## Movimiento que explica

| Idea | Movimiento útil | Qué revisar |
| --- | --- | --- |
| Causa → efecto | Cambia primero la variable, después el resultado | Orden causal visible |
| Comparación | Dos estados alineados, misma escala, variable identificada | No engañar con ejes distintos |
| Flujo | Partículas/flechas entran y salen por un recorrido | Dirección coherente |
| Acumulación | Cantidad crece con el tiempo | No confundir tamaño con cantidad |
| Cambio de escala | Zoom del objeto a su interior esquemático | Conservar una referencia espacial |
| Mito | Se ve la predicción y luego el comportamiento correcto | Mostrar evidencia, no solo una cruz |
| Regla/excepción | Condición aparece y modifica el resultado | No ocultar la condición en letra chica |

Mantener un centro de atención. Los movimientos pequeños siguen ocurriendo durante las pausas de lectura, pero no deben distraer. Los cortes pueden ser rápidos si el estado anterior ya se entendió.

Transiciones sugeridas: 6–12 cuadros, ease-out para entradas, continuidad de posición entre planos relacionados. Zooms moderados de aproximadamente 5–12% cuando tengan un propósito. Evitar rotación constante de todo, paneos de imágenes estáticas como único movimiento, explosiones decorativas y rebote en cada palabra.

## Cierre

Resolver primero la pregunta. En los últimos 3 segundos, mostrar **una CTA legible** sobre una continuación del gráfico, por ejemplo una burbuja que asciende suavemente. Si hay marca propia, usarla en segundo plano; no reemplazar la conclusión por una placa de logo ajeno.
