# Instalación y skills locales

La receta es reutilizable en Claude Code y Codex. Las skills son instrucciones que el agente lee; las dependencias npm son las bibliotecas que ejecutan el video. Necesitás ambas cuando corresponda.

## Revisar antes de instalar

```bash
node --version
npm --version
ffmpeg -version
ffprobe -version
```

Node.js 22 o superior para este kit. Usar una versión de Node que siga teniendo soporte y sea compatible con las dependencias. Verificar navegador Chromium/Chrome o dejar que Remotion instale el compatible. No borrar manifests o lockfiles de un proyecto existente.

## Skills dentro del proyecto

Ejecutar desde la carpeta que se vaya a usar como raíz del proyecto, sin la opción global:

```bash
npx -y skills@latest add remotion-dev/skills -y
npx -y skills@latest add heygen-com/hyperframes --skill hyperframes hyperframes-cli hyperframes-registry media-use -y
```

Comprobar que los archivos reales estén en `.agents/skills/` y no solo en una caché de npx. Leer los SKILL.md pertinentes desde allí. Si el cliente necesita otro directorio para descubrir skills, usar el método oficial de su instalador y conservar una copia local o una referencia válida al mismo contenido.

Con HyperFrames instalado en el proyecto:

```bash
npx hyperframes skills check --dir .agents/skills --json
```

Las cuatro principales deben estar presentes y `coreMissing` debe ser 0. Una actualización posterior puede cambiar el formato del informe: leer su salida real. Las skills opcionales faltantes no equivalen a fallo de las principales.

El comando `npx hyperframes skills update` puede intentar instalar en el home global según la versión. Si se usa, comprobar el destino y verificar luego la copia local. La alternativa local de arriba evita depender de una instalación global temporal. No editar las instrucciones externas para ocultar un error de instalación.

## Ejecutar el proyecto incluido

```bash
cd plantilla-remotion
npm ci
npm run check
npm run render
npm run verify
```

Los nombres de salida y opciones concretas están en `plantilla-remotion/README.md`. El proyecto fija versiones y trae lockfile. No actualizar versiones solo por rutina; mantener sincronizados todos los paquetes `@remotion/*` y `remotion`.

En una computadora con navegador ya instalado, la plantilla permite configurar `REMOTION_BROWSER_EXECUTABLE`. En una nube administrada, respetar el proxy y las CA existentes. Ajustar la caché npm a una ruta escribible si hace falta. No desactivar TLS para conseguir que una instalación pase.

## Función de cada herramienta

- **Remotion:** composición principal, SVG/React, timing por fotogramas, subtítulos y montaje/exportación.
- **HyperFrames:** segmento HTML/GSAP renderizado a video; el ejemplo contiene su fuente y un clip local ya renderizado.
- **FFmpeg/FFprobe:** conversión final cuando haga falta, metadatos y decodificación de control.

Renderizar localmente este ejemplo no requiere una voz de HeyGen ni una cuenta de generación remota. Otros servicios opcionales pueden tener sus propios requisitos. Consultar las licencias vigentes de las herramientas para el uso previsto.

Las skills oficiales se descargan de sus repositorios; no están redistribuidas dentro del ZIP. Para máxima reproducibilidad, guardar el lockfile de skills que produzca el instalador y registrar la revisión usada en cada proyecto.
