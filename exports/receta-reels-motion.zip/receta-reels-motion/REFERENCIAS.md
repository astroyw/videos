# Referencias y alcance del análisis

Revisión realizada para este kit el 29 de octubre de 2026.

| Archivo aportado | Acceso y revisión |
| --- | --- |
| `Poner el aire en 17 NO enfría más rápido #shorts.mp4` | Abierto. 1080 × 1920, 30 FPS, unos 67,895 s. Se inspeccionaron cuadros a 1, 4, 9, 16, 24, 32, 42, 51, 59 y 66 segundos. |
| `Vas a 130 por la izquierda ¿te tenés que correr igual #shorts.mp4` | Abierto. 1080 × 1920, 30 FPS, unos 81,897 s. Se inspeccionaron cuadros a 1, 5, 12, 20, 29, 39, 49, 59, 70 y 80 segundos. |
| `El secreto de la gravedad en una Tierra plana #fisica #espacio #datoscuriosos.mp4` | No se pudo transferir: supera el límite de 32 MiB de la herramienta disponible. No se infiere su diseño a partir del título. |

Además se inspeccionaron secuencias de muestras cada 0,5 segundos: 6–8 s y 45–47 s del aire acondicionado; 34–36 s y 60–62 s del carril izquierdo. Permiten observar continuidad de objetos, cambios de texto y resaltado de palabras.

El análisis de las dos primeras referencias es visual, mediante fotogramas y secuencias de muestras. No se realizó una transcripción o escucha completa ni una auditoría factual de sus afirmaciones. La guía del kit recoge composición, lenguaje de diagramas, paleta aproximada y jerarquía del texto.

Observaciones del aire acondicionado: aparato y control remoto, temperaturas, contraste de una idea con una cruz roja, gráfico comparativo y curvas. Del tránsito: vista superior de carretera, autos de colores, indicador de velocidad, flechas y comparación entre comportamientos.

Los archivos originales, su música/locución y sus logos no se incluyen en el ZIP. La demostración incluida es propia y usa el tema de gasificación trabajado en este repositorio. No es una reproducción cuadro por cuadro de los videos de referencia.

Para incorporar la tercera referencia al análisis futuro, colocar una versión accesible o un fragmento representativo en `referencias/` y pedir al agente que inspeccione su contenido real antes de ajustar el estilo.
