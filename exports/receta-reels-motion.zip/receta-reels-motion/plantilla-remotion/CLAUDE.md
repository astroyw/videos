# Claude Code

Leé y seguí `AGENTS.md` y `README.md` de esta carpeta, además de la receta principal del kit. Esta demo usa Remotion para el montaje y un clip de HyperFrames para las moléculas. La especificación vigente del usuario tiene prioridad sobre los valores del ejemplo.
