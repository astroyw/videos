# Ejemplo editorial: cómo se gasifican las bebidas

Este es un guion modelo para aprender a convertir un tema en una explicación animada. Es un storyboard editorial independiente: la demostración ejecutable de `../plantilla-remotion/` puede distribuir sus escenas de otra forma. Si usás este guion para producir un video, implementá estos tiempos y movimientos en el código; cambiar únicamente los textos de otra composición no alcanza.

**Entrega propuesta:** 40 segundos exactos, 1080 × 1920, 30 FPS, 1200 cuadros, MP4 H.264, 14 microescenas, subtítulos incrustados y SRT. **Sin voz, música ni efectos sonoros.** No mostrar números de escena, de slide ni contadores.

**Pregunta central:** ¿cómo llega el gas a una bebida y por qué aparecen burbujas al abrirla?

**Promesa del gancho:** explicar un fenómeno cotidiano que el espectador reconoce al instante. **Retención:** revelar primero que el gas está disuelto y luego preguntar qué cambia al destapar. **Recompensa:** mostrar la caída de presión y el nacimiento de una burbuja. **CTA única:** «Compartíselo a ese amigo curioso».

## Storyboard listo para implementar

Los intervalos son `[inicio, fin)`: el cuadro final de una fila pertenece a la siguiente. Los identificadores son para el editor; no aparecen en pantalla. No hay un título grande fijo sobre cada escena: manda el diagrama, acompañado por un subtítulo breve y, cuando ayude, una etiqueta pequeña.

| ID interno | Tiempo | Cuadros | Subtítulo visible | Diagrama y movimiento que explica | Función narrativa |
|---|---|---|---|---|---|
| apertura | 0–3 s | 0–90 | Abrís una gaseosa. ¿De dónde sale ese gas? | Botella cerrada en primer plano. La tapa gira y sube; después aparecen burbujas ascendentes. El primer segundo ya muestra la acción. | Gancho: situación reconocible y pregunta concreta. |
| identidad | 3–6 s | 90–180 | Es dióxido de carbono: CO₂. | Acercamiento que conecta una burbuja con un esquema de una molécula lineal O=C=O. La etiqueta CO₂ entra al lado, no sobre el dibujo. | Primera respuesta rápida. |
| contacto | 6–9 s | 180–270 | Se agrega CO₂ de uso alimentario. | Tanque y conducto de entrada. Flechas muestran gas entrando en contacto con el líquido; una frontera visible diferencia ambas fases. | Hace visible el origen del gas. |
| frio | 9–12 s | 270–360 | En frío, se puede disolver más gas. | Termómetro desciende. Mantener la presión de CO₂ constante en la comparación; aumentar gradualmente las moléculas disueltas. Etiqueta discreta: «a igual presión». | Explica una condición de fabricación. |
| presion | 12–15 s | 360–450 | Más presión de CO₂ permite disolver más. | Manómetro sube y moléculas atraviesan la interfaz. Mantener la temperatura de la comparación constante. | Segunda causa, con su consecuencia visible. |
| disuelto | 15–18 s | 450–540 | Disuelto significa moléculas repartidas en el líquido. | Acercamiento molecular: CO₂ entre moléculas de agua en movimiento. No dibujar círculos de gas como si fueran burbujas atrapadas. | Corrige una intuición equivocada. |
| pregunta | 18–21 s | 540–630 | Entonces, ¿qué cambia cuando la abrís? | Alejar desde el diagrama molecular hacia una botella cerrada. Resaltar la tapa y el gas del espacio superior con una línea amarilla. | Microgancho: plantea la siguiente causa sin ocultar lo ya explicado. |
| llenado | 21–24 s | 630–720 | Se embotella a contrapresión para perder menos CO₂. | El nivel de líquido sube dentro de una botella conectada al llenador; una indicación de presión se conserva durante la transferencia. | Responde cómo se preserva el gas durante el proceso. |
| sellado | 24–27 s | 720–810 | El cierre ayuda a conservar el gas disuelto. | La tapa desciende y sella. Mostrar líquido y espacio superior con CO₂; flechas sutiles en ambos sentidos sugieren intercambio en equilibrio. | Prepara el contraste entre cerrado y abierto. |
| destapar | 27–30 s | 810–900 | Al destaparla, baja la presión y sobra CO₂ disuelto. | La tapa se abre; el manómetro cae. Marcar «sobresaturación» como etiqueta opcional. El cambio de presión precede al crecimiento visible de burbujas. | Recompensa principal: conecta apertura con liberación del gas. |
| nucleacion | 30–33 s | 900–990 | Pequeñas cavidades facilitan que se formen burbujas. | Acercamiento a una irregularidad de la pared con un pequeño bolsillo de gas. Una burbuja nace allí y empieza a crecer. | Explica dónde empieza el fenómeno. |
| crecimiento | 33–35 s | 990–1050 | El CO₂ disuelto alimenta la burbuja. | Moléculas se desplazan hacia la interfaz; la burbuja aumenta de tamaño de forma continua. | Completa el mecanismo en un plano simple. |
| resultado | 35–37 s | 1050–1110 | Sube, llega a la superficie y libera el gas. | Una burbuja se desprende, asciende y llega a la superficie. Conservar el mismo color del CO₂ durante todo el recorrido. | Cierre de la explicación y recuerdo visual del gancho. |
| compartir | 37–40 s | 1110–1200 | Compartíselo a ese amigo curioso. | Botella y una última burbuja ascienden suavemente; la CTA entra una sola vez y permanece legible. Mantenerla dentro del área segura. | Una única acción final, relacionada con la curiosidad del video. |

## Dirección visual para este ejemplo

- Fondo carbón, gráficos simples con volumen discreto, tipografía sans serif blanca y gruesa. Amarillo para el dato que se está explicando; azul para el frío o el líquido; rojo solo si se señala un error. Los colores deben conservar significado entre escenas.
- Una idea visual por plano. Transformar el mismo tanque, botella o diagrama entre estados para que se comprenda la continuidad.
- El movimiento tiene que explicar algo: una tapa que se abre, presión que baja, gas que entra, líquido que sube, una burbuja que crece. Evitar animaciones decorativas que compitan con la causa.
- Dejar el subtítulo quieto el tiempo suficiente para leerlo. Resaltar una o dos palabras por frase, sin un karaoke ficticio sincronizado con una voz inexistente.
- Las etiquetas «presión», «CO₂» y «frío» pueden estar junto a los objetos; no repetir toda la explicación en títulos y subtítulos a la vez.
- La CTA se mantiene en pantalla tres segundos; no agregar además «suscribite» y «dale like».

## Límites del modelo científico

El esquema simplifica la escala molecular y los equipos industriales. CO₂ es lineal y H₂O es angular; las moléculas no están dibujadas a escala. En el líquido, CO₂ disuelto no equivale a pequeñas burbujas preexistentes. Un recipiente sellado también tiene una fase gaseosa en el espacio superior. La solubilidad depende de la temperatura y de la presión parcial de CO₂; las comparaciones deben mantener la otra condición constante. La caída de presión favorece la liberación del exceso de gas y la nucleación puede verse favorecida por cavidades o partículas. No todos los procesos industriales usan una secuencia idéntica de equipos.

Este texto es una guía editorial, no un registro de fuentes consultadas. Antes de publicar un video científico, documentar las fuentes efectivamente verificadas para las afirmaciones del guion y ajustar cualquier simplificación que resulte engañosa.

## Si después agregás tu voz

Los subtítulos pueden servir como base para tu narración, pero los tiempos de este ejemplo son de lectura y animación: no están sincronizados con una grabación. Grabá tu voz, medí cada frase y ajustá los subtítulos, el SRT y las acciones al audio real. Si la entrega debe seguir durando 40 segundos, la suma final tiene que conservar exactamente 1200 cuadros. El ejemplo original permanece sin pista de audio.
