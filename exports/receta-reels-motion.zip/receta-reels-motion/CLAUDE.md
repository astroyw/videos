# Instrucciones para Claude Code

Leé `AGENTS.md` de esta carpeta, `00-EMPEZA-ACA.md` y el brief de `01-PROMPT-EDITABLE.md`. Aplicá la receta de `02-RECETA-PARA-EL-AGENTE.md` y la guía visual antes de construir el video.

Las skills relevantes están en `.agents/skills/` del proyecto después de instalarlas con `06-INSTALACION-Y-SKILLS.md`. Si no aparecen en tu catálogo, leé sus SKILL.md directamente. No confundas instalarlas con haber renderizado usando las herramientas.

Entregá resultados verificables y preservá los archivos del usuario. Estas instrucciones pertenecen a esta carpeta; no reemplazan las de un repositorio ajeno.
