# PROMPT EDITABLE — copiá desde acá

Quiero que produzcas un video educativo con motion graphics para Instagram Reels, YouTube Shorts y TikTok. Ejecutá el trabajo hasta entregar un MP4 renderizado y verificado, con sus fuentes editables. No te detengas en una propuesta o en imágenes de muestra.

## 1. Mi brief — EDITÁ ESTOS CAMPOS

TEMA: [Cómo se gasifican las bebidas]
IDEA_QUE_DEBE_ENTENDERSE: [El CO₂ se disuelve mejor en líquido frío bajo presión; al abrir, la presión baja y aparecen burbujas.]
PUBLICO: [Personas curiosas, sin conocimientos técnicos previos]
DURACION_SEGUNDOS: [40]
CANTIDAD_DE_PARTES: [14; entre 10 y 20 para una pieza de 40 segundos]
IDIOMA_Y_TONO: [Español rioplatense, cercano, claro, preciso; usar vos, mirá, pensá]
HOOK: [AUTO: proponé internamente tres opciones y ejecutá la más clara y visual]
PREGUNTA_QUE_ABRE_CURIOSIDAD: [¿Cómo llegó ese gas a la bebida?]
GIRO_O_DETALLE_SORPRENDENTE: [Cuando está disuelto, el CO₂ no está formando burbujitas visibles]
CTA_UNICA: [Compartíselo a ese amigo curioso.]
MARCA_O_USUARIO: [NINGUNO; opcional: mi propia marca]
VOZ: [NO; voy a grabarla después]
MUSICA_Y_EFECTOS: [NO; entregar sin ninguna pista de audio]
SUBTITULOS: [Incrustados y archivo SRT separado]
FUENTES_O_DATOS_OBLIGATORIOS: [Investigar fuentes fiables y registrar sus enlaces]
REFERENCIAS_VISUALES: [Los videos que adjunto y la guía visual de este kit, si está disponible]
RESTRICCIONES_DEL_TEMA: [Evitar afirmaciones absolutas cuando haya excepciones relevantes]

Los corchetes delimitan valores editables: no deben aparecer en pantalla. Si algo opcional falta, usá una decisión razonable y registrala. Preguntá solo si falta un dato imprescindible. No dependas de una aprobación intermedia del guion para renderizar: este pedido ya solicita la entrega final.

## 2. Estructura narrativa obligatoria

- **Hook:** en los primeros 2–3 segundos, una situación reconocible, una pregunta concreta o una creencia puesta a prueba. Mostrar el objeto o fenómeno desde el primer cuadro útil.
- **Promesa abierta:** dejar claro qué pregunta se va a resolver. No esconder todo el valor hasta el final.
- **Cuerpo:** explicar una sola cadena causal. Cada microescena aporta una idea y una acción visible en el diagrama.
- **Retención:** en la mitad, introducir una comparación, una predicción o un detalle que cambie cómo se entiende el fenómeno. Después mostrar su respuesta. No usar «esperá al final» como recurso vacío.
- **Payoff:** resolver la pregunta inicial de forma visual y con una frase breve antes del cierre.
- **CTA:** reservar los últimos 3 segundos para UNA acción de `CTA_UNICA`, relacionada con el tema. Mantener el objeto o diagrama en movimiento suave. No pedir compartir, seguir y dar like a la vez.

Con los valores iniciales, organizá 14 microescenas en 40 segundos, de aproximadamente 2–3 segundos cada una. La suma debe dar **1200 fotogramas a 30 FPS**. Si edito duración o cantidad, respetá los nuevos valores del brief, recalculá los intervalos y conservá 3 segundos para la CTA. Si la combinación no deja leer el texto, acortá el guion; señalá cualquier incompatibilidad real. Las escenas son cambios de estado y encuadre; no diapositivas numeradas. Los identificadores internos del storyboard nunca se dibujan en el video.

## 3. Dirección visual

Quiero divulgación con diagramas animados, como los archivos adjuntos:

- Fondo carbón uniforme o con una viñeta muy sutil; base sugerida `#202123`.
- Texto blanco cálido `#F5F3EB`; palabras clave amarillas `#F6C945`.
- Rojo `#F05B59` para error, peligro o contraste; azul `#70BCE2` para frío, flujo o comparación; verde solo si representa una condición correcta.
- Un protagonista visual grande en el centro: objeto, corte esquemático, moléculas, carretera, flechas o gráfico que explique el tema.
- Ilustración vectorial limpia en SVG/Canvas. Volumen y sombras discretas, trazos consistentes. El gráfico debe tener movimiento causal: algo entra, cambia, se desplaza, se acumula o sale.
- Tipografía sans serif gruesa y legible. Subtítulos de 48–60 px sobre el lienzo de 1080 px, máximo dos líneas y preferentemente 4–9 palabras por bloque. Resaltar solo 1–2 palabras.
- Titulares opcionales, cortos, de 64–88 px. No llenar cada escena con un título gigante además del subtítulo. Las etiquetas técnicas pueden ser menores si son secundarias.
- Márgenes conservadores para elementos esenciales: x entre 90 y 900, y entre 240 y 1450. Poner subtítulos preferentemente entre y=1180 y y=1420. El fondo y las ilustraciones no esenciales pueden llegar al borde. Estos márgenes no reemplazan la revisión en la aplicación de destino.
- Cortes al cambiar la idea; continuidad del objeto entre escenas relacionadas; acercamientos y transiciones de 6–12 fotogramas cuando ayuden a entender. Easing suave, sin rebotes elásticos constantes.
- Nada de números de slide, barras de navegador, tarjetas de dashboard, listas estáticas, emojis como ilustración principal, logos ajenos ni marcas de agua.

## 4. Tecnología y producción

Usá **Remotion** para composición, timing, tipografía, subtítulos y exportación. Usá **HyperFrames** para al menos un segmento animado útil, integrando su render local en Remotion. Guardá también el HTML/GSAP de ese segmento. No alcanza con instalar las skills y afirmar que se usaron ambas herramientas.

Si está disponible este kit, leé `02-RECETA-PARA-EL-AGENTE.md`, `03-GUIA-VISUAL.md`, `05-CONTROL-DE-CALIDAD.md` y el README de `plantilla-remotion/`. Usá la plantilla como ejemplo, no como sustituto del diseño del tema nuevo.

Inspeccioná el repositorio y sus instrucciones antes de cambiarlo. Preservá su aplicación, dependencias y archivos. Creá una subcarpeta si hace falta. Verificá Node.js, npm, FFmpeg, FFprobe y navegador. Instalá las skills oficiales dentro del proyecto, preferentemente `.agents/skills`, y leé las pertinentes. Mantené todos los paquetes Remotion en la misma versión.

Animá de manera determinista con fotogramas en Remotion y una timeline pausada registrada en HyperFrames. Usá recursos y fuentes locales al renderizar. Conservá sus licencias. No inventes simulaciones científicas: si el diagrama es esquemático, indicálo cuando sea relevante y respetá el mecanismo real.

## 5. Texto y audio

Con `VOZ=NO`, no generes narración ni agregues una voz provisional. Con `MUSICA_Y_EFECTOS=NO`, el MP4 no debe tener ninguna pista de audio. Los subtítulos deben permitir entender el video por sí solos, con tiempo suficiente de lectura. Prepará el guion por intervalos para que yo pueda grabar mi voz después.

Si cambio el brief para pedir voz, generá o usá el archivo autorizado, ajustá el montaje a su duración real y sincronizá subtítulos con ese audio. No afirmes sincronización por palabra si solo alineaste frases. No clones la voz del creador de las referencias. Si falta una capacidad de audio necesaria, informá el límite real.

## 6. Formato y control final

Entregá 1080 × 1920, 9:16, 30 FPS, MP4 H.264, yuv420p y duración exacta del brief. Con 40 segundos son 1200 cuadros. Usá metadatos de color coherentes y faststart para reproducción web.

Antes de entregar:

1. Comprobá el contenido factual y guardá fuentes y matices en `FUENTES.md`.
2. Ejecutá las verificaciones de código y `hyperframes check` cuando corresponda. Corregí errores; no cuentes auditorías sin muestras como aprobaciones visuales.
3. Revisá fotogramas decodificados del MP4 de cada escena y de los cortes. Verificá tamaño de texto, márgenes, continuidad, CTA y ausencia de números.
4. Comprobá movimiento del objeto explicativo dentro de cada escena. Cambiar solo subtítulos o una barra de progreso no demuestra motion graphics.
5. Usá FFprobe para verificar resolución, codec, FPS, duración, cuadros y presencia o ausencia de audio. Decodificá el archivo completo con FFmpeg para detectar errores.
6. Si hay narración, revisá que corresponda con los subtítulos. Diferenciá mediciones técnicas de escucha humana.

Entregables: `video-final.mp4`, `subtitulos.srt`, `GUION.md` con tiempos, `FUENTES.md`, proyecto editable, assets utilizados y `VERIFICACION.md` con resultados reales. Entregá un enlace o adjunto que exista; no presentes una ruta interna como si fuera una descarga comprobada. No publiques en redes ni hagas push al repositorio sin mi autorización.
